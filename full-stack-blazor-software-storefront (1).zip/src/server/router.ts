import { z, type ZodType } from "zod";
import { eq, or, sql } from "drizzle-orm";
import { db } from "@/db";
import { licenses, products, users } from "@/db/schema";
import {
  ACCESS_TTL,
  REFRESH_COOKIE,
  consumeRefreshToken,
  hashPassword,
  issueRefreshToken,
  refreshCookieOptions,
  revokeRefreshToken,
  signAccessToken,
  toUserDto,
  verifyAccessToken,
  verifyPassword,
} from "@/server/auth";
import {
  HttpError,
  corsPreflight,
  forbidden,
  listParams,
  logger,
  notFound,
  ok,
  pagedMeta,
  parseCookies,
  parseJson,
  problem,
  serializeCookie,
} from "@/server/http";
import * as catalog from "@/server/services/catalog";
import * as commerce from "@/server/services/commerce";
import * as support from "@/server/services/support";
import { ensureSeeded } from "@/server/bootstrap";
import type { PagedMeta, Role } from "@/shared/contracts";

export interface AuthUser {
  id: string;
  email: string;
  role: Role;
  name: string;
}

export interface ListOptions {
  defaultSort?: string;
  allowedSorts?: string[];
  filters?: string[];
}

export interface ListQuery {
  page: number;
  pageSize: number;
  search: string | null;
  sortBy: string | null;
  sortDir: "asc" | "desc";
  filters: Record<string, string>;
}

export interface RouteContext {
  req: Request;
  method: string;
  params: Record<string, string>;
  query: URLSearchParams;
  user: AuthUser | null;
  cookies: string[];
  cartSession: string;
  body<T>(schema: ZodType<T>): Promise<T>;
  requireUser(): AuthUser;
  requireAdmin(): AuthUser;
  list(options?: ListOptions): ListQuery;
  meta(page: number, pageSize: number, total: number): PagedMeta;
}

type Handler = (ctx: RouteContext) => Promise<unknown>;
type AuthMode = "public" | "user" | "admin";

interface RouteDef {
  method: string;
  path: string;
  tag: string;
  summary: string;
  auth: AuthMode;
  handler: Handler;
}

const uuid = z.string().uuid();

/* --------------------------------- schemas -------------------------------- */

const credentials = z.object({
  email: z.string().email(),
  password: z.string().min(8, "Password must be at least 8 characters"),
});

const registerSchema = credentials.extend({
  fullName: z.string().min(2),
  company: z.string().optional().nullable(),
  country: z.string().optional().nullable(),
});

const productSchema = z.object({
  name: z.string().min(2),
  slug: z.string().min(2).regex(/^[a-z0-9-]+$/, "Use lowercase letters, numbers and dashes"),
  tagline: z.string().min(5),
  description: z.string().min(20),
  categoryId: uuid,
  type: z.enum(["Module", "DesktopApp", "AddOn"]),
  platform: z.string().min(2),
  version: z.string().min(1),
  basePriceCents: z.number().int().min(0),
  heroImage: z.string().optional().nullable(),
  accentColor: z.string().optional(),
  features: z.array(z.string()).optional(),
  systemRequirements: z.array(z.string()).optional(),
  demoVideoUrl: z.string().optional().nullable(),
  trialDays: z.number().int().min(0).max(365).optional(),
  isFeatured: z.boolean().optional(),
  isActive: z.boolean().optional(),
});

const planSchema = z.object({
  productId: uuid.optional(),
  name: z.string().min(2),
  tier: z.enum(["SingleUser", "MultiUser", "Enterprise"]),
  billingType: z.enum(["OneTime", "Annual"]),
  priceCents: z.number().int().min(0),
  seats: z.number().int().min(1).max(5000),
  description: z.string().optional().nullable(),
  isPopular: z.boolean().optional(),
  sortOrder: z.number().int().optional(),
});

const versionSchema = z.object({
  productId: uuid.optional(),
  version: z.string().min(1),
  releasedAt: z.string().min(4),
  notes: z.string().min(3),
  installerUrl: z.string().optional().nullable(),
  sizeMb: z.number().int().min(0).optional(),
  platform: z.string().optional(),
});

const categorySchema = z.object({
  name: z.string().min(2),
  slug: z.string().min(2).regex(/^[a-z0-9-]+$/),
  description: z.string().optional().nullable(),
  icon: z.string().optional(),
  sortOrder: z.number().int().optional(),
  isActive: z.boolean().optional(),
});

const checkoutSchema = z.object({
  discountCode: z.string().optional().nullable(),
  paymentMethod: z.enum(["card", "invoice", "bank-transfer"]).default("card"),
  cardName: z.string().optional(),
  cardNumber: z.string().optional(),
  billing: z.object({
    name: z.string().min(2),
    company: z.string().optional().nullable(),
    email: z.string().email(),
    country: z.string().min(2),
    vatId: z.string().optional().nullable(),
  }),
  notes: z.string().optional().nullable(),
});

const ticketSchema = z.object({
  productId: uuid.optional().nullable(),
  subject: z.string().min(5),
  category: z.enum(["Technical", "Billing", "Licensing", "Feature Request", "General"]),
  priority: z.enum(["Low", "Normal", "High", "Critical"]),
  environment: z.string().optional().nullable(),
  message: z.string().min(10),
});

const reviewSchema = z.object({
  productId: uuid,
  rating: z.number().int().min(1).max(5),
  title: z.string().min(3),
  body: z.string().min(10),
  authorCompany: z.string().optional().nullable(),
});

/* --------------------------------- helpers -------------------------------- */

async function resolveProduct(idOrSlug: string) {
  const [row] = await db
    .select()
    .from(products)
    .where(or(eq(products.slug, idOrSlug), eq(products.id, idOrSlug)))
    .limit(1);
  if (!row) throw notFound("Product");
  return catalog.getProductById(row.id);
}

function cartSessionOf(ctx: RouteContext) {
  return { sessionKey: ctx.cartSession, userId: ctx.user?.id ?? null };
}

function responseWithCookies(payload: unknown, meta: PagedMeta | undefined, cookies: string[]): Response {
  const base = ok(payload, meta);
  if (!cookies.length) return base;
  const headers = new Headers(base.headers);
  for (const cookie of cookies) headers.append("set-cookie", cookie);
  return new Response(base.body, { status: base.status, headers });
}

/* -------------------------------- route table ------------------------------ */

export const routes: RouteDef[] = [
  {
    method: "GET",
    path: "/api/health",
    tag: "System",
    summary: "Health check used by the platform",
    auth: "public",
    handler: async () => {
      await db.execute(sql`select 1`);
      return { ok: true, timestamp: new Date().toISOString() };
    },
  },
  {
    method: "POST",
    path: "/api/system/reseed",
    tag: "System",
    summary: "Rebuild demo data (admin only)",
    auth: "admin",
    handler: async () => {
      await ensureSeeded(true);
      return { reseeded: true };
    },
  },

  /* ---------------------------------- auth ---------------------------------- */
  {
    method: "POST",
    path: "/api/auth/register",
    tag: "Auth",
    summary: "Create a customer account and start a session",
    auth: "public",
    handler: async (ctx) => {
      const input = await ctx.body(registerSchema);
      const [existing] = await db
        .select()
        .from(users)
        .where(eq(users.email, input.email.toLowerCase()))
        .limit(1);
      if (existing) {
        throw new HttpError(409, "email_taken", "An account with this email already exists.");
      }
      const [row] = await db
        .insert(users)
        .values({
          email: input.email.toLowerCase(),
          fullName: input.fullName,
          company: input.company ?? null,
          country: input.country ?? null,
          passwordHash: hashPassword(input.password),
          role: "Customer",
        })
        .returning();
      const access = signAccessToken(row);
      const refresh = await issueRefreshToken(row.id);
      ctx.cookies.push(serializeCookie(REFRESH_COOKIE, refresh, refreshCookieOptions()));
      return { user: toUserDto(row), accessToken: access.token, expiresIn: access.expiresIn };
    },
  },
  {
    method: "POST",
    path: "/api/auth/login",
    tag: "Auth",
    summary: "Exchange credentials for an access + refresh token pair",
    auth: "public",
    handler: async (ctx) => {
      const input = await ctx.body(credentials);
      const [row] = await db
        .select()
        .from(users)
        .where(eq(users.email, input.email.toLowerCase()))
        .limit(1);
      if (!row || !verifyPassword(input.password, row.passwordHash)) {
        throw new HttpError(401, "invalid_credentials", "Email or password is incorrect.");
      }
      if (row.isLocked) throw new HttpError(403, "account_locked", "This account has been locked.");
      await db.update(users).set({ lastLoginAt: new Date() }).where(eq(users.id, row.id));
      const access = signAccessToken(row);
      const refresh = await issueRefreshToken(row.id);
      ctx.cookies.push(serializeCookie(REFRESH_COOKIE, refresh, refreshCookieOptions()));
      return { user: toUserDto(row), accessToken: access.token, expiresIn: access.expiresIn };
    },
  },
  {
    method: "POST",
    path: "/api/auth/refresh",
    tag: "Auth",
    summary: "Rotate the refresh token and issue a new access token",
    auth: "public",
    handler: async (ctx) => {
      const jar = parseCookies(ctx.req.headers.get("cookie"));
      const token = jar[REFRESH_COOKIE];
      if (!token) throw new HttpError(401, "no_refresh_token", "No refresh token present.");
      const user = await consumeRefreshToken(token);
      if (!user) {
        throw new HttpError(401, "invalid_refresh_token", "Session expired, please sign in again.");
      }
      const [row] = await db.select().from(users).where(eq(users.id, user.id)).limit(1);
      const refresh = await issueRefreshToken(user.id);
      ctx.cookies.push(serializeCookie(REFRESH_COOKIE, refresh, refreshCookieOptions()));
      const access = signAccessToken(row);
      return { user, accessToken: access.token, expiresIn: access.expiresIn };
    },
  },
  {
    method: "POST",
    path: "/api/auth/logout",
    tag: "Auth",
    summary: "Revoke the refresh token",
    auth: "public",
    handler: async (ctx) => {
      const jar = parseCookies(ctx.req.headers.get("cookie"));
      if (jar[REFRESH_COOKIE]) await revokeRefreshToken(jar[REFRESH_COOKIE]);
      ctx.cookies.push(serializeCookie(REFRESH_COOKIE, "", { ...refreshCookieOptions(), maxAge: 0 }));
      return { loggedOut: true };
    },
  },
  {
    method: "GET",
    path: "/api/auth/me",
    tag: "Auth",
    summary: "Current authenticated user",
    auth: "user",
    handler: async (ctx) => {
      const user = ctx.requireUser();
      const [row] = await db.select().from(users).where(eq(users.id, user.id)).limit(1);
      if (!row) throw notFound("User");
      return { user: toUserDto(row) };
    },
  },
  {
    method: "PATCH",
    path: "/api/auth/me",
    tag: "Auth",
    summary: "Update profile details",
    auth: "user",
    handler: async (ctx) => {
      const user = ctx.requireUser();
      const input = await ctx.body(
        z.object({
          fullName: z.string().min(2).optional(),
          company: z.string().optional().nullable(),
          phone: z.string().optional().nullable(),
          country: z.string().optional().nullable(),
        }),
      );
      const [row] = await db.update(users).set(input).where(eq(users.id, user.id)).returning();
      return { user: toUserDto(row) };
    },
  },
  {
    method: "POST",
    path: "/api/auth/change-password",
    tag: "Auth",
    summary: "Change the current password",
    auth: "user",
    handler: async (ctx) => {
      const user = ctx.requireUser();
      const input = await ctx.body(
        z.object({
          currentPassword: z.string().min(8),
          newPassword: z.string().min(8, "Password must be at least 8 characters"),
        }),
      );
      const [row] = await db.select().from(users).where(eq(users.id, user.id)).limit(1);
      if (!row || !verifyPassword(input.currentPassword, row.passwordHash)) {
        throw new HttpError(400, "wrong_password", "Current password is incorrect.");
      }
      await db
        .update(users)
        .set({ passwordHash: hashPassword(input.newPassword) })
        .where(eq(users.id, user.id));
      return { updated: true };
    },
  },

  /* --------------------------------- products -------------------------------- */
  {
    method: "GET",
    path: "/api/products",
    tag: "Products",
    summary: "Paged, searchable, sortable product catalog",
    auth: "public",
    handler: async (ctx) => {
      const base = ctx.list({
        defaultSort: "newest",
        allowedSorts: ["newest", "oldest", "price-asc", "price-desc", "popular", "rating", "name"],
        filters: ["category", "type", "featured"],
      });
      const isAdmin = ctx.user?.role === "Admin";
      const result = await catalog.listProducts({
        ...base,
        categorySlug: base.filters.category,
        type: base.filters.type,
        featured: base.filters.featured === "true",
        includeInactive: isAdmin && ctx.query.get("includeInactive") === "true",
      });
      return { items: result.items, meta: ctx.meta(base.page, base.pageSize, result.total) };
    },
  },
  {
    method: "GET",
    path: "/api/products/compare",
    tag: "Products",
    summary: "Load several products for side-by-side comparison",
    auth: "public",
    handler: async (ctx) => {
      const ids = (ctx.query.get("ids") ?? "").split(",").filter(Boolean).slice(0, 4);
      return { items: await catalog.getProductsByIds(ids) };
    },
  },
  {
    method: "POST",
    path: "/api/products",
    tag: "Products",
    summary: "Create a product (admin)",
    auth: "admin",
    handler: async (ctx) => catalog.createProduct(await ctx.body(productSchema)),
  },
  {
    method: "GET",
    path: "/api/products/:id",
    tag: "Products",
    summary: "Product detail with plans, versions and requirements",
    auth: "public",
    handler: async (ctx) => resolveProduct(ctx.params.id),
  },
  {
    method: "PATCH",
    path: "/api/products/:id",
    tag: "Products",
    summary: "Update a product (admin)",
    auth: "admin",
    handler: async (ctx) => catalog.updateProduct(ctx.params.id, await ctx.body(productSchema.partial())),
  },
  {
    method: "DELETE",
    path: "/api/products/:id",
    tag: "Products",
    summary: "Delete a product (admin)",
    auth: "admin",
    handler: async (ctx) => {
      await catalog.deleteProduct(ctx.params.id);
      return { deleted: true };
    },
  },
  {
    method: "POST",
    path: "/api/products/:id/plans",
    tag: "Plans",
    summary: "Add a pricing plan to a product (admin)",
    auth: "admin",
    handler: async (ctx) => {
      const input = await ctx.body(planSchema);
      return catalog.createPlan({ ...input, productId: ctx.params.id });
    },
  },
  {
    method: "PATCH",
    path: "/api/products/:id/plans/:planId",
    tag: "Plans",
    summary: "Update a pricing plan (admin)",
    auth: "admin",
    handler: async (ctx) => catalog.updatePlan(ctx.params.planId, await ctx.body(planSchema.partial())),
  },
  {
    method: "DELETE",
    path: "/api/products/:id/plans/:planId",
    tag: "Plans",
    summary: "Delete a pricing plan (admin)",
    auth: "admin",
    handler: async (ctx) => {
      await catalog.deletePlan(ctx.params.planId);
      return { deleted: true };
    },
  },
  {
    method: "POST",
    path: "/api/products/:id/versions",
    tag: "Versions",
    summary: "Publish a new product version (admin)",
    auth: "admin",
    handler: async (ctx) => {
      const input = await ctx.body(versionSchema);
      return catalog.createVersion({ ...input, productId: ctx.params.id });
    },
  },
  {
    method: "DELETE",
    path: "/api/products/:id/versions/:versionId",
    tag: "Versions",
    summary: "Remove a product version (admin)",
    auth: "admin",
    handler: async (ctx) => {
      await catalog.deleteVersion(ctx.params.versionId);
      return { deleted: true };
    },
  },

  /* -------------------------------- categories ------------------------------- */
  {
    method: "GET",
    path: "/api/categories",
    tag: "Categories",
    summary: "List categories with product counts",
    auth: "public",
    handler: async (ctx) => ({
      items: await catalog.listCategories(
        ctx.user?.role === "Admin" && ctx.query.get("includeInactive") === "true",
      ),
    }),
  },
  {
    method: "POST",
    path: "/api/categories",
    tag: "Categories",
    summary: "Create a category (admin)",
    auth: "admin",
    handler: async (ctx) => catalog.createCategory(await ctx.body(categorySchema)),
  },
  {
    method: "PATCH",
    path: "/api/categories/:id",
    tag: "Categories",
    summary: "Update a category (admin)",
    auth: "admin",
    handler: async (ctx) => catalog.updateCategory(ctx.params.id, await ctx.body(categorySchema.partial())),
  },
  {
    method: "DELETE",
    path: "/api/categories/:id",
    tag: "Categories",
    summary: "Delete an unused category (admin)",
    auth: "admin",
    handler: async (ctx) => {
      await catalog.deleteCategory(ctx.params.id);
      return { deleted: true };
    },
  },

  /* ----------------------------------- cart ---------------------------------- */
  {
    method: "GET",
    path: "/api/cart",
    tag: "Cart",
    summary: "Current cart with pricing preview",
    auth: "public",
    handler: async (ctx) => {
      const { sessionKey, userId } = cartSessionOf(ctx);
      return commerce.getCart(sessionKey, userId, ctx.query.get("discountCode"));
    },
  },
  {
    method: "POST",
    path: "/api/cart/items",
    tag: "Cart",
    summary: "Add a plan to the cart",
    auth: "public",
    handler: async (ctx) => {
      const { sessionKey, userId } = cartSessionOf(ctx);
      const input = await ctx.body(
        z.object({ planId: uuid, quantity: z.number().int().min(1).max(50).default(1) }),
      );
      return commerce.addToCart(sessionKey, userId, input.planId, input.quantity);
    },
  },
  {
    method: "PATCH",
    path: "/api/cart/items/:itemId",
    tag: "Cart",
    summary: "Change the quantity of a cart line",
    auth: "public",
    handler: async (ctx) => {
      const { sessionKey, userId } = cartSessionOf(ctx);
      const input = await ctx.body(z.object({ quantity: z.number().int().min(0).max(50) }));
      return commerce.updateCartItem(sessionKey, userId, ctx.params.itemId, input.quantity);
    },
  },
  {
    method: "DELETE",
    path: "/api/cart/items/:itemId",
    tag: "Cart",
    summary: "Remove a cart line",
    auth: "public",
    handler: async (ctx) => {
      const { sessionKey, userId } = cartSessionOf(ctx);
      return commerce.removeCartItem(sessionKey, userId, ctx.params.itemId);
    },
  },
  {
    method: "POST",
    path: "/api/cart/discount",
    tag: "Cart",
    summary: "Validate a discount code against the current cart",
    auth: "public",
    handler: async (ctx) => {
      const { sessionKey, userId } = cartSessionOf(ctx);
      const input = await ctx.body(z.object({ code: z.string().min(2) }));
      return commerce.getCart(sessionKey, userId, input.code);
    },
  },

  /* ------------------------------ discount codes ----------------------------- */
  {
    method: "GET",
    path: "/api/discount-codes",
    tag: "DiscountCodes",
    summary: "List discount codes (admin)",
    auth: "admin",
    handler: async () => ({ items: await commerce.listDiscountCodes() }),
  },
  {
    method: "POST",
    path: "/api/discount-codes",
    tag: "DiscountCodes",
    summary: "Create a discount code (admin)",
    auth: "admin",
    handler: async (ctx) =>
      commerce.createDiscountCode(
        await ctx.body(
          z.object({
            code: z.string().min(3).max(24),
            description: z.string().optional().nullable(),
            percentOff: z.number().int().min(1).max(100),
            maxRedemptions: z.number().int().min(0).optional(),
            expiresAt: z.string().optional().nullable(),
            isActive: z.boolean().optional(),
          }),
        ),
      ),
  },
  {
    method: "PATCH",
    path: "/api/discount-codes/:id",
    tag: "DiscountCodes",
    summary: "Update a discount code (admin)",
    auth: "admin",
    handler: async (ctx) =>
      commerce.updateDiscountCode(
        ctx.params.id,
        await ctx.body(
          z.object({
            description: z.string().optional().nullable(),
            percentOff: z.number().int().min(1).max(100).optional(),
            maxRedemptions: z.number().int().min(0).optional(),
            expiresAt: z.string().optional().nullable(),
            isActive: z.boolean().optional(),
          }),
        ),
      ),
  },
  {
    method: "DELETE",
    path: "/api/discount-codes/:id",
    tag: "DiscountCodes",
    summary: "Delete a discount code (admin)",
    auth: "admin",
    handler: async (ctx) => {
      await commerce.deleteDiscountCode(ctx.params.id);
      return { deleted: true };
    },
  },

  /* ---------------------------------- orders --------------------------------- */
  {
    method: "GET",
    path: "/api/orders",
    tag: "Orders",
    summary: "List orders (own for customers, all for admins)",
    auth: "user",
    handler: async (ctx) => {
      const user = ctx.requireUser();
      const base = ctx.list({ defaultSort: "newest", filters: ["status", "customerId"] });
      const result = await commerce.listOrders({
        userId: user.role === "Admin" ? base.filters.customerId : user.id,
        status: base.filters.status as never,
        search: base.search,
        page: base.page,
        pageSize: base.pageSize,
      });
      return { items: result.items, meta: ctx.meta(base.page, base.pageSize, result.total) };
    },
  },
  {
    method: "POST",
    path: "/api/orders",
    tag: "Orders",
    summary: "Checkout the current cart (creates order, payment, invoice, licenses)",
    auth: "user",
    handler: async (ctx) => {
      const user = ctx.requireUser();
      const input = await ctx.body(checkoutSchema);
      return commerce.checkout({
        userId: user.id,
        sessionKey: ctx.cartSession,
        discountCode: input.discountCode,
        paymentMethod: input.paymentMethod,
        cardName: input.cardName,
        cardLast4: input.cardNumber?.replace(/\D/g, "").slice(-4),
        billing: input.billing,
        notes: input.notes,
      });
    },
  },
  {
    method: "GET",
    path: "/api/orders/:id",
    tag: "Orders",
    summary: "Order detail with line items",
    auth: "user",
    handler: async (ctx) => {
      const user = ctx.requireUser();
      return commerce.getOrder(ctx.params.id, user.role === "Admin" ? undefined : user.id);
    },
  },
  {
    method: "PATCH",
    path: "/api/orders/:id",
    tag: "Orders",
    summary: "Change order status (admin)",
    auth: "admin",
    handler: async (ctx) => {
      const input = await ctx.body(
        z.object({
          status: z.enum(["Pending", "Paid", "Processing", "Completed", "Refunded", "Cancelled"]),
        }),
      );
      return commerce.updateOrderStatus(ctx.params.id, input.status);
    },
  },

  /* --------------------------------- payments -------------------------------- */
  {
    method: "GET",
    path: "/api/payments",
    tag: "Payments",
    summary: "Payment state for an order",
    auth: "user",
    handler: async (ctx) => {
      const user = ctx.requireUser();
      const orderId = ctx.query.get("orderId");
      if (!orderId) throw new HttpError(400, "missing_order", "orderId query parameter is required.");
      const order = await commerce.getOrder(orderId, user.role === "Admin" ? undefined : user.id);
      return { order };
    },
  },
  {
    method: "POST",
    path: "/api/payments",
    tag: "Payments",
    summary: "Re-attempt payment for a pending order (mock gateway)",
    auth: "user",
    handler: async (ctx) => {
      const user = ctx.requireUser();
      const input = await ctx.body(
        z.object({
          orderId: uuid,
          method: z.enum(["card", "invoice", "bank-transfer"]).default("card"),
        }),
      );
      await commerce.getOrder(input.orderId, user.role === "Admin" ? undefined : user.id);
      const updated = await commerce.updateOrderStatus(input.orderId, "Paid");
      return { order: updated, transactionRef: `txn_retry_${Date.now()}` };
    },
  },

  /* --------------------------------- licenses -------------------------------- */
  {
    method: "GET",
    path: "/api/licenses",
    tag: "Licenses",
    summary: "List licenses (own for customers, all for admins)",
    auth: "user",
    handler: async (ctx) => {
      const user = ctx.requireUser();
      const base = ctx.list({ defaultSort: "newest", filters: ["status", "customerId"] });
      const result = await commerce.listLicenses({
        userId: user.role === "Admin" ? base.filters.customerId : user.id,
        status: base.filters.status as never,
        search: base.search,
        page: base.page,
        pageSize: base.pageSize,
      });
      return { items: result.items, meta: ctx.meta(base.page, base.pageSize, result.total) };
    },
  },
  {
    method: "POST",
    path: "/api/licenses",
    tag: "Licenses",
    summary: "Manually generate a license (admin)",
    auth: "admin",
    handler: async (ctx) =>
      commerce.generateLicense(
        await ctx.body(
          z.object({
            userId: uuid,
            productId: uuid,
            planId: uuid.optional().nullable(),
            seats: z.number().int().min(1).max(5000).default(1),
            validDays: z.number().int().min(0).max(3650).optional().nullable(),
          }),
        ),
      ),
  },
  {
    method: "PATCH",
    path: "/api/licenses/:id",
    tag: "Licenses",
    summary: "Revoke, reactivate, extend or activate a license",
    auth: "user",
    handler: async (ctx) => {
      const user = ctx.requireUser();
      const input = await ctx.body(
        z.object({
          action: z.enum(["revoke", "extend", "reactivate", "activate"]),
          days: z.number().int().min(1).max(3650).optional(),
          machineName: z.string().optional(),
        }),
      );
      const [license] = await db.select().from(licenses).where(eq(licenses.id, ctx.params.id)).limit(1);
      if (!license) throw notFound("License");
      if (user.role !== "Admin" && license.userId !== user.id) throw forbidden();
      if (user.role !== "Admin" && (input.action === "revoke" || input.action === "reactivate")) {
        throw forbidden();
      }
      return commerce.licenseAction(ctx.params.id, input.action, {
        days: input.days,
        machineName: input.machineName,
      });
    },
  },

  /* -------------------------------- downloads -------------------------------- */
  {
    method: "GET",
    path: "/api/downloads/available",
    tag: "Downloads",
    summary: "Installers available to the current user",
    auth: "user",
    handler: async (ctx) => ({ items: await commerce.listAvailableDownloads(ctx.requireUser().id) }),
  },
  {
    method: "GET",
    path: "/api/downloads",
    tag: "Downloads",
    summary: "Download history for the current user",
    auth: "user",
    handler: async (ctx) => ({ items: await commerce.listDownloadHistory(ctx.requireUser().id) }),
  },
  {
    method: "POST",
    path: "/api/downloads",
    tag: "Downloads",
    summary: "Register a download and return the installer manifest",
    auth: "public",
    handler: async (ctx) => {
      const input = await ctx.body(
        z.object({
          productId: uuid,
          versionId: uuid.optional().nullable(),
          kind: z.enum(["installer", "manual", "trial"]).default("installer"),
          fileName: z.string().min(3),
          sizeMb: z.number().int().min(0).optional(),
        }),
      );
      const download = await commerce.recordDownload({
        userId: ctx.user?.id ?? null,
        productId: input.productId,
        versionId: input.versionId ?? null,
        kind: input.kind,
        fileName: input.fileName,
        sizeMb: input.sizeMb,
      });
      return {
        download,
        manifest: {
          product: download.productName,
          file: input.fileName,
          issuedTo: ctx.user?.email ?? "trial-user",
          licenseKey: "TRIAL",
          checksum: Math.random().toString(36).slice(2, 10).toUpperCase(),
        },
      };
    },
  },

  /* --------------------------------- invoices -------------------------------- */
  {
    method: "GET",
    path: "/api/invoices",
    tag: "Invoices",
    summary: "List invoices (own for customers, all for admins)",
    auth: "user",
    handler: async (ctx) => {
      const user = ctx.requireUser();
      const base = ctx.list({ defaultSort: "newest" });
      const result = await commerce.listInvoices({
        userId: user.role === "Admin" ? undefined : user.id,
        page: base.page,
        pageSize: base.pageSize,
      });
      return { items: result.items, meta: ctx.meta(base.page, base.pageSize, result.total) };
    },
  },
  {
    method: "GET",
    path: "/api/invoices/:id",
    tag: "Invoices",
    summary: "Invoice detail with its order",
    auth: "user",
    handler: async (ctx) => {
      const user = ctx.requireUser();
      const { items } = await commerce.listInvoices({ page: 1, pageSize: 500 });
      const invoice = items.find((i) => i.id === ctx.params.id || i.invoiceNumber === ctx.params.id);
      if (!invoice) throw notFound("Invoice");
      if (user.role !== "Admin") {
        const owned = await commerce.getOrder(invoice.orderId, user.id).catch(() => null);
        if (!owned) throw forbidden();
      }
      const order = await commerce.getOrder(invoice.orderId);
      return { invoice, order };
    },
  },

  /* ---------------------------------- tickets -------------------------------- */
  {
    method: "GET",
    path: "/api/tickets",
    tag: "Tickets",
    summary: "List support tickets (own for customers, all for admins)",
    auth: "user",
    handler: async (ctx) => {
      const user = ctx.requireUser();
      const base = ctx.list({ defaultSort: "newest", filters: ["status", "priority", "customerId"] });
      const result = await support.listTickets({
        userId: user.role === "Admin" ? base.filters.customerId : user.id,
        status: base.filters.status as never,
        priority: base.filters.priority as never,
        search: base.search,
        page: base.page,
        pageSize: base.pageSize,
      });
      return { items: result.items, meta: ctx.meta(base.page, base.pageSize, result.total) };
    },
  },
  {
    method: "POST",
    path: "/api/tickets",
    tag: "Tickets",
    summary: "Open a new support ticket",
    auth: "user",
    handler: async (ctx) => {
      const user = ctx.requireUser();
      const input = await ctx.body(ticketSchema);
      return support.createTicket({ ...input, userId: user.id });
    },
  },
  {
    method: "GET",
    path: "/api/tickets/:id",
    tag: "Tickets",
    summary: "Ticket thread",
    auth: "user",
    handler: async (ctx) => {
      const user = ctx.requireUser();
      return support.getTicket(ctx.params.id, user.role === "Admin" ? undefined : user.id);
    },
  },
  {
    method: "POST",
    path: "/api/tickets/:id/messages",
    tag: "Tickets",
    summary: "Reply to a ticket",
    auth: "user",
    handler: async (ctx) => {
      const user = ctx.requireUser();
      const input = await ctx.body(
        z.object({
          body: z.string().min(2),
          status: z.enum(["Open", "InProgress", "WaitingCustomer", "Resolved", "Closed"]).optional(),
        }),
      );
      const ticket = await support.getTicket(ctx.params.id, user.role === "Admin" ? undefined : user.id);
      return support.addTicketMessage({
        ticketId: ticket.id,
        authorId: user.id,
        authorName: user.role === "Admin" ? `${user.name} (Support)` : "You",
        isStaff: user.role === "Admin",
        body: input.body,
        newStatus: input.status ?? (user.role === "Admin" ? "WaitingCustomer" : "InProgress"),
      });
    },
  },
  {
    method: "PATCH",
    path: "/api/tickets/:id",
    tag: "Tickets",
    summary: "Change ticket status or priority (admin)",
    auth: "admin",
    handler: async (ctx) => {
      const input = await ctx.body(
        z.object({
          status: z.enum(["Open", "InProgress", "WaitingCustomer", "Resolved", "Closed"]).optional(),
          priority: z.enum(["Low", "Normal", "High", "Critical"]).optional(),
        }),
      );
      return support.updateTicket(ctx.params.id, input);
    },
  },

  /* ---------------------------------- reviews -------------------------------- */
  {
    method: "GET",
    path: "/api/reviews",
    tag: "Reviews",
    summary: "List reviews, optionally filtered by product or status",
    auth: "public",
    handler: async (ctx) => {
      const base = ctx.list({ defaultSort: "newest", filters: ["productId", "status"] });
      const result = await catalog.listReviews({
        productId: base.filters.productId,
        status: base.filters.status as never,
        page: base.page,
        pageSize: base.pageSize,
      });
      return { items: result.items, meta: ctx.meta(base.page, base.pageSize, result.total) };
    },
  },
  {
    method: "POST",
    path: "/api/reviews",
    tag: "Reviews",
    summary: "Submit a product review (queued for moderation)",
    auth: "user",
    handler: async (ctx) => {
      const user = ctx.requireUser();
      const input = await ctx.body(reviewSchema);
      return catalog.createReview({
        productId: input.productId,
        userId: user.id,
        authorName: user.name || user.email,
        authorCompany: input.authorCompany ?? null,
        rating: input.rating,
        title: input.title,
        body: input.body,
      });
    },
  },
  {
    method: "PATCH",
    path: "/api/reviews/:id",
    tag: "Reviews",
    summary: "Approve or reject a review (admin)",
    auth: "admin",
    handler: async (ctx) => {
      const input = await ctx.body(z.object({ status: z.enum(["Pending", "Approved", "Rejected"]) }));
      return catalog.moderateReview(ctx.params.id, input.status);
    },
  },
  {
    method: "DELETE",
    path: "/api/reviews/:id",
    tag: "Reviews",
    summary: "Delete a review (admin)",
    auth: "admin",
    handler: async (ctx) => {
      await catalog.deleteReview(ctx.params.id);
      return { deleted: true };
    },
  },

  /* --------------------------------- customers ------------------------------- */
  {
    method: "GET",
    path: "/api/customers",
    tag: "Customers",
    summary: "Paged customer directory with spend stats (admin)",
    auth: "admin",
    handler: async (ctx) => {
      const base = ctx.list({ defaultSort: "newest", filters: ["role"] });
      const result = await support.listCustomers({
        search: base.search,
        role: base.filters.role,
        page: base.page,
        pageSize: base.pageSize,
      });
      return { items: result.items, meta: ctx.meta(base.page, base.pageSize, result.total) };
    },
  },
  {
    method: "PATCH",
    path: "/api/customers/:id",
    tag: "Customers",
    summary: "Update a customer (admin)",
    auth: "admin",
    handler: async (ctx) =>
      support.updateCustomer(
        ctx.params.id,
        await ctx.body(
          z.object({
            fullName: z.string().min(2).optional(),
            company: z.string().optional().nullable(),
            phone: z.string().optional().nullable(),
            country: z.string().optional().nullable(),
            role: z.enum(["Admin", "Customer"]).optional(),
            isLocked: z.boolean().optional(),
          }),
        ),
      ),
  },
  {
    method: "DELETE",
    path: "/api/customers/:id",
    tag: "Customers",
    summary: "Delete a customer (admin)",
    auth: "admin",
    handler: async (ctx) => {
      await support.deleteCustomer(ctx.params.id);
      return { deleted: true };
    },
  },

  /* ---------------------------------- reports -------------------------------- */
  {
    method: "GET",
    path: "/api/reports/admin",
    tag: "Dashboard",
    summary: "Admin KPIs, revenue series and top products",
    auth: "admin",
    handler: async () => support.adminOverview(),
  },
  {
    method: "GET",
    path: "/api/reports/customer",
    tag: "Dashboard",
    summary: "Customer portal summary",
    auth: "user",
    handler: async (ctx) => support.customerOverview(ctx.requireUser().id),
  },

  /* --------------------------------- settings -------------------------------- */
  {
    method: "GET",
    path: "/api/settings",
    tag: "Settings",
    summary: "Public site settings",
    auth: "public",
    handler: async () => catalog.getSettings(),
  },
  {
    method: "PUT",
    path: "/api/settings",
    tag: "Settings",
    summary: "Update site settings (admin)",
    auth: "admin",
    handler: async (ctx) =>
      catalog.updateSettings(
        await ctx.body(
          z.object({
            siteName: z.string().min(2),
            supportEmail: z.string().email(),
            salesEmail: z.string().email(),
            supportPhone: z.string().min(4),
            heroHeadline: z.string().min(4),
            heroSubheading: z.string(),
            taxRateBps: z.number().int().min(0).max(10_000),
            trialDays: z.number().int().min(0).max(365),
            maintenanceMode: z.boolean(),
            announcement: z.string(),
          }),
        ),
      ),
  },

  /* ---------------------------------- content -------------------------------- */
  {
    method: "GET",
    path: "/api/content/testimonials",
    tag: "Content",
    summary: "Published testimonials",
    auth: "public",
    handler: async () => ({ items: await catalog.listTestimonials() }),
  },
  {
    method: "GET",
    path: "/api/content/faqs",
    tag: "Content",
    summary: "Frequently asked questions",
    auth: "public",
    handler: async () => ({ items: await catalog.listFaqs() }),
  },
  {
    method: "POST",
    path: "/api/contact",
    tag: "Content",
    summary: "Submit the contact form",
    auth: "public",
    handler: async (ctx) =>
      support.createContactMessage(
        await ctx.body(
          z.object({
            name: z.string().min(2),
            email: z.string().email(),
            company: z.string().optional().nullable(),
            topic: z.enum(["General", "Sales", "Support", "Partnership"]),
            message: z.string().min(10),
          }),
        ),
      ),
  },
  {
    method: "POST",
    path: "/api/demos",
    tag: "Content",
    summary: "Request a guided product demo",
    auth: "public",
    handler: async (ctx) =>
      support.createDemoRequest(
        await ctx.body(
          z.object({
            productId: uuid.optional().nullable(),
            name: z.string().min(2),
            email: z.string().email(),
            company: z.string().optional().nullable(),
            companySize: z.string().optional().nullable(),
            message: z.string().optional().nullable(),
          }),
        ),
      ),
  },

  /* ---------------------------------- openapi -------------------------------- */
  {
    method: "GET",
    path: "/api/openapi",
    tag: "System",
    summary: "OpenAPI 3.0 document for this API",
    auth: "public",
    handler: async () => buildOpenApiDocument(),
  },
];

/* --------------------------- OpenAPI document ------------------------------ */

function buildOpenApiDocument() {
  const paths: Record<string, Record<string, unknown>> = {};
  for (const route of routes) {
    const openApiPath = route.path.replace(/:(\w+)/g, "{$1}");
    paths[openApiPath] = paths[openApiPath] ?? {};
    paths[openApiPath][route.method.toLowerCase()] = {
      tags: [route.tag],
      summary: route.summary,
      security: route.auth === "public" ? [] : [{ bearerAuth: [] }],
      parameters:
        route.method === "GET"
          ? [
              { name: "page", in: "query", schema: { type: "integer" }, description: "Page number" },
              { name: "pageSize", in: "query", schema: { type: "integer" }, description: "Items per page" },
              { name: "search", in: "query", schema: { type: "string" }, description: "Free text search" },
              { name: "sortBy", in: "query", schema: { type: "string" }, description: "Sort key" },
              { name: "sortDir", in: "query", schema: { type: "string", enum: ["asc", "desc"] } },
            ]
          : [],
      responses: {
        "200": { description: "Success envelope" },
        "401": { description: "Unauthorized" },
        "403": { description: "Forbidden" },
        "422": { description: "Validation problem details" },
      },
    };
  }
  return {
    openapi: "3.0.3",
    info: {
      title: "Northwind Business Software Platform API",
      version: "1.0.0",
      description:
        "Storefront + customer portal API. All responses use the { success, data, meta, error } envelope. JWT bearer tokens with rotating refresh cookies.",
    },
    servers: [{ url: "/", description: "Current host" }],
    components: {
      securitySchemes: { bearerAuth: { type: "http", scheme: "bearer", bearerFormat: "JWT" } },
    },
    paths,
  };
}

/* -------------------------------- dispatcher ------------------------------- */

function matchRoute(method: string, segments: string[]) {
  for (const route of routes) {
    if (route.method !== method) continue;
    const routeSegments = route.path.split("/").filter(Boolean);
    if (routeSegments.length !== segments.length) continue;
    const params: Record<string, string> = {};
    let matched = true;
    for (let i = 0; i < routeSegments.length; i += 1) {
      const expected = routeSegments[i];
      const actual = segments[i];
      if (expected.startsWith(":")) params[expected.slice(1)] = decodeURIComponent(actual);
      else if (expected !== actual) {
        matched = false;
        break;
      }
    }
    if (matched) return { route, params };
  }
  return null;
}

export async function handleApiRequest(req: Request, pathSegments: string[]): Promise<Response> {
  if (req.method === "OPTIONS") return corsPreflight();

  const method = req.method.toUpperCase();
  const segments = ["api", ...pathSegments].filter(Boolean);
  const match = matchRoute(method, segments);

  if (!match) {
    return problem(
      new HttpError(404, "route_not_found", `No endpoint matches ${method} /${segments.join("/")}`),
    );
  }

  const url = new URL(req.url);
  const cookieJar = parseCookies(req.headers.get("cookie"));
  const authHeader = req.headers.get("authorization");
  let user: AuthUser | null = null;
  if (authHeader?.startsWith("Bearer ")) {
    const claims = verifyAccessToken(authHeader.slice(7).trim());
    if (claims) user = { id: claims.sub, email: claims.email, role: claims.role, name: claims.name };
  }

  let cartSession = req.headers.get("x-cart-session") ?? cookieJar.nw_cart ?? "";
  const cookies: string[] = [];
  let issuedCartSession = false;
  if (!cartSession) {
    cartSession = crypto.randomUUID();
    issuedCartSession = true;
    cookies.push(
      serializeCookie("nw_cart", cartSession, {
        httpOnly: true,
        path: "/",
        sameSite: "lax",
        maxAge: 60 * 60 * 24 * 30,
      }),
    );
  }

  const ctx: RouteContext = {
    req,
    method,
    params: match.params,
    query: url.searchParams,
    user,
    cookies,
    cartSession,
    body: <T,>(schema: ZodType<T>) => parseJson(req, schema),
    requireUser() {
      if (!user) throw new HttpError(401, "unauthorized", "You must sign in to do that.");
      return user;
    },
    requireAdmin() {
      const current = this.requireUser();
      if (current.role !== "Admin") throw forbidden();
      return current;
    },
    list(options) {
      const { defaultSort, allowedSorts, filters } = options ?? {};
      return listParams(url.searchParams, {
        defaultSort: defaultSort ?? "newest",
        allowedSorts:
          allowedSorts ?? ["newest", "oldest", "price-asc", "price-desc", "popular", "rating", "name"],
        filters: filters ?? ["category", "type", "status", "priority", "productId", "role", "featured"],
      });
    },
    meta: (page, pageSize, total) => pagedMeta(page, pageSize, total),
  };

  try {
    if (match.route.auth === "user") ctx.requireUser();
    if (match.route.auth === "admin") ctx.requireAdmin();

    const started = Date.now();
    const payload = await match.route.handler(ctx);

    // Handlers return `{ items, meta }` for collections — hoist `meta` to the
    // envelope root so every client reads pagination from one place.
    let body: unknown = payload;
    let meta: PagedMeta | undefined;
    if (
      payload &&
      typeof payload === "object" &&
      "meta" in payload &&
      typeof (payload as { meta?: unknown }).meta === "object" &&
      (payload as { meta?: unknown }).meta !== null &&
      "totalPages" in (payload as { meta: Record<string, unknown> }).meta
    ) {
      const { meta: extracted, ...rest } = payload as { meta: PagedMeta } & Record<string, unknown>;
      meta = extracted;
      body = rest;
    }

    const response = responseWithCookies(body, meta, cookies);
    logger.info("request_handled", {
      method,
      path: `/${segments.join("/")}`,
      status: response.status,
      elapsedMs: Date.now() - started,
      user: user?.email ?? "anonymous",
    });

    const headers = new Headers(response.headers);
    if (issuedCartSession) headers.set("x-cart-session", cartSession);
    return new Response(response.body, { status: response.status, headers });
  } catch (error) {
    logger.warn("request_failed", {
      method,
      path: `/${segments.join("/")}`,
      error: error instanceof Error ? error.message : String(error),
    });
    return problem(error);
  }
}

export const API_CONSTANTS = { ACCESS_TTL };
