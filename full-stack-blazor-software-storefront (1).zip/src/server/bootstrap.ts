import { logger } from "@/server/http";
import { isSeeded, resetAndSeed, seedDatabase } from "@/db/seed";

let seedPromise: Promise<void> | null = null;

/**
 * Guarantees the storefront has data on first load. Executed at most once per
 * server process (memoised promise) and never throws, so a partially
 * initialised database cannot take the API down.
 */
export async function ensureSeeded(force = false): Promise<void> {
  if (force) {
    await resetAndSeed();
    return;
  }
  if (!seedPromise) {
    seedPromise = (async () => {
      try {
        if (!(await isSeeded())) {
          await seedDatabase();
          logger.info("demo_data_seeded", { scope: "full-catalog" });
        }
      } catch (error) {
        logger.error("seed_failed", {
          error: error instanceof Error ? error.message : String(error),
        });
      }
    })();
  }
  return seedPromise;
}
