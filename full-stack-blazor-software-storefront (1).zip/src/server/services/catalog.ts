import { and, asc, count, desc, eq, ilike, inArray, or, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  categories,
  faqs,
  productPlans,
  productVersions,
  products,
  reviews,
  siteSettings,
  testimonials,
} from "@/db/schema";
import { notFound } from "@/server/http";
import type {
  CategoryDto,
  PlanDto,
  ProductDetailDto,
  ProductListItemDto,
  ProductType,
  ProductVersionDto,
  ReviewDto,
  ReviewStatus,
  SiteSettingsDto,
  TestimonialDto,
  FaqDto,
  PlanTier,
  BillingType,
} from "@/shared/contracts";

type ProductRow = typeof products.$inferSelect;
type PlanRow = typeof productPlans.$inferSelect;
type VersionRow = typeof productVersions.$inferSelect;
type ReviewRow = typeof reviews.$inferSelect;
type CategoryRow = typeof categories.$inferSelect;

export function toCategoryDto(row: CategoryRow, productCount?: number): CategoryDto {
  return {
    id: row.id,
    name: row.name,
    slug: row.slug,
    description: row.description,
    icon: row.icon,
    sortOrder: row.sortOrder,
    isActive: row.isActive,
    ...(productCount === undefined ? {} : { productCount }),
  };
}

export function toPlanDto(row: PlanRow): PlanDto {
  return {
    id: row.id,
    productId: row.productId,
    name: row.name,
    tier: row.tier,
    billingType: row.billingType,
    priceCents: row.priceCents,
    seats: row.seats,
    description: row.description,
    isPopular: row.isPopular,
    sortOrder: row.sortOrder,
  };
}

export function toVersionDto(row: VersionRow): ProductVersionDto {
  return {
    id: row.id,
    productId: row.productId,
    version: row.version,
    releasedAt: row.releasedAt.toISOString(),
    notes: row.notes,
    installerUrl: row.installerUrl,
    sizeMb: row.sizeMb,
    platform: row.platform,
  };
}

export function toReviewDto(row: ReviewRow, productName?: string): ReviewDto {
  return {
    id: row.id,
    productId: row.productId,
    ...(productName ? { productName } : {}),
    authorName: row.authorName,
    authorCompany: row.authorCompany,
    rating: row.rating,
    title: row.title,
    body: row.body,
    status: row.status,
    createdAt: row.createdAt.toISOString(),
  };
}

export function toListItem(
  row: ProductRow,
  categoryName: string,
  categorySlug: string,
): ProductListItemDto {
  return {
    id: row.id,
    slug: row.slug,
    name: row.name,
    tagline: row.tagline,
    type: row.type,
    platform: row.platform,
    version: row.version,
    basePriceCents: row.basePriceCents,
    ratingAvg: row.ratingAvg / 10,
    ratingCount: row.ratingCount,
    popularity: row.popularity,
    heroImage: row.heroImage,
    accentColor: row.accentColor,
    isFeatured: row.isFeatured,
    isActive: row.isActive,
    createdAt: row.createdAt.toISOString(),
    categoryName,
    categorySlug,
  };
}

const SORTS: Record<string, ReturnType<typeof desc> | ReturnType<typeof asc>> = {
  newest: desc(products.createdAt),
  oldest: asc(products.createdAt),
  "price-asc": asc(products.basePriceCents),
  "price-desc": desc(products.basePriceCents),
  popular: desc(products.popularity),
  rating: desc(products.ratingAvg),
  name: asc(products.name),
};

export interface ProductQuery {
  page: number;
  pageSize: number;
  search?: string | null;
  sortBy?: string | null;
  sortDir?: "asc" | "desc";
  filters?: Record<string, string>;
  categorySlug?: string;
  type?: ProductType | string;
  featured?: boolean;
  includeInactive?: boolean;
}

export async function listProducts(query: ProductQuery) {
  const conditions = [];
  if (!query.includeInactive) conditions.push(eq(products.isActive, true));
  if (query.search) {
    const like = `%${query.search}%`;
    conditions.push(
      or(ilike(products.name, like), ilike(products.tagline, like), ilike(products.description, like))!,
    );
  }
  if (query.categorySlug) conditions.push(eq(categories.slug, query.categorySlug));
  if (query.type && query.type !== "all") {
    conditions.push(eq(products.type, query.type as ProductType));
  }
  if (query.featured) conditions.push(eq(products.isFeatured, true));
  const where = conditions.length ? and(...conditions) : undefined;

  const orderExpr = SORTS[query.sortBy ?? "newest"] ?? SORTS.newest;
  const offset = (query.page - 1) * query.pageSize;

  const rows = await db
    .select({ product: products, categoryName: categories.name, categorySlug: categories.slug })
    .from(products)
    .innerJoin(categories, eq(products.categoryId, categories.id))
    .where(where)
    .orderBy(orderExpr, desc(products.name))
    .limit(query.pageSize)
    .offset(offset);

  const [totals] = await db
    .select({ value: count() })
    .from(products)
    .innerJoin(categories, eq(products.categoryId, categories.id))
    .where(where);

  return {
    items: rows.map((r) => toListItem(r.product, r.categoryName, r.categorySlug)),
    total: totals?.value ?? 0,
  };
}

export async function getProductBySlug(slug: string): Promise<ProductDetailDto> {
  const [row] = await db
    .select({ product: products, categoryName: categories.name, categorySlug: categories.slug })
    .from(products)
    .innerJoin(categories, eq(products.categoryId, categories.id))
    .where(eq(products.slug, slug))
    .limit(1);
  if (!row) throw notFound("Product");
  return hydrateProduct(row.product, row.categoryName, row.categorySlug);
}

export async function getProductById(id: string): Promise<ProductDetailDto> {
  const [row] = await db
    .select({ product: products, categoryName: categories.name, categorySlug: categories.slug })
    .from(products)
    .innerJoin(categories, eq(products.categoryId, categories.id))
    .where(eq(products.id, id))
    .limit(1);
  if (!row) throw notFound("Product");
  return hydrateProduct(row.product, row.categoryName, row.categorySlug);
}

export async function hydrateProduct(
  row: ProductRow,
  categoryName: string,
  categorySlug: string,
): Promise<ProductDetailDto> {
  const [plans, versions] = await Promise.all([
    db
      .select()
      .from(productPlans)
      .where(eq(productPlans.productId, row.id))
      .orderBy(asc(productPlans.sortOrder), asc(productPlans.priceCents)),
    db
      .select()
      .from(productVersions)
      .where(eq(productVersions.productId, row.id))
      .orderBy(desc(productVersions.releasedAt)),
  ]);
  return {
    ...toListItem(row, categoryName, categorySlug),
    description: row.description,
    gallery: row.gallery ?? [],
    features: row.features ?? [],
    systemRequirements: row.systemRequirements ?? [],
    demoVideoUrl: row.demoVideoUrl,
    trialDays: row.trialDays,
    categoryId: row.categoryId,
    plans: plans.map(toPlanDto),
    versions: versions.map(toVersionDto),
  };
}

export async function getProductsByIds(ids: string[]): Promise<ProductDetailDto[]> {
  if (!ids.length) return [];
  const rows = await db
    .select({ product: products, categoryName: categories.name, categorySlug: categories.slug })
    .from(products)
    .innerJoin(categories, eq(products.categoryId, categories.id))
    .where(inArray(products.id, ids));
  const hydrated = await Promise.all(
    rows.map((r) => hydrateProduct(r.product, r.categoryName, r.categorySlug)),
  );
  const order = new Map(ids.map((id, i) => [id, i]));
  return hydrated.sort((a, b) => (order.get(a.id) ?? 0) - (order.get(b.id) ?? 0));
}

/* ----------------------------- categories ---------------------------- */

export async function listCategories(includeInactive = false): Promise<CategoryDto[]> {
  const rows = await db
    .select({ category: categories, productCount: sql<number>`count(${products.id})::int` })
    .from(categories)
    .leftJoin(products, and(eq(products.categoryId, categories.id), eq(products.isActive, true)))
    .where(includeInactive ? undefined : eq(categories.isActive, true))
    .groupBy(categories.id)
    .orderBy(asc(categories.sortOrder), asc(categories.name));
  return rows.map((r) => toCategoryDto(r.category, Number(r.productCount)));
}

export async function createCategory(input: {
  name: string;
  slug: string;
  description?: string | null;
  icon?: string;
  sortOrder?: number;
  isActive?: boolean;
}): Promise<CategoryDto> {
  const [row] = await db
    .insert(categories)
    .values({
      name: input.name,
      slug: input.slug,
      description: input.description ?? null,
      icon: input.icon ?? "package",
      sortOrder: input.sortOrder ?? 0,
      isActive: input.isActive ?? true,
    })
    .returning();
  return toCategoryDto(row);
}

export async function updateCategory(
  id: string,
  input: Partial<{
    name: string;
    slug: string;
    description: string | null;
    icon: string;
    sortOrder: number;
    isActive: boolean;
  }>,
): Promise<CategoryDto> {
  const [row] = await db
    .update(categories)
    .set({ ...input })
    .where(eq(categories.id, id))
    .returning();
  if (!row) throw notFound("Category");
  return toCategoryDto(row);
}

export async function deleteCategory(id: string): Promise<void> {
  const [used] = await db.select({ value: count() }).from(products).where(eq(products.categoryId, id));
  if ((used?.value ?? 0) > 0) {
    throw notFound("Category is used by products and cannot be deleted");
  }
  await db.delete(categories).where(eq(categories.id, id));
}

/* ------------------------------ products ----------------------------- */

export async function createProduct(input: {
  name: string;
  slug: string;
  tagline: string;
  description: string;
  categoryId: string;
  type: ProductType;
  platform: string;
  version: string;
  basePriceCents: number;
  heroImage?: string | null;
  accentColor?: string;
  features?: string[];
  systemRequirements?: string[];
  demoVideoUrl?: string | null;
  trialDays?: number;
  isFeatured?: boolean;
  isActive?: boolean;
}): Promise<ProductDetailDto> {
  const [row] = await db
    .insert(products)
    .values({
      ...input,
      heroImage: input.heroImage ?? null,
      accentColor: input.accentColor ?? "#4f46e5",
      features: input.features ?? [],
      systemRequirements: input.systemRequirements ?? [],
      demoVideoUrl: input.demoVideoUrl ?? null,
      trialDays: input.trialDays ?? 30,
      isFeatured: input.isFeatured ?? false,
      isActive: input.isActive ?? true,
    })
    .returning();
  return getProductById(row.id);
}

export async function updateProduct(
  id: string,
  input: Partial<{
    name: string;
    slug: string;
    tagline: string;
    description: string;
    categoryId: string;
    type: ProductType;
    platform: string;
    version: string;
    basePriceCents: number;
    heroImage: string | null;
    accentColor: string;
    features: string[];
    systemRequirements: string[];
    demoVideoUrl: string | null;
    trialDays: number;
    isFeatured: boolean;
    isActive: boolean;
    popularity: number;
  }>,
): Promise<ProductDetailDto> {
  const [row] = await db
    .update(products)
    .set({ ...input, updatedAt: new Date() })
    .where(eq(products.id, id))
    .returning();
  if (!row) throw notFound("Product");
  return getProductById(row.id);
}

export async function deleteProduct(id: string): Promise<void> {
  await db.delete(products).where(eq(products.id, id));
}

/* -------------------------------- plans ------------------------------ */

export async function createPlan(input: {
  productId: string;
  name: string;
  tier: PlanTier;
  billingType: BillingType;
  priceCents: number;
  seats: number;
  description?: string | null;
  isPopular?: boolean;
  sortOrder?: number;
}): Promise<PlanDto> {
  const [row] = await db.insert(productPlans).values(input).returning();
  return toPlanDto(row);
}

export async function updatePlan(
  id: string,
  input: Partial<{
    name: string;
    tier: PlanTier;
    billingType: BillingType;
    priceCents: number;
    seats: number;
    description: string | null;
    isPopular: boolean;
    sortOrder: number;
  }>,
): Promise<PlanDto> {
  const [row] = await db.update(productPlans).set(input).where(eq(productPlans.id, id)).returning();
  if (!row) throw notFound("Plan");
  return toPlanDto(row);
}

export async function deletePlan(id: string): Promise<void> {
  await db.delete(productPlans).where(eq(productPlans.id, id));
}

/* ------------------------------ versions ----------------------------- */

export async function createVersion(input: {
  productId: string;
  version: string;
  releasedAt: string;
  notes: string;
  installerUrl?: string | null;
  sizeMb?: number;
  platform?: string;
}): Promise<ProductVersionDto> {
  const [row] = await db
    .insert(productVersions)
    .values({
      productId: input.productId,
      version: input.version,
      releasedAt: new Date(input.releasedAt),
      notes: input.notes,
      installerUrl: input.installerUrl ?? null,
      sizeMb: input.sizeMb ?? 0,
      platform: input.platform ?? "Windows",
    })
    .returning();
  await syncProductVersion(input.productId);
  return toVersionDto(row);
}

export async function deleteVersion(id: string): Promise<void> {
  const [row] = await db.select().from(productVersions).where(eq(productVersions.id, id)).limit(1);
  if (!row) throw notFound("Version");
  await db.delete(productVersions).where(eq(productVersions.id, id));
  await syncProductVersion(row.productId);
}

async function syncProductVersion(productId: string) {
  const [latest] = await db
    .select()
    .from(productVersions)
    .where(eq(productVersions.productId, productId))
    .orderBy(desc(productVersions.releasedAt))
    .limit(1);
  if (latest) {
    await db
      .update(products)
      .set({ version: latest.version, updatedAt: new Date() })
      .where(eq(products.id, productId));
  }
}

/* ------------------------------ reviews ------------------------------ */

export async function listReviews(query: {
  productId?: string;
  status?: ReviewStatus | "all";
  page: number;
  pageSize: number;
}) {
  const conditions = [];
  if (query.productId) conditions.push(eq(reviews.productId, query.productId));
  if (query.status && query.status !== "all") conditions.push(eq(reviews.status, query.status));
  const where = conditions.length ? and(...conditions) : undefined;

  const rows = await db
    .select({ review: reviews, productName: products.name })
    .from(reviews)
    .innerJoin(products, eq(reviews.productId, products.id))
    .where(where)
    .orderBy(desc(reviews.createdAt))
    .limit(query.pageSize)
    .offset((query.page - 1) * query.pageSize);
  const [total] = await db.select({ value: count() }).from(reviews).where(where);
  return {
    items: rows.map((r) => toReviewDto(r.review, r.productName)),
    total: total?.value ?? 0,
  };
}

export async function createReview(input: {
  productId: string;
  userId: string;
  authorName: string;
  authorCompany?: string | null;
  rating: number;
  title: string;
  body: string;
}): Promise<ReviewDto> {
  const [row] = await db
    .insert(reviews)
    .values({ ...input, status: "Pending" })
    .returning();
  return toReviewDto(row);
}

export async function moderateReview(id: string, status: ReviewStatus): Promise<ReviewDto> {
  const [row] = await db.update(reviews).set({ status }).where(eq(reviews.id, id)).returning();
  if (!row) throw notFound("Review");
  await recalcProductRating(row.productId);
  return toReviewDto(row);
}

export async function deleteReview(id: string): Promise<void> {
  const [row] = await db.select().from(reviews).where(eq(reviews.id, id)).limit(1);
  if (!row) throw notFound("Review");
  await db.delete(reviews).where(eq(reviews.id, id));
  await recalcProductRating(row.productId);
}

export async function recalcProductRating(productId: string) {
  const [agg] = await db
    .select({
      avg: sql<number>`coalesce(round(avg(${reviews.rating}) * 10), 0)::int`,
      total: count(),
    })
    .from(reviews)
    .where(and(eq(reviews.productId, productId), eq(reviews.status, "Approved")));
  await db
    .update(products)
    .set({ ratingAvg: agg?.avg ?? 0, ratingCount: agg?.total ?? 0 })
    .where(eq(products.id, productId));
}

/* ------------------------- content & settings ------------------------ */

export async function getSettings(): Promise<SiteSettingsDto> {
  const [row] = await db.select().from(siteSettings).where(eq(siteSettings.id, 1)).limit(1);
  if (!row) {
    const [created] = await db.insert(siteSettings).values({ id: 1 }).returning();
    return toSettingsDto(created);
  }
  return toSettingsDto(row);
}

export function toSettingsDto(row: typeof siteSettings.$inferSelect): SiteSettingsDto {
  return {
    siteName: row.siteName,
    supportEmail: row.supportEmail,
    salesEmail: row.salesEmail,
    supportPhone: row.supportPhone,
    heroHeadline: row.heroHeadline,
    heroSubheading: row.heroSubheading,
    taxRateBps: row.taxRateBps,
    trialDays: row.trialDays,
    maintenanceMode: row.maintenanceMode,
    announcement: row.announcement,
  };
}

export async function updateSettings(
  input: Partial<{
    siteName: string;
    supportEmail: string;
    salesEmail: string;
    supportPhone: string;
    heroHeadline: string;
    heroSubheading: string;
    taxRateBps: number;
    trialDays: number;
    maintenanceMode: boolean;
    announcement: string;
  }>,
): Promise<SiteSettingsDto> {
  await getSettings();
  const [row] = await db
    .update(siteSettings)
    .set({ ...input, updatedAt: new Date() })
    .where(eq(siteSettings.id, 1))
    .returning();
  return toSettingsDto(row);
}

export async function listTestimonials(): Promise<TestimonialDto[]> {
  const rows = await db.select().from(testimonials).orderBy(asc(testimonials.sortOrder)).limit(9);
  return rows.map((r) => ({
    id: r.id,
    authorName: r.authorName,
    authorRole: r.authorRole,
    company: r.company,
    quote: r.quote,
    rating: r.rating,
  }));
}

export async function listFaqs(): Promise<FaqDto[]> {
  const rows = await db.select().from(faqs).orderBy(asc(faqs.sortOrder)).limit(12);
  return rows.map((r) => ({ id: r.id, question: r.question, answer: r.answer }));
}
