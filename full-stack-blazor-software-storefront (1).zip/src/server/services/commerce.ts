import { and, asc, count, desc, eq, ilike, inArray, lt, or, sql } from "drizzle-orm";
import { randomBytes } from "node:crypto";
import { db } from "@/db";
import {
  cartItems,
  carts,
  discountCodes,
  downloads,
  invoices,
  licenseActivations,
  licenses,
  orderItems,
  orders,
  payments,
  productPlans,
  productVersions,
  products,
  users,
} from "@/db/schema";
import { HttpError, logger, notFound } from "@/server/http";
import { getSettings } from "@/server/services/catalog";
import type {
  AvailableDownloadDto,
  CartDto,
  CartItemDto,
  DiscountCodeDto,
  DownloadDto,
  InvoiceDto,
  LicenseDto,
  LicenseStatus,
  OrderDto,
  OrderStatus,
} from "@/shared/contracts";

/* --------------------------------- cart --------------------------------- */

async function resolveCart(sessionKey: string, userId: string | null) {
  const [sessionCart] = await db.select().from(carts).where(eq(carts.sessionKey, sessionKey)).limit(1);

  if (!userId) {
    if (sessionCart) return sessionCart;
    const [created] = await db.insert(carts).values({ sessionKey }).returning();
    return created;
  }

  const [userCart] = await db
    .select()
    .from(carts)
    .where(eq(carts.userId, userId))
    .orderBy(desc(carts.createdAt))
    .limit(1);

  if (!userCart) {
    if (sessionCart) {
      const [attached] = await db
        .update(carts)
        .set({ userId })
        .where(eq(carts.id, sessionCart.id))
        .returning();
      return attached;
    }
    const [created] = await db.insert(carts).values({ sessionKey, userId }).returning();
    return created;
  }

  if (sessionCart && sessionCart.id !== userCart.id) {
    const guestItems = await db.select().from(cartItems).where(eq(cartItems.cartId, sessionCart.id));
    const existing = await db.select().from(cartItems).where(eq(cartItems.cartId, userCart.id));
    const existingPlans = new Set(existing.map((i) => i.planId));
    for (const item of guestItems) {
      if (existingPlans.has(item.planId)) {
        await db.delete(cartItems).where(eq(cartItems.id, item.id));
      } else {
        await db.update(cartItems).set({ cartId: userCart.id }).where(eq(cartItems.id, item.id));
      }
    }
    await db.delete(carts).where(eq(carts.id, sessionCart.id));
  }

  if (userCart.sessionKey !== sessionKey) {
    const [updated] = await db
      .update(carts)
      .set({ sessionKey })
      .where(eq(carts.id, userCart.id))
      .returning();
    return updated;
  }
  return userCart;
}

function toCartItemDto(
  item: typeof cartItems.$inferSelect,
  plan: typeof productPlans.$inferSelect,
  product: typeof products.$inferSelect,
): CartItemDto {
  return {
    id: item.id,
    planId: item.planId,
    quantity: item.quantity,
    productId: product.id,
    productName: product.name,
    productSlug: product.slug,
    planName: plan.name,
    tier: plan.tier,
    billingType: plan.billingType,
    accentColor: product.accentColor,
    unitPriceCents: plan.priceCents,
    lineTotalCents: plan.priceCents * item.quantity,
  };
}

export async function getCart(
  sessionKey: string,
  userId: string | null,
  discountCode?: string | null,
): Promise<CartDto> {
  const cart = await resolveCart(sessionKey, userId);
  const rows = await db
    .select({ item: cartItems, plan: productPlans, product: products })
    .from(cartItems)
    .innerJoin(productPlans, eq(cartItems.planId, productPlans.id))
    .innerJoin(products, eq(productPlans.productId, products.id))
    .where(eq(cartItems.cartId, cart.id))
    .orderBy(asc(cartItems.createdAt));

  const items = rows.map((r) => toCartItemDto(r.item, r.plan, r.product));
  const settings = await getSettings();
  const subtotalCents = items.reduce((sum, i) => sum + i.lineTotalCents, 0);
  const itemCount = items.reduce((sum, i) => sum + i.quantity, 0);

  let discountCents = 0;
  let appliedCode: string | null = null;
  if (discountCode) {
    const result = await evaluateDiscount(discountCode, subtotalCents);
    discountCents = result.discountCents;
    appliedCode = result.code.code;
  }
  const taxable = Math.max(0, subtotalCents - discountCents);
  const taxCents = Math.round((taxable * settings.taxRateBps) / 10_000);

  return {
    items,
    subtotalCents,
    itemCount,
    discountCents,
    discountCode: appliedCode,
    taxCents,
    totalCents: taxable + taxCents,
    taxRateBps: settings.taxRateBps,
  };
}

export async function addToCart(
  sessionKey: string,
  userId: string | null,
  planId: string,
  quantity: number,
): Promise<CartDto> {
  const [plan] = await db.select().from(productPlans).where(eq(productPlans.id, planId)).limit(1);
  if (!plan) throw notFound("Plan");
  const cart = await resolveCart(sessionKey, userId);
  const [existing] = await db
    .select()
    .from(cartItems)
    .where(and(eq(cartItems.cartId, cart.id), eq(cartItems.planId, planId)))
    .limit(1);
  if (existing) {
    await db
      .update(cartItems)
      .set({ quantity: existing.quantity + quantity })
      .where(eq(cartItems.id, existing.id));
  } else {
    await db.insert(cartItems).values({ cartId: cart.id, planId, quantity });
  }
  return getCart(sessionKey, userId);
}

export async function updateCartItem(
  sessionKey: string,
  userId: string | null,
  itemId: string,
  quantity: number,
): Promise<CartDto> {
  const cart = await resolveCart(sessionKey, userId);
  if (quantity <= 0) return removeCartItem(sessionKey, userId, itemId);
  await db
    .update(cartItems)
    .set({ quantity })
    .where(and(eq(cartItems.id, itemId), eq(cartItems.cartId, cart.id)));
  return getCart(sessionKey, userId);
}

export async function removeCartItem(
  sessionKey: string,
  userId: string | null,
  itemId: string,
): Promise<CartDto> {
  const cart = await resolveCart(sessionKey, userId);
  await db
    .delete(cartItems)
    .where(and(eq(cartItems.id, itemId), eq(cartItems.cartId, cart.id)));
  return getCart(sessionKey, userId);
}

/* ---------------------------- discount codes ---------------------------- */

function toDiscountDto(row: typeof discountCodes.$inferSelect): DiscountCodeDto {
  return {
    id: row.id,
    code: row.code,
    description: row.description,
    percentOff: row.percentOff,
    maxRedemptions: row.maxRedemptions,
    timesRedeemed: row.timesRedeemed,
    expiresAt: row.expiresAt ? row.expiresAt.toISOString() : null,
    isActive: row.isActive,
    createdAt: row.createdAt.toISOString(),
  };
}

async function evaluateDiscount(code: string, subtotalCents: number) {
  const [row] = await db
    .select()
    .from(discountCodes)
    .where(eq(discountCodes.code, code.trim().toUpperCase()))
    .limit(1);
  if (!row || !row.isActive) {
    throw new HttpError(404, "discount_invalid", "This discount code is not valid.");
  }
  if (row.expiresAt && row.expiresAt.getTime() < Date.now()) {
    throw new HttpError(410, "discount_expired", "This discount code has expired.");
  }
  if (row.maxRedemptions > 0 && row.timesRedeemed >= row.maxRedemptions) {
    throw new HttpError(410, "discount_exhausted", "This discount code has reached its redemption limit.");
  }
  const discountCents = Math.min(subtotalCents, Math.round((subtotalCents * row.percentOff) / 100));
  return { code: row, discountCents };
}

export async function listDiscountCodes() {
  const rows = await db.select().from(discountCodes).orderBy(desc(discountCodes.createdAt));
  return rows.map(toDiscountDto);
}

export async function createDiscountCode(input: {
  code: string;
  description?: string | null;
  percentOff: number;
  maxRedemptions?: number;
  expiresAt?: string | null;
  isActive?: boolean;
}) {
  const [row] = await db
    .insert(discountCodes)
    .values({
      code: input.code.toUpperCase(),
      description: input.description ?? null,
      percentOff: input.percentOff,
      maxRedemptions: input.maxRedemptions ?? 0,
      expiresAt: input.expiresAt ? new Date(input.expiresAt) : null,
      isActive: input.isActive ?? true,
    })
    .returning();
  return toDiscountDto(row);
}

export async function updateDiscountCode(
  id: string,
  input: Partial<{
    description: string | null;
    percentOff: number;
    maxRedemptions: number;
    expiresAt: string | null;
    isActive: boolean;
  }>,
) {
  const { expiresAt, ...rest } = input;
  const [row] = await db
    .update(discountCodes)
    .set({
      ...rest,
      ...(expiresAt === undefined ? {} : { expiresAt: expiresAt ? new Date(expiresAt) : null }),
    })
    .where(eq(discountCodes.id, id))
    .returning();
  if (!row) throw notFound("Discount code");
  return toDiscountDto(row);
}

export async function deleteDiscountCode(id: string) {
  await db.delete(discountCodes).where(eq(discountCodes.id, id));
}

/* ------------------- orders, checkout, payments, invoices ------------------ */

function toOrderDto(
  order: typeof orders.$inferSelect,
  customer: { fullName: string; email: string; company: string | null },
  items: (typeof orderItems.$inferSelect)[],
): OrderDto {
  return {
    id: order.id,
    orderNumber: order.orderNumber,
    userId: order.userId,
    customerName: customer.fullName,
    customerEmail: customer.email,
    customerCompany: customer.company,
    status: order.status,
    subtotalCents: order.subtotalCents,
    discountCents: order.discountCents,
    taxCents: order.taxCents,
    totalCents: order.totalCents,
    currency: order.currency,
    discountCode: order.discountCode,
    placedAt: order.placedAt.toISOString(),
    billingName: order.billingName,
    billingCompany: order.billingCompany,
    billingEmail: order.billingEmail,
    billingCountry: order.billingCountry,
    notes: order.notes,
    items: items.map((i) => ({
      id: i.id,
      productId: i.productId,
      planId: i.planId,
      productName: i.productName,
      planName: i.planName,
      billingType: i.billingType,
      unitPriceCents: i.unitPriceCents,
      quantity: i.quantity,
      lineTotalCents: i.lineTotalCents,
    })),
  };
}

async function loadOrders(where: ReturnType<typeof eq> | undefined, page: number, pageSize: number) {
  const rows = await db
    .select({ order: orders, user: users })
    .from(orders)
    .innerJoin(users, eq(orders.userId, users.id))
    .where(where)
    .orderBy(desc(orders.placedAt))
    .limit(pageSize)
    .offset((page - 1) * pageSize);
  const ids = rows.map((r) => r.order.id);
  const items = ids.length
    ? await db.select().from(orderItems).where(inArray(orderItems.orderId, ids))
    : [];
  const [total] = await db.select({ value: count() }).from(orders).where(where);
  return {
    items: rows.map((r) =>
      toOrderDto(
        r.order,
        { fullName: r.user.fullName, email: r.user.email, company: r.user.company },
        items.filter((i) => i.orderId === r.order.id),
      ),
    ),
    total: total?.value ?? 0,
  };
}

export async function listOrders(query: {
  userId?: string;
  status?: OrderStatus | "all";
  search?: string | null;
  page: number;
  pageSize: number;
}) {
  const conditions = [];
  if (query.userId) conditions.push(eq(orders.userId, query.userId));
  if (query.status && query.status !== "all") conditions.push(eq(orders.status, query.status));
  if (query.search) {
    const like = `%${query.search}%`;
    conditions.push(
      or(ilike(orders.orderNumber, like), ilike(users.fullName, like), ilike(users.email, like))!,
    );
  }
  return loadOrders(conditions.length ? and(...conditions) : undefined, query.page, query.pageSize);
}

export async function getOrder(id: string, userId?: string): Promise<OrderDto> {
  const [row] = await db
    .select({ order: orders, user: users })
    .from(orders)
    .innerJoin(users, eq(orders.userId, users.id))
    .where(userId ? and(eq(orders.id, id), eq(orders.userId, userId)) : eq(orders.id, id))
    .limit(1);
  if (!row) throw notFound("Order");
  const items = await db.select().from(orderItems).where(eq(orderItems.orderId, id));
  return toOrderDto(
    row.order,
    { fullName: row.user.fullName, email: row.user.email, company: row.user.company },
    items,
  );
}

function generateLicenseKey(): string {
  const charset = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  const group = (n: number) =>
    Array.from(randomBytes(n))
      .map((b) => charset[b % charset.length])
      .join("");
  return `NW-${group(5)}-${group(5)}-${group(5)}-${group(5)}`;
}

async function nextSequence(prefix: string): Promise<string> {
  const [row] = await db.select({ value: count() }).from(orders);
  const seq = (row?.value ?? 0) + 1;
  return `${prefix}-${new Date().getFullYear()}-${String(seq).padStart(4, "0")}`;
}

export interface CheckoutInput {
  userId: string;
  sessionKey: string;
  discountCode?: string | null;
  paymentMethod: string;
  cardName?: string;
  cardLast4?: string;
  billing: {
    name: string;
    company?: string | null;
    email: string;
    country: string;
    vatId?: string | null;
  };
  notes?: string | null;
}

export async function checkout(input: CheckoutInput): Promise<OrderDto> {
  const cart = await getCart(input.sessionKey, input.userId, input.discountCode);
  if (!cart.items.length) {
    throw new HttpError(400, "cart_empty", "Your cart is empty — add a plan before checking out.");
  }

  const orderNumber = await nextSequence("NW");
  const [order] = await db
    .insert(orders)
    .values({
      orderNumber,
      userId: input.userId,
      status: "Pending",
      subtotalCents: cart.subtotalCents,
      discountCents: cart.discountCents,
      taxCents: cart.taxCents,
      totalCents: cart.totalCents,
      discountCode: cart.discountCode,
      billingName: input.billing.name,
      billingCompany: input.billing.company ?? null,
      billingEmail: input.billing.email,
      billingCountry: input.billing.country,
      notes: input.notes ?? null,
    })
    .returning();

  await db.insert(orderItems).values(
    cart.items.map((item) => ({
      orderId: order.id,
      productId: item.productId,
      planId: item.planId,
      productName: item.productName,
      planName: item.planName,
      billingType: item.billingType,
      unitPriceCents: item.unitPriceCents,
      quantity: item.quantity,
      lineTotalCents: item.lineTotalCents,
    })),
  );

  // Payment gateway integration point (Infrastructure layer).
  const [payment] = await db
    .insert(payments)
    .values({
      orderId: order.id,
      provider: "MockGateway",
      method: input.paymentMethod,
      amountCents: cart.totalCents,
      status: "Succeeded",
      transactionRef: `txn_${randomBytes(8).toString("hex")}`,
      paidAt: new Date(),
    })
    .returning();

  await db.update(orders).set({ status: "Paid" }).where(eq(orders.id, order.id));

  const [invoice] = await db
    .insert(invoices)
    .values({
      invoiceNumber: await nextSequence("INV"),
      orderId: order.id,
      status: "Paid",
      totalCents: cart.totalCents,
      taxCents: cart.taxCents,
      dueAt: new Date(Date.now() + 14 * 86_400_000),
    })
    .returning();

  // Provision a license per purchased seat.
  for (const item of cart.items) {
    const [plan] = await db
      .select()
      .from(productPlans)
      .where(eq(productPlans.id, item.planId))
      .limit(1);
    if (!plan) continue;
    const expiresAt = plan.billingType === "Annual" ? new Date(Date.now() + 365 * 86_400_000) : null;
    for (let i = 0; i < item.quantity; i += 1) {
      await db.insert(licenses).values({
        licenseKey: generateLicenseKey(),
        userId: input.userId,
        productId: item.productId,
        planId: item.planId,
        orderId: order.id,
        seats: plan.seats,
        expiresAt,
      });
    }
    await db
      .update(products)
      .set({ popularity: sql`${products.popularity} + ${item.quantity}` })
      .where(eq(products.id, item.productId));
  }

  if (cart.discountCode) {
    await db
      .update(discountCodes)
      .set({ timesRedeemed: sql`${discountCodes.timesRedeemed} + 1` })
      .where(eq(discountCodes.code, cart.discountCode));
  }

  const [cartRow] = await db.select().from(carts).where(eq(carts.sessionKey, input.sessionKey)).limit(1);
  if (cartRow) await db.delete(cartItems).where(eq(cartItems.cartId, cartRow.id));

  logger.info("order_completed", {
    orderId: order.id,
    paymentId: payment.id,
    invoiceId: invoice.id,
    totalCents: cart.totalCents,
  });
  return getOrder(order.id);
}

export async function updateOrderStatus(id: string, status: OrderStatus): Promise<OrderDto> {
  const [row] = await db.update(orders).set({ status }).where(eq(orders.id, id)).returning();
  if (!row) throw notFound("Order");
  if (status === "Refunded") {
    await db.update(payments).set({ status: "Refunded" }).where(eq(payments.orderId, id));
    await db.update(licenses).set({ status: "Revoked" }).where(eq(licenses.orderId, id));
  }
  return getOrder(id);
}

export async function listInvoices(query: { userId?: string; page: number; pageSize: number }) {
  const conditions = [];
  if (query.userId) conditions.push(eq(orders.userId, query.userId));
  const where = conditions.length ? and(...conditions) : undefined;
  const rows = await db
    .select({ invoice: invoices, order: orders, user: users })
    .from(invoices)
    .innerJoin(orders, eq(invoices.orderId, orders.id))
    .innerJoin(users, eq(orders.userId, users.id))
    .where(where)
    .orderBy(desc(invoices.issuedAt))
    .limit(query.pageSize)
    .offset((query.page - 1) * query.pageSize);
  const [total] = await db
    .select({ value: count() })
    .from(invoices)
    .innerJoin(orders, eq(invoices.orderId, orders.id))
    .where(where);
  const items: InvoiceDto[] = rows.map((r) => ({
    id: r.invoice.id,
    invoiceNumber: r.invoice.invoiceNumber,
    orderId: r.order.id,
    orderNumber: r.order.orderNumber,
    customerName: r.user.fullName,
    customerEmail: r.user.email,
    status: r.invoice.status,
    issuedAt: r.invoice.issuedAt.toISOString(),
    dueAt: r.invoice.dueAt ? r.invoice.dueAt.toISOString() : null,
    totalCents: r.invoice.totalCents,
    taxCents: r.invoice.taxCents,
  }));
  return { items, total: total?.value ?? 0 };
}

/* ------------------------------- licenses ------------------------------- */

function toLicenseDto(
  license: typeof licenses.$inferSelect,
  user: { fullName: string; email: string },
  product: { id: string; name: string; slug: string },
  planName: string | null,
): LicenseDto {
  return {
    id: license.id,
    licenseKey: license.licenseKey,
    userId: license.userId,
    customerName: user.fullName,
    customerEmail: user.email,
    productId: product.id,
    productName: product.name,
    productSlug: product.slug,
    planName,
    seats: license.seats,
    activationsUsed: license.activationsUsed,
    status: license.status,
    issuedAt: license.issuedAt.toISOString(),
    expiresAt: license.expiresAt ? license.expiresAt.toISOString() : null,
  };
}

export async function listLicenses(query: {
  userId?: string;
  status?: LicenseStatus | "all";
  search?: string | null;
  page: number;
  pageSize: number;
}) {
  const conditions = [];
  if (query.userId) conditions.push(eq(licenses.userId, query.userId));
  if (query.status && query.status !== "all") conditions.push(eq(licenses.status, query.status));
  if (query.search) {
    const like = `%${query.search}%`;
    conditions.push(
      or(
        ilike(licenses.licenseKey, like),
        ilike(users.fullName, like),
        ilike(users.email, like),
        ilike(products.name, like),
      )!,
    );
  }
  const where = conditions.length ? and(...conditions) : undefined;
  const rows = await db
    .select({ license: licenses, user: users, product: products, plan: productPlans })
    .from(licenses)
    .innerJoin(users, eq(licenses.userId, users.id))
    .innerJoin(products, eq(licenses.productId, products.id))
    .leftJoin(productPlans, eq(licenses.planId, productPlans.id))
    .where(where)
    .orderBy(desc(licenses.issuedAt))
    .limit(query.pageSize)
    .offset((query.page - 1) * query.pageSize);
  const [total] = await db
    .select({ value: count() })
    .from(licenses)
    .innerJoin(users, eq(licenses.userId, users.id))
    .innerJoin(products, eq(licenses.productId, products.id))
    .where(where);
  return {
    items: rows.map((r) =>
      toLicenseDto(
        r.license,
        { fullName: r.user.fullName, email: r.user.email },
        r.product,
        r.plan?.name ?? null,
      ),
    ),
    total: total?.value ?? 0,
  };
}

export async function generateLicense(input: {
  userId: string;
  productId: string;
  planId?: string | null;
  seats?: number;
  validDays?: number | null;
}): Promise<LicenseDto> {
  const [product] = await db.select().from(products).where(eq(products.id, input.productId)).limit(1);
  if (!product) throw notFound("Product");
  const [row] = await db
    .insert(licenses)
    .values({
      licenseKey: generateLicenseKey(),
      userId: input.userId,
      productId: input.productId,
      planId: input.planId ?? null,
      seats: input.seats ?? 1,
      expiresAt: input.validDays ? new Date(Date.now() + input.validDays * 86_400_000) : null,
    })
    .returning();
  const [user] = await db.select().from(users).where(eq(users.id, input.userId)).limit(1);
  const [plan] = input.planId
    ? await db.select().from(productPlans).where(eq(productPlans.id, input.planId)).limit(1)
    : [undefined];
  return toLicenseDto(
    row,
    { fullName: user?.fullName ?? "Customer", email: user?.email ?? "" },
    product,
    plan?.name ?? null,
  );
}

export async function licenseAction(
  id: string,
  action: "revoke" | "extend" | "reactivate" | "activate",
  payload: { days?: number; machineName?: string },
): Promise<LicenseDto> {
  const [row] = await db.select().from(licenses).where(eq(licenses.id, id)).limit(1);
  if (!row) throw notFound("License");

  if (action === "revoke") {
    await db.update(licenses).set({ status: "Revoked" }).where(eq(licenses.id, id));
  } else if (action === "reactivate") {
    await db.update(licenses).set({ status: "Active" }).where(eq(licenses.id, id));
  } else if (action === "extend") {
    const days = payload.days ?? 365;
    const base = row.expiresAt && row.expiresAt.getTime() > Date.now() ? row.expiresAt : new Date();
    await db
      .update(licenses)
      .set({ expiresAt: new Date(base.getTime() + days * 86_400_000), status: "Active" })
      .where(eq(licenses.id, id));
  } else if (action === "activate") {
    if (row.status === "Revoked") {
      throw new HttpError(400, "license_revoked", "This license has been revoked.");
    }
    if (row.activationsUsed >= row.seats) {
      throw new HttpError(400, "license_seats_exceeded", "All seats for this license are in use.");
    }
    await db.insert(licenseActivations).values({
      licenseId: id,
      machineName: payload.machineName ?? "WORKSTATION-01",
      machineHash: randomBytes(8).toString("hex"),
    });
    await db
      .update(licenses)
      .set({ activationsUsed: row.activationsUsed + 1, status: "Active" })
      .where(eq(licenses.id, id));
  }

  const [updated] = await db.select().from(licenses).where(eq(licenses.id, id)).limit(1);
  const [user] = await db.select().from(users).where(eq(users.id, updated.userId)).limit(1);
  const [product] = await db.select().from(products).where(eq(products.id, updated.productId)).limit(1);
  const [plan] = updated.planId
    ? await db.select().from(productPlans).where(eq(productPlans.id, updated.planId)).limit(1)
    : [undefined];
  return toLicenseDto(
    updated,
    { fullName: user?.fullName ?? "", email: user?.email ?? "" },
    product,
    plan?.name ?? null,
  );
}

/* ------------------------------- downloads ------------------------------ */

export async function listAvailableDownloads(userId: string): Promise<AvailableDownloadDto[]> {
  const owned = await db
    .select({ productId: licenses.productId })
    .from(licenses)
    .where(and(eq(licenses.userId, userId), eq(licenses.status, "Active")));
  const ownedIds = new Set(owned.map((o) => o.productId));

  const rows = await db
    .select({ product: products, version: productVersions })
    .from(products)
    .innerJoin(productVersions, eq(productVersions.productId, products.id))
    .where(eq(products.isActive, true))
    .orderBy(asc(products.name), desc(productVersions.releasedAt));

  const grouped = new Map<string, AvailableDownloadDto>();
  for (const row of rows) {
    const existing = grouped.get(row.product.id) ?? {
      productId: row.product.id,
      productName: row.product.name,
      productSlug: row.product.slug,
      accentColor: row.product.accentColor,
      licensed: ownedIds.has(row.product.id),
      versions: [],
    };
    existing.versions.push({
      id: row.version.id,
      version: row.version.version,
      releasedAt: row.version.releasedAt.toISOString(),
      platform: row.version.platform,
      sizeMb: row.version.sizeMb,
      fileName: `${row.product.slug}-${row.version.version}-setup.exe`,
      installerUrl: row.version.installerUrl,
      notes: row.version.notes,
    });
    grouped.set(row.product.id, existing);
  }
  return [...grouped.values()];
}

export async function listDownloadHistory(userId: string): Promise<DownloadDto[]> {
  const rows = await db
    .select({ download: downloads, product: products, version: productVersions })
    .from(downloads)
    .innerJoin(products, eq(downloads.productId, products.id))
    .leftJoin(productVersions, eq(downloads.versionId, productVersions.id))
    .where(eq(downloads.userId, userId))
    .orderBy(desc(downloads.downloadedAt))
    .limit(50);
  return rows.map((r) => ({
    id: r.download.id,
    productId: r.product.id,
    productName: r.product.name,
    productSlug: r.product.slug,
    versionId: r.download.versionId,
    version: r.version?.version ?? "latest",
    kind: r.download.kind,
    fileName: r.download.fileName,
    sizeMb: r.download.sizeMb,
    downloadedAt: r.download.downloadedAt.toISOString(),
    requiresLicense: r.download.kind === "installer",
  }));
}

export async function recordDownload(input: {
  userId: string | null;
  productId: string;
  versionId?: string | null;
  kind: string;
  fileName: string;
  sizeMb?: number;
}): Promise<DownloadDto> {
  let size = input.sizeMb ?? 0;
  if (!size && input.versionId) {
    const [v] = await db
      .select()
      .from(productVersions)
      .where(eq(productVersions.id, input.versionId))
      .limit(1);
    size = v?.sizeMb ?? 0;
  }
  const [row] = await db
    .insert(downloads)
    .values({
      userId: input.userId,
      productId: input.productId,
      versionId: input.versionId ?? null,
      kind: input.kind,
      fileName: input.fileName,
      sizeMb: size,
    })
    .returning();
  const [product] = await db.select().from(products).where(eq(products.id, input.productId)).limit(1);
  return {
    id: row.id,
    productId: input.productId,
    productName: product?.name ?? "Product",
    productSlug: product?.slug ?? "",
    versionId: row.versionId,
    version: "latest",
    kind: row.kind,
    fileName: row.fileName,
    sizeMb: row.sizeMb,
    downloadedAt: row.downloadedAt.toISOString(),
    requiresLicense: row.kind === "installer",
  };
}

export async function expiringLicenseCount(userId?: string) {
  const soon = new Date(Date.now() + 45 * 86_400_000);
  const conditions = [eq(licenses.status, "Active"), lt(licenses.expiresAt, soon)];
  if (userId) conditions.push(eq(licenses.userId, userId));
  const [row] = await db
    .select({ value: count() })
    .from(licenses)
    .where(and(...conditions));
  return row?.value ?? 0;
}
