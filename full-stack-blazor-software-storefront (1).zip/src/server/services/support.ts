import { and, count, desc, eq, ilike, inArray, or, sql } from "drizzle-orm";
import { randomBytes } from "node:crypto";
import { db } from "@/db";
import {
  contactMessages,
  demoRequests,
  invoices,
  licenses,
  orders,
  products,
  reviews,
  ticketMessages,
  tickets,
  users,
} from "@/db/schema";
import { HttpError, notFound } from "@/server/http";
import { toUserDto } from "@/server/auth";
import { listAvailableDownloads, listLicenses, listOrders } from "@/server/services/commerce";
import type {
  CustomerDto,
  CustomerOverviewDto,
  OrderStatus,
  Role,
  TicketDetailDto,
  TicketDto,
  TicketPriority,
  TicketStatus,
} from "@/shared/contracts";

/* ----------------------------- support tickets ---------------------------- */

function ticketRef() {
  return `TKT-${randomBytes(3).toString("hex").toUpperCase()}`;
}

function toTicketDto(
  ticket: typeof tickets.$inferSelect,
  user: { fullName: string; email: string },
  productName: string | null,
  messageCount?: number,
): TicketDto {
  return {
    id: ticket.id,
    reference: ticket.reference,
    userId: ticket.userId,
    customerName: user.fullName,
    customerEmail: user.email,
    productId: ticket.productId,
    productName,
    subject: ticket.subject,
    category: ticket.category,
    priority: ticket.priority,
    status: ticket.status,
    environment: ticket.environment,
    createdAt: ticket.createdAt.toISOString(),
    updatedAt: ticket.updatedAt.toISOString(),
    ...(messageCount === undefined ? {} : { messageCount }),
  };
}

export async function listTickets(query: {
  userId?: string;
  status?: TicketStatus | "all";
  priority?: TicketPriority | "all";
  search?: string | null;
  page: number;
  pageSize: number;
}) {
  const conditions = [];
  if (query.userId) conditions.push(eq(tickets.userId, query.userId));
  if (query.status && query.status !== "all") conditions.push(eq(tickets.status, query.status));
  if (query.priority && query.priority !== "all") {
    conditions.push(eq(tickets.priority, query.priority));
  }
  if (query.search) {
    const like = `%${query.search}%`;
    conditions.push(
      or(ilike(tickets.subject, like), ilike(tickets.reference, like), ilike(users.fullName, like))!,
    );
  }
  const where = conditions.length ? and(...conditions) : undefined;

  const rows = await db
    .select({ ticket: tickets, user: users, product: products })
    .from(tickets)
    .innerJoin(users, eq(tickets.userId, users.id))
    .leftJoin(products, eq(tickets.productId, products.id))
    .where(where)
    .orderBy(desc(tickets.updatedAt))
    .limit(query.pageSize)
    .offset((query.page - 1) * query.pageSize);

  const ids = rows.map((r) => r.ticket.id);
  const counts = ids.length
    ? await db
        .select({ ticketId: ticketMessages.ticketId, value: count() })
        .from(ticketMessages)
        .where(inArray(ticketMessages.ticketId, ids))
        .groupBy(ticketMessages.ticketId)
    : [];
  const countMap = new Map(counts.map((c) => [c.ticketId, Number(c.value)]));

  const [total] = await db
    .select({ value: count() })
    .from(tickets)
    .innerJoin(users, eq(tickets.userId, users.id))
    .where(where);

  return {
    items: rows.map((r) =>
      toTicketDto(
        r.ticket,
        { fullName: r.user.fullName, email: r.user.email },
        r.product?.name ?? null,
        countMap.get(r.ticket.id) ?? 0,
      ),
    ),
    total: total?.value ?? 0,
  };
}

export async function getTicket(id: string, userId?: string): Promise<TicketDetailDto> {
  const [row] = await db
    .select({ ticket: tickets, user: users, product: products })
    .from(tickets)
    .innerJoin(users, eq(tickets.userId, users.id))
    .leftJoin(products, eq(tickets.productId, products.id))
    .where(userId ? and(eq(tickets.id, id), eq(tickets.userId, userId)) : eq(tickets.id, id))
    .limit(1);
  if (!row) throw notFound("Ticket");
  const messages = await db
    .select()
    .from(ticketMessages)
    .where(eq(ticketMessages.ticketId, id))
    .orderBy(ticketMessages.createdAt);
  return {
    ...toTicketDto(
      row.ticket,
      { fullName: row.user.fullName, email: row.user.email },
      row.product?.name ?? null,
    ),
    messages: messages.map((m) => ({
      id: m.id,
      authorName: m.authorName,
      isStaff: m.isStaff,
      body: m.body,
      createdAt: m.createdAt.toISOString(),
    })),
  };
}

export async function createTicket(input: {
  userId: string;
  productId?: string | null;
  subject: string;
  category: string;
  priority: TicketPriority;
  environment?: string | null;
  message: string;
}): Promise<TicketDetailDto> {
  const [ticket] = await db
    .insert(tickets)
    .values({
      reference: ticketRef(),
      userId: input.userId,
      productId: input.productId ?? null,
      subject: input.subject,
      category: input.category,
      priority: input.priority,
      environment: input.environment ?? null,
      status: "Open",
    })
    .returning();
  await db.insert(ticketMessages).values({
    ticketId: ticket.id,
    authorId: input.userId,
    authorName: "You",
    isStaff: false,
    body: input.message,
  });
  return getTicket(ticket.id);
}

export async function addTicketMessage(input: {
  ticketId: string;
  authorId: string | null;
  authorName: string;
  isStaff: boolean;
  body: string;
  newStatus?: TicketStatus;
}): Promise<TicketDetailDto> {
  const [ticket] = await db.select().from(tickets).where(eq(tickets.id, input.ticketId)).limit(1);
  if (!ticket) throw notFound("Ticket");
  await db.insert(ticketMessages).values({
    ticketId: input.ticketId,
    authorId: input.authorId,
    authorName: input.authorName,
    isStaff: input.isStaff,
    body: input.body,
  });
  await db
    .update(tickets)
    .set({ updatedAt: new Date(), ...(input.newStatus ? { status: input.newStatus } : {}) })
    .where(eq(tickets.id, input.ticketId));
  return getTicket(input.ticketId);
}

export async function updateTicket(
  id: string,
  input: Partial<{ status: TicketStatus; priority: TicketPriority }>,
): Promise<TicketDetailDto> {
  const [row] = await db
    .update(tickets)
    .set({ ...input, updatedAt: new Date() })
    .where(eq(tickets.id, id))
    .returning();
  if (!row) throw notFound("Ticket");
  return getTicket(id);
}

/* ------------------------- contact & demo requests ------------------------ */

export async function createContactMessage(input: {
  name: string;
  email: string;
  company?: string | null;
  topic: string;
  message: string;
}) {
  const [row] = await db.insert(contactMessages).values(input).returning();
  return { id: row.id, receivedAt: row.createdAt.toISOString() };
}

export async function createDemoRequest(input: {
  productId?: string | null;
  name: string;
  email: string;
  company?: string | null;
  companySize?: string | null;
  message?: string | null;
}) {
  const [row] = await db.insert(demoRequests).values(input).returning();
  return { id: row.id, receivedAt: row.createdAt.toISOString() };
}

/* ------------------------------ customers (admin) ------------------------- */

export async function listCustomers(query: {
  search?: string | null;
  role?: string;
  page: number;
  pageSize: number;
}): Promise<{ items: CustomerDto[]; total: number }> {
  const conditions = [];
  if (query.search) {
    const like = `%${query.search}%`;
    conditions.push(or(ilike(users.fullName, like), ilike(users.email, like), ilike(users.company, like))!);
  }
  if (query.role && query.role !== "all") conditions.push(eq(users.role, query.role as Role));
  const where = conditions.length ? and(...conditions) : undefined;

  const rows = await db
    .select()
    .from(users)
    .where(where)
    .orderBy(desc(users.createdAt))
    .limit(query.pageSize)
    .offset((query.page - 1) * query.pageSize);
  const ids = rows.map((r) => r.id);

  const orderStats = ids.length
    ? await db
        .select({
          userId: orders.userId,
          orderCount: count(),
          totalSpent: sql<number>`coalesce(sum(${orders.totalCents}), 0)::int`,
        })
        .from(orders)
        .where(inArray(orders.userId, ids))
        .groupBy(orders.userId)
    : [];
  const licenseStats = ids.length
    ? await db
        .select({ userId: licenses.userId, value: count() })
        .from(licenses)
        .where(and(inArray(licenses.userId, ids), eq(licenses.status, "Active")))
        .groupBy(licenses.userId)
    : [];
  const ticketStats = ids.length
    ? await db
        .select({ userId: tickets.userId, value: count() })
        .from(tickets)
        .where(and(inArray(tickets.userId, ids), inArray(tickets.status, ["Open", "InProgress"])))
        .groupBy(tickets.userId)
    : [];

  const orderMap = new Map(orderStats.map((o) => [o.userId, o]));
  const licenseMap = new Map(licenseStats.map((l) => [l.userId, Number(l.value)]));
  const ticketMap = new Map(ticketStats.map((t) => [t.userId, Number(t.value)]));
  const [total] = await db.select({ value: count() }).from(users).where(where);

  return {
    items: rows.map((row) => ({
      ...toUserDto(row),
      orderCount: Number(orderMap.get(row.id)?.orderCount ?? 0),
      totalSpentCents: Number(orderMap.get(row.id)?.totalSpent ?? 0),
      licenseCount: licenseMap.get(row.id) ?? 0,
      openTickets: ticketMap.get(row.id) ?? 0,
    })),
    total: total?.value ?? 0,
  };
}

export async function updateCustomer(
  id: string,
  input: Partial<{
    fullName: string;
    company: string | null;
    phone: string | null;
    country: string | null;
    role: Role;
    isLocked: boolean;
  }>,
): Promise<CustomerDto> {
  const [row] = await db.update(users).set(input).where(eq(users.id, id)).returning();
  if (!row) throw notFound("Customer");
  return { ...toUserDto(row), orderCount: 0, totalSpentCents: 0, licenseCount: 0, openTickets: 0 };
}

export async function deleteCustomer(id: string): Promise<void> {
  const [row] = await db.select().from(users).where(eq(users.id, id)).limit(1);
  if (!row) throw notFound("Customer");
  if (row.role === "Admin") {
    throw new HttpError(400, "cannot_delete_admin", "Administrator accounts cannot be deleted.");
  }
  await db.delete(users).where(eq(users.id, id));
}

/* --------------------------- reports & dashboards -------------------------- */

/** برچسب ماه‌های میلادی به فارسی برای نمودارها */
const FA_MONTHS: Record<string, string> = {
  Jan: "ژانویه",
  Feb: "فوریه",
  Mar: "مارس",
  Apr: "آوریل",
  May: "مه",
  Jun: "ژوئن",
  Jul: "ژوئیه",
  Aug: "اوت",
  Sep: "سپتامبر",
  Oct: "اکتبر",
  Nov: "نوامبر",
  Dec: "دسامبر",
};

export async function adminOverview() {
  const paidStatuses = ["Paid", "Completed", "Processing"] as OrderStatus[];

  const [revenueRow] = await db
    .select({ revenue: sql<number>`coalesce(sum(${orders.totalCents}), 0)::int`, orderCount: count() })
    .from(orders)
    .where(inArray(orders.status, paidStatuses));

  const [recentRevenue] = await db
    .select({ revenue: sql<number>`coalesce(sum(${orders.totalCents}), 0)::int` })
    .from(orders)
    .where(and(inArray(orders.status, paidStatuses), sql`${orders.placedAt} > now() - interval '30 days'`));

  const [customerRow] = await db.select({ total: count() }).from(users).where(eq(users.role, "Customer"));
  const [newCustomerRow] = await db
    .select({ total: count() })
    .from(users)
    .where(and(eq(users.role, "Customer"), sql`${users.createdAt} > now() - interval '30 days'`));

  const [licenseRow] = await db.select({ total: count() }).from(licenses).where(eq(licenses.status, "Active"));
  const [expiringRow] = await db
    .select({ total: count() })
    .from(licenses)
    .where(
      and(
        eq(licenses.status, "Active"),
        sql`${licenses.expiresAt} is not null and ${licenses.expiresAt} < now() + interval '45 days'`,
      ),
    );
  const [ticketRow] = await db
    .select({ total: count() })
    .from(tickets)
    .where(inArray(tickets.status, ["Open", "InProgress"] as TicketStatus[]));
  const [reviewRow] = await db.select({ total: count() }).from(reviews).where(eq(reviews.status, "Pending"));

  const revenueByMonth = await db
    .select({
      label: sql<string>`to_char(date_trunc('month', ${orders.placedAt}), 'Mon')`,
      valueCents: sql<number>`coalesce(sum(${orders.totalCents}), 0)::int`,
    })
    .from(orders)
    .where(sql`${orders.placedAt} > now() - interval '6 months'`)
    .groupBy(sql`date_trunc('month', ${orders.placedAt})`)
    .orderBy(sql`date_trunc('month', ${orders.placedAt})`);

  const ordersByStatus = await db
    .select({ label: orders.status, value: count() })
    .from(orders)
    .groupBy(orders.status);

  const customerGrowth = await db
    .select({ label: sql<string>`to_char(date_trunc('month', ${users.createdAt}), 'Mon')`, value: count() })
    .from(users)
    .where(sql`${users.createdAt} > now() - interval '6 months'`)
    .groupBy(sql`date_trunc('month', ${users.createdAt})`)
    .orderBy(sql`date_trunc('month', ${users.createdAt})`);

  const topProductRows = await db.execute(sql`
    select p.name as name, sum(oi.quantity)::int as units, sum(oi.line_total_cents)::int as revenue_cents
    from order_items oi
    join products p on p.id = oi.product_id
    group by p.name
    order by revenue_cents desc
    limit 5
  `);

  const recent = await listOrders({ page: 1, pageSize: 6 });
  const revenue = Number(revenueRow?.revenue ?? 0);
  const orderCount = Number(revenueRow?.orderCount ?? 0);

  return {
    revenueCents: revenue,
    revenueLast30Cents: Number(recentRevenue?.revenue ?? 0),
    orderCount,
    pendingOrderCount: Number(ordersByStatus.find((s) => s.label === "Pending")?.value ?? 0),
    customerCount: Number(customerRow?.total ?? 0),
    newCustomers30: Number(newCustomerRow?.total ?? 0),
    activeLicenses: Number(licenseRow?.total ?? 0),
    expiringLicenses: Number(expiringRow?.total ?? 0),
    openTickets: Number(ticketRow?.total ?? 0),
    pendingReviews: Number(reviewRow?.total ?? 0),
    averageOrderCents: orderCount ? Math.round(revenue / orderCount) : 0,
    revenueByMonth: revenueByMonth.map((r) => ({
      label: FA_MONTHS[r.label] ?? r.label,
      valueCents: Number(r.valueCents),
    })),
    ordersByStatus: ordersByStatus.map((r) => ({ label: r.label, value: Number(r.value) })),
    topProducts: (topProductRows.rows as { name: string; units: number; revenue_cents: number }[]).map(
      (r) => ({ name: r.name, units: Number(r.units), revenueCents: Number(r.revenue_cents) }),
    ),
    customerGrowth: customerGrowth.map((r) => ({ label: FA_MONTHS[r.label] ?? r.label, value: Number(r.value) })),
    recentOrders: recent.items,
  };
}

export async function customerOverview(userId: string): Promise<CustomerOverviewDto> {
  const paidStatuses = ["Paid", "Completed", "Processing"] as OrderStatus[];

  const [orderStat] = await db
    .select({ orderCount: count(), totalSpent: sql<number>`coalesce(sum(${orders.totalCents}), 0)::int` })
    .from(orders)
    .where(and(eq(orders.userId, userId), inArray(orders.status, paidStatuses)));

  const [activeLicenseRow] = await db
    .select({ total: count() })
    .from(licenses)
    .where(and(eq(licenses.userId, userId), eq(licenses.status, "Active")));
  const [expiringRow] = await db
    .select({ total: count() })
    .from(licenses)
    .where(
      and(
        eq(licenses.userId, userId),
        eq(licenses.status, "Active"),
        sql`${licenses.expiresAt} is not null and ${licenses.expiresAt} < now() + interval '45 days'`,
      ),
    );
  const [ticketRow] = await db
    .select({ total: count() })
    .from(tickets)
    .where(and(eq(tickets.userId, userId), inArray(tickets.status, ["Open", "InProgress"] as TicketStatus[])));
  const [outstanding] = await db
    .select({ total: sql<number>`coalesce(sum(${invoices.totalCents}), 0)::int` })
    .from(invoices)
    .innerJoin(orders, eq(invoices.orderId, orders.id))
    .where(and(eq(orders.userId, userId), inArray(invoices.status, ["Issued", "Draft"] as const)));

  const recent = await listOrders({ userId, page: 1, pageSize: 5 });
  const expiring = await listLicenses({ userId, page: 1, pageSize: 20 });
  const downloadsAvailable = await listAvailableDownloads(userId);

  return {
    orderCount: Number(orderStat?.orderCount ?? 0),
    activeLicenses: Number(activeLicenseRow?.total ?? 0),
    expiringLicenses: Number(expiringRow?.total ?? 0),
    openTickets: Number(ticketRow?.total ?? 0),
    totalSpentCents: Number(orderStat?.totalSpent ?? 0),
    availableDownloads: downloadsAvailable.reduce((sum, d) => sum + d.versions.length, 0),
    outstandingInvoicesCents: Number(outstanding?.total ?? 0),
    recentOrders: recent.items,
    licensesExpiringSoon: expiring.items.filter(
      (l) => l.expiresAt && new Date(l.expiresAt).getTime() < Date.now() + 45 * 86_400_000,
    ),
  };
}
