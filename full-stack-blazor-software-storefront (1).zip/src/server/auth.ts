import { createHmac, randomBytes, randomUUID, scryptSync, timingSafeEqual } from "node:crypto";
import { and, eq, gt, isNull } from "drizzle-orm";
import { db } from "@/db";
import { refreshTokens, users } from "@/db/schema";
import type { Role, UserDto } from "@/shared/contracts";

/* ------------------------- password hashing ------------------------- */

export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, 64).toString("hex");
  return `scrypt$${salt}$${hash}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  const [scheme, salt, hash] = stored.split("$");
  if (scheme !== "scrypt" || !salt || !hash) return false;
  const candidate = scryptSync(password, salt, 64);
  const expected = Buffer.from(hash, "hex");
  if (candidate.length !== expected.length) return false;
  return timingSafeEqual(candidate, expected);
}

/* ---------------------- JWT access tokens (HS256) -------------------- */

const SECRET = process.env.AUTH_SECRET ?? "northwind-storefront-dev-secret-key-2026";
const ACCESS_TTL_SECONDS = 15 * 60;
const REFRESH_TTL_DAYS = 14;

export interface TokenClaims {
  sub: string;
  email: string;
  role: Role;
  name: string;
  jti: string;
  iat: number;
  exp: number;
}

function b64url(input: Buffer | string): string {
  return Buffer.from(input)
    .toString("base64")
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/, "");
}

function fromB64url(input: string): Buffer {
  const pad = input.length % 4 === 0 ? "" : "=".repeat(4 - (input.length % 4));
  return Buffer.from(input.replace(/-/g, "+").replace(/_/g, "/") + pad, "base64");
}

export function signAccessToken(user: {
  id: string;
  email: string;
  role: Role;
  fullName: string;
}): { token: string; expiresIn: number } {
  const now = Math.floor(Date.now() / 1000);
  const header = b64url(JSON.stringify({ alg: "HS256", typ: "JWT" }));
  const payload: TokenClaims = {
    sub: user.id,
    email: user.email,
    role: user.role,
    name: user.fullName,
    jti: randomUUID(),
    iat: now,
    exp: now + ACCESS_TTL_SECONDS,
  };
  const body = b64url(JSON.stringify(payload));
  const signature = b64url(createHmac("sha256", SECRET).update(`${header}.${body}`).digest());
  return { token: `${header}.${body}.${signature}`, expiresIn: ACCESS_TTL_SECONDS };
}

export function verifyAccessToken(token: string): TokenClaims | null {
  const parts = token.split(".");
  if (parts.length !== 3) return null;
  const [header, body, signature] = parts;
  const expected = b64url(createHmac("sha256", SECRET).update(`${header}.${body}`).digest());
  if (expected.length !== signature.length) return null;
  if (!timingSafeEqual(Buffer.from(expected), Buffer.from(signature))) return null;
  try {
    const claims = JSON.parse(fromB64url(body).toString("utf8")) as TokenClaims;
    if (claims.exp * 1000 < Date.now()) return null;
    return claims;
  } catch {
    return null;
  }
}

/* ----------------- rotating, persisted refresh tokens ---------------- */

export function toUserDto(row: typeof users.$inferSelect): UserDto {
  return {
    id: row.id,
    email: row.email,
    fullName: row.fullName,
    role: row.role,
    company: row.company,
    phone: row.phone,
    country: row.country,
    createdAt: row.createdAt.toISOString(),
    lastLoginAt: row.lastLoginAt ? row.lastLoginAt.toISOString() : null,
  };
}

export async function issueRefreshToken(userId: string): Promise<string> {
  const token = randomBytes(48).toString("base64url");
  const tokenHash = createHmac("sha256", SECRET).update(token).digest("hex");
  await db.insert(refreshTokens).values({
    userId,
    tokenHash,
    expiresAt: new Date(Date.now() + REFRESH_TTL_DAYS * 86_400_000),
  });
  return token;
}

export async function consumeRefreshToken(token: string): Promise<UserDto | null> {
  const tokenHash = createHmac("sha256", SECRET).update(token).digest("hex");
  const [row] = await db
    .select()
    .from(refreshTokens)
    .where(
      and(
        eq(refreshTokens.tokenHash, tokenHash),
        isNull(refreshTokens.revokedAt),
        gt(refreshTokens.expiresAt, new Date()),
      ),
    )
    .limit(1);
  if (!row) return null;
  await db.update(refreshTokens).set({ revokedAt: new Date() }).where(eq(refreshTokens.id, row.id));
  const [user] = await db.select().from(users).where(eq(users.id, row.userId)).limit(1);
  if (!user || user.isLocked) return null;
  return toUserDto(user);
}

export async function revokeRefreshToken(token: string): Promise<void> {
  const tokenHash = createHmac("sha256", SECRET).update(token).digest("hex");
  await db
    .update(refreshTokens)
    .set({ revokedAt: new Date() })
    .where(eq(refreshTokens.tokenHash, tokenHash));
}

export const REFRESH_COOKIE = "nw_refresh";
export const ACCESS_TTL = ACCESS_TTL_SECONDS;

export function refreshCookieOptions() {
  return {
    httpOnly: true,
    sameSite: "lax" as const,
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: REFRESH_TTL_DAYS * 86_400,
  };
}
