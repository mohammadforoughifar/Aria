import { ZodError, type ZodType } from "zod";
import type { PagedMeta } from "@/shared/contracts";

/* ------------------- structured (Serilog-style) logger ------------------- */

type Level = "debug" | "info" | "warn" | "error";
const levelOrder: Record<Level, number> = { debug: 10, info: 20, warn: 30, error: 40 };
const minLevel = (process.env.LOG_LEVEL as Level) ?? "info";

export const logger = {
  log(level: Level, message: string, props?: Record<string, unknown>) {
    if (levelOrder[level] < levelOrder[minLevel]) return;
    const line = { timestamp: new Date().toISOString(), level: level.toUpperCase(), message, ...props };
    const out = JSON.stringify(line);
    if (level === "error") console.error(out);
    else if (level === "warn") console.warn(out);
    else console.log(out);
  },
  info: (m: string, p?: Record<string, unknown>) => logger.log("info", m, p),
  warn: (m: string, p?: Record<string, unknown>) => logger.log("warn", m, p),
  error: (m: string, p?: Record<string, unknown>) => logger.log("error", m, p),
  debug: (m: string, p?: Record<string, unknown>) => logger.log("debug", m, p),
};

/* -------- ProblemDetails-style errors + response envelope + CORS -------- */

export class HttpError extends Error {
  status: number;
  code: string;
  details?: Record<string, string[]>;
  constructor(status: number, code: string, message: string, details?: Record<string, string[]>) {
    super(message);
    this.status = status;
    this.code = code;
    this.details = details;
  }
}

const baseHeaders: Record<string, string> = {
  "content-type": "application/json",
  "cache-control": "no-store",
  "access-control-allow-origin": "*",
  "access-control-allow-headers": "content-type,authorization,x-cart-session",
  "access-control-allow-methods": "GET,POST,PATCH,PUT,DELETE,OPTIONS",
  "access-control-expose-headers": "x-cart-session",
};

export function ok<T>(data: T, meta?: PagedMeta, status = 200): Response {
  return new Response(JSON.stringify({ success: true, data, ...(meta ? { meta } : {}) }), {
    status,
    headers: baseHeaders,
  });
}

export function problem(err: unknown): Response {
  let status = 500;
  let code = "internal_error";
  let message = "An unexpected error occurred.";
  let details: Record<string, string[]> | undefined;

  if (err instanceof HttpError) {
    status = err.status;
    code = err.code;
    message = err.message;
    details = err.details;
  } else if (err instanceof ZodError) {
    status = 422;
    code = "validation_failed";
    message = "The request payload failed validation.";
    details = {};
    for (const issue of err.issues) {
      const key = issue.path.join(".") || "_";
      details[key] = [...(details[key] ?? []), issue.message];
    }
  } else if (err instanceof Error) {
    logger.error("unhandled_exception", { error: err.message, stack: err.stack?.slice(0, 400) });
  }

  return new Response(
    JSON.stringify({ success: false, error: { code, message, ...(details ? { details } : {}) } }),
    { status, headers: baseHeaders },
  );
}

export function corsPreflight(): Response {
  return new Response(null, { status: 204, headers: baseHeaders });
}

/* ----------------------------- request helpers ---------------------------- */

export async function parseJson<T>(req: Request, schema: ZodType<T>): Promise<T> {
  let raw: unknown;
  try {
    raw = await req.json();
  } catch {
    throw new HttpError(400, "invalid_json", "Request body must be valid JSON.");
  }
  return schema.parse(raw);
}

export interface ListParams {
  page: number;
  pageSize: number;
  search: string | null;
  sortBy: string | null;
  sortDir: "asc" | "desc";
  filters: Record<string, string>;
}

export function listParams(
  search: URLSearchParams,
  options: { defaultSort?: string; allowedSorts?: string[]; filters?: string[] } = {},
): ListParams {
  const page = Math.max(1, Number(search.get("page") ?? 1) || 1);
  const pageSize = Math.min(100, Math.max(1, Number(search.get("pageSize") ?? 12) || 12));
  const sortBy = search.get("sortBy") ?? options.defaultSort ?? null;
  const sortDir = (search.get("sortDir") ?? "desc") === "asc" ? "asc" : "desc";
  if (sortBy && options.allowedSorts && !options.allowedSorts.includes(sortBy)) {
    throw new HttpError(400, "invalid_sort", `Sorting by '${sortBy}' is not supported.`);
  }
  const filters: Record<string, string> = {};
  for (const key of options.filters ?? []) {
    const value = search.get(key);
    if (value !== null && value !== "" && value !== "all") filters[key] = value;
  }
  return { page, pageSize, search: search.get("search") || null, sortBy, sortDir, filters };
}

export function pagedMeta(page: number, pageSize: number, totalCount: number): PagedMeta {
  return { page, pageSize, totalCount, totalPages: Math.max(1, Math.ceil(totalCount / pageSize)) };
}

export function parseCookies(header: string | null): Record<string, string> {
  const out: Record<string, string> = {};
  if (!header) return out;
  for (const part of header.split(";")) {
    const idx = part.indexOf("=");
    if (idx < 0) continue;
    const key = part.slice(0, idx).trim();
    const value = part.slice(idx + 1).trim();
    if (key) out[key] = decodeURIComponent(value);
  }
  return out;
}

export function serializeCookie(
  name: string,
  value: string,
  opts: { httpOnly?: boolean; path?: string; maxAge?: number; sameSite?: string; secure?: boolean },
): string {
  const parts = [`${name}=${encodeURIComponent(value)}`, `Path=${opts.path ?? "/"}`];
  if (opts.maxAge !== undefined) parts.push(`Max-Age=${opts.maxAge}`);
  if (opts.httpOnly) parts.push("HttpOnly");
  if (opts.sameSite) parts.push(`SameSite=${opts.sameSite}`);
  if (opts.secure) parts.push("Secure");
  return parts.join("; ");
}

export function notFound(resource = "Resource"): HttpError {
  return new HttpError(404, "not_found", `${resource} was not found.`);
}

export function forbidden(): HttpError {
  return new HttpError(403, "forbidden", "You do not have permission to perform this action.");
}
