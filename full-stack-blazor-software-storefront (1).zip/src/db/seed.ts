import { count, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  categories,
  discountCodes,
  downloads,
  faqs,
  invoices,
  licenseActivations,
  licenses,
  orderItems,
  orders,
  payments,
  productPlans,
  productVersions,
  products,
  reviews,
  siteSettings,
  testimonials,
  ticketMessages,
  tickets,
  users,
} from "@/db/schema";
import { hashPassword } from "@/server/auth";

export const DEMO_PASSWORD = "Password123!";

const CATEGORY_DATA = [
  { name: "مجموعه ERP", slug: "erp-suite", icon: "layers", sortOrder: 1, description: "ماژول‌های اصلی برنامه‌ریزی منابع سازمان برای مالی، منابع انسانی و عملیات." },
  { name: "مالی و حسابداری", slug: "finance-accounting", icon: "calculator", sortOrder: 2, description: "دفتر کل، حساب‌های دریافتنی و پرداختنی، مالیات و تجمیع گزارش‌ها." },
  { name: "عملیات و انبار", slug: "operations-inventory", icon: "boxes", sortOrder: 3, description: "انبارگردانی، کنترل موجودی و اجرای تولید." },
  { name: "بهره‌وری دسکتاپ", slug: "desktop-productivity", icon: "monitor", sortOrder: 4, description: "برنامه‌های مستقل ویندوز برای کارهای روزمره کسب‌وکار." },
  { name: "افزونه‌ها و یکپارچه‌سازی", slug: "addons-integrations", icon: "puzzle", sortOrder: 5, description: "توسعه پلتفرم با کانکتورها، درگاه‌ها و ابزارهای کمکی." },
];

interface SeedProduct {
  slug: string;
  name: string;
  tagline: string;
  description: string;
  categorySlug: string;
  type: "Module" | "DesktopApp" | "AddOn";
  platform: string;
  accentColor: string;
  popularity: number;
  isFeatured: boolean;
  trialDays: number;
  features: string[];
  requirements: string[];
  gallery: string[];
  plans: { name: string; tier: "SingleUser" | "MultiUser" | "Enterprise"; billing: "OneTime" | "Annual"; price: number; seats: number; popular?: boolean; description: string }[];
}

const PRODUCTS: SeedProduct[] = [
  {
    slug: "northwind-erp-core",
    name: "هسته ERP نورث‌ویند",
    tagline: "منبع واحد حقیقت برای کل سازمان شما",
    description:
      "هسته ERP نورث‌ویند پایه این مجموعه است. داده‌های مالی، خرید، انبار و تولید را در یک هسته تراکنشی واحد با کلاینت دسکتاپ مدرن و مبتنی بر نقش یکپارچه می‌کند. این محصول برای تولیدکنندگان و پخش‌کنندگان متوسط طراحی شده و با بیش از ۱۴۰ گزارش آماده، تاریخچه کامل حسابرسی و پشتیبانی چندشرکتی و چندارزی ارائه می‌شود.\n\nهر ماژول مجموعه نورث‌ویند به این هسته متصل می‌شود و یک لایه داده پایه را به اشتراک می‌گذارد، تا دیگر هرگز مجبور به مغایرت‌گیری دستی صفحات گسترده نباشید. راه‌اندازی با جادوگر نصب یک بعدازظهر طول می‌کشد و ابزار مهاجرت همراه، داده‌ها را از QuickBooks، Sage و پایگاه‌های SQL قدیمی وارد می‌کند.",
    categorySlug: "erp-suite",
    type: "Module",
    platform: "ویندوز ۱۰/۱۱ · ویندوز سرور ۲۰۱۹ به بالا",
    accentColor: "#4f46e5",
    popularity: 982,
    isFeatured: true,
    trialDays: 30,
    features: [
      "دفتر کل چندشرکتی و چندارزی",
      "فرایند خرید با گردش کار تأیید و تطبیق سه‌جانبه",
      "ارزش‌گذاری لحظه‌ای موجودی (FIFO، میانگین و بهای استاندارد)",
      "داشبوردهای مبتنی بر نقش با بیش از ۱۴۰ گزارش استاندارد",
      "تاریخچه حسابرسی کامل با ثبت تغییرات تغییرناپذیر",
      "API وب سرویس و Webhook برای تمام موجودیت‌های کسب‌وکار",
    ],
    requirements: [
      "ویندوز ۱۰/۱۱ شصت‌وچهاربیتی یا ویندوز سرور ۲۰۱۹ به بالا",
      "۸ گیگابایت رم (برای بیش از ۲۵ کاربر ۱۶ گیگابایت توصیه می‌شود)",
      "SQL Server 2019/2022 یا PostgreSQL 14 به بالا",
      "۲ گیگابایت فضای خالی برای کلاینت دسکتاپ",
    ],
    gallery: ["داشبورد مدیریت", "ثبت سند حسابداری", "تأیید درخواست خرید"],
    plans: [
      { name: "تک‌کاربره", tier: "SingleUser", billing: "OneTime", price: 249000, seats: 1, description: "لایسنس دائمی برای یک دستگاه، شامل ۱۲ ماه به‌روزرسانی." },
      { name: "۵ کاربر", tier: "MultiUser", billing: "OneTime", price: 899000, seats: 5, popular: true, description: "لایسنس دائمی با داده پایه مشترک برای ۵ کاربر نامی." },
      { name: "سازمانی", tier: "Enterprise", billing: "Annual", price: 199900, seats: 250, description: "اشتراک سالانه، شرکت‌های نامحدود، مدیر موفقیت اختصاصی." },
    ],
  },
  {
    slug: "northwind-financials",
    name: "مالی نورث‌ویند",
    tagline: "بستن حساب‌ها در چند روز، نه چند هفته",
    description:
      "ماژول مالی قلب حسابداری مجموعه است: دفتر کل، حساب‌های پرداختنی و دریافتنی، دارایی ثابت و گزارش‌های تجمیعی. صورتحساب بانکی خودکار، اسناد تکراری و چک‌لیست پایان دوره، زمان بستن ماهانه را تا ۶۰٪ کاهش می‌دهد.\n\nاین ماژول با IFRS و GAAP سازگار است، از دفاتر موازی برای گزارشگری قانونی محلی پشتیبانی می‌کند و با یک کلیک برگه‌کار حسابرسی آماده تحویل به حسابرس تولید می‌کند.",
    categorySlug: "finance-accounting",
    type: "Module",
    platform: "ویندوز ۱۰/۱۱ · افزودنی وب موجود است",
    accentColor: "#0f766e",
    popularity: 745,
    isFeatured: true,
    trialDays: 30,
    features: [
      "دفاتر موازی برای IFRS و استانداردهای محلی",
      "تطبیق خودکار صورتحساب بانکی با موتور قواعد",
      "دفتر دارایی ثابت با برنامه‌ریزی استهلاک",
      "چک‌لیست بستن دوره با واگذاری وظایف",
      "خروجی برگه‌کار حسابرسی به PDF و Excel",
    ],
    requirements: [
      "ویندوز ۱۰/۱۱ شصت‌وچهاربیتی",
      "حداقل ۴ گیگابایت رم",
      "هسته ERP نورث‌ویند نسخه ۲۰۲۴٫۲ یا بالاتر",
      "دسترسی به اینترنت برای صورتحساب بانکی",
    ],
    gallery: ["چک‌لیست بستن دوره", "تطبیق بانکی", "سود و زیان تجمیعی"],
    plans: [
      { name: "تک‌کاربره", tier: "SingleUser", billing: "OneTime", price: 189000, seats: 1, description: "یک کاربر حسابداری با لایسنس دائمی." },
      { name: "تیم مالی", tier: "MultiUser", billing: "OneTime", price: 649000, seats: 5, popular: true, description: "پنج کاربر با ماتریس تأیید و تاریخچه حسابرسی." },
      { name: "سازمانی", tier: "Enterprise", billing: "Annual", price: 149900, seats: 250, description: "تجمیع گزارش‌ها در شرکت‌های نامحدود." },
    ],
  },
  {
    slug: "northwind-inventory-control",
    name: "کنترل موجودی نورث‌ویند",
    tagline: "بدانید دقیقاً چه چیزی دارید و کجا است",
    description:
      "کنترل موجودی دقت موجودی را در سطح قفسه و در انبارهای نامحدود فراهم می‌کند. شمارش دوره‌ای، رهگیری بچ و شماره سریال، مدیریت تاریخ انقضا و خودکارسازی نقطه سفارش، موجودی را بدون کسری کالا بهینه نگه می‌دارد.\n\nاپلیکیشن همراه موبایل (شامل محصول) به کارکنان انبار اجازه می‌دهد از هر دستگاه اندرویدی یا iOS کالا را اسکن، جابه‌جا و دریافت کنند.",
    categorySlug: "operations-inventory",
    type: "Module",
    platform: "ویندوز ۱۰/۱۱ · همراه موبایل",
    accentColor: "#b45309",
    popularity: 612,
    isFeatured: true,
    trialDays: 30,
    features: [
      "رهگیری در سطح قفسه در انبارهای نامحدود",
      "مدیریت بچ، شماره سریال و تاریخ انقضا",
      "اسکن بارکد با طراح برچسب",
      "خودکارسازی نقطه سفارش و پیشنهاد خرید",
      "شمارش دوره‌ای با تأیید مغایرت",
    ],
    requirements: [
      "ویندوز ۱۰/۱۱ شصت‌وچهاربیتی",
      "۴ گیگابایت رم",
      "هسته ERP نورث‌ویند نسخه ۲۰۲۴٫۱ یا بالاتر",
      "اختیاری: اسکنر USB برند Zebra یا Honeywell",
    ],
    gallery: ["نقشه انبار", "صفحه شمارش دوره‌ای", "داشبورد نقطه سفارش"],
    plans: [
      { name: "تک‌انبار", tier: "SingleUser", billing: "OneTime", price: 129000, seats: 2, description: "یک انبار، دو کاربر هم‌زمان." },
      { name: "چند انبار", tier: "MultiUser", billing: "OneTime", price: 399000, seats: 10, popular: true, description: "انبارهای نامحدود و ۱۰ کاربر نامی." },
      { name: "سازمانی", tier: "Enterprise", billing: "Annual", price: 99900, seats: 500, description: "شامل خودکارسازی WMS و یکپارچه‌سازی حمل‌ونقل." },
    ],
  },
  {
    slug: "northwind-hr-payroll",
    name: "منابع انسانی و حقوق نورث‌ویند",
    tagline: "عملیات منابع انسانی بدون آشفتگی صفحات گسترده",
    description:
      "یک ایستگاه کاری کامل منابع انسانی و حقوق: قراردادها، مرخصی، حضور و غیاب، ارزیابی عملکرد و اجرای حقوق با گزارش‌های قانونی ۱۴ کشور. کارکنان از طریق افزودنی پورتال اختیاری به اطلاعات خود دسترسی دارند.\n\nموتور حقوق، محاسبه ناخالص تا خالص، محاسبات بازگشتی، تخصیص هزینه به واحدها و صورتحساب پایان سال را مدیریت می‌کند.",
    categorySlug: "erp-suite",
    type: "Module",
    platform: "ویندوز ۱۰/۱۱",
    accentColor: "#be123c",
    popularity: 431,
    isFeatured: false,
    trialDays: 30,
    features: [
      "چرخه کامل کارکنان از پیشنهاد همکاری تا خروج",
      "موتور حقوق با محاسبات بازگشتی و خارج از چرخه",
      "مرخصی و حضور با سیاست‌های انباشت",
      "تخصیص هزینه به واحدها و پروژه‌ها",
      "گزارش‌های قانونی برای ۱۴ کشور",
    ],
    requirements: ["ویندوز ۱۰/۱۱ شصت‌وچهاربیتی", "۴ گیگابایت رم", "هسته ERP نورث‌ویند نسخه ۲۰۲۴٫۱ یا بالاتر", "زمان اجرای دسکتاپ NET 8."],
    gallery: ["پرونده کارمند", "اجرای حقوق", "تقویم مرخصی"],
    plans: [
      { name: "تا ۲۵ کارمند", tier: "SingleUser", billing: "OneTime", price: 165000, seats: 2, description: "دو کاربر منابع انسانی، ۲۵ پرونده کارمند." },
      { name: "تا ۱۰۰ کارمند", tier: "MultiUser", billing: "OneTime", price: 389000, seats: 6, popular: true, description: "شش کاربر منابع انسانی، ۱۰۰ پرونده کارمند." },
      { name: "سازمانی", tier: "Enterprise", billing: "Annual", price: 119900, seats: 1000, description: "کارمند نامحدود و پورتال سلف‌سرویس." },
    ],
  },
  {
    slug: "northwind-crm-desktop",
    name: "CRM دسکتاپ نورث‌ویند",
    tagline: "یک CRM سریع که روی دسکتاپ شما زندگی می‌کند",
    description:
      "CRM دسکتاپ یک مدیریت ارتباط با مشتری سبک و قابل استفاده آفلاین برای تیم‌هایی است که در صندوق ایمیل خود زندگی می‌کنند. با داده پایه مشتریان ERP همگام می‌شود، معاملات را در یک پایپ‌لاین کانبان دنبال می‌کند و هر تماس را خودکار ثبت می‌کند.\n\nبه‌طور کامل آفلاین کار می‌کند و پس از اتصال مجدد همگام می‌شود — برای تیم‌های فروش میدانی عالی است.",
    categorySlug: "desktop-productivity",
    type: "DesktopApp",
    platform: "ویندوز ۱۰/۱۱ · مک ۱۳ به بالا",
    accentColor: "#7c3aed",
    popularity: 1187,
    isFeatured: true,
    trialDays: 30,
    features: [
      "کلاینت دسکتاپ آفلاین‌محور با همگام‌سازی پس‌زمینه",
      "پایپ‌لاین کانبان معاملات با پیش‌بینی فروش",
      "یکپارچه‌سازی ایمیل و تقویم (Outlook و Gmail)",
      "ثبت تماس با یادآور پیگیری",
      "صدور پیش‌فاکتور مستقیم از فرصت فروش",
    ],
    requirements: ["ویندوز ۱۰/۱۱ یا مک ۱۳ به بالا", "۴ گیگابایت رم", "۵۰۰ مگابایت فضای خالی", "اختیاری: هسته ERP برای همگام‌سازی داده پایه"],
    gallery: ["برد پایپ‌لاین", "مشتری ۳۶۰", "سازنده پیش‌فاکتور"],
    plans: [
      { name: "تک‌کاربره", tier: "SingleUser", billing: "OneTime", price: 69000, seats: 1, description: "لایسنس دائمی یک دستگاه." },
      { name: "تیم فروش (۵ نفر)", tier: "MultiUser", billing: "OneTime", price: 249000, seats: 5, popular: true, description: "پنج کاربر با پایپ‌لاین و گزارش مشترک." },
      { name: "سازمانی", tier: "Enterprise", billing: "Annual", price: 59900, seats: 500, description: "اشتراک سالانه با ورود یکپارچه و قواعد قلمرو فروش." },
    ],
  },
  {
    slug: "northwind-point-of-sale",
    name: "صندوق فروشگاهی نورث‌ویند",
    tagline: "نرم‌افزار صندوق که مشتری را معطل نمی‌کند",
    description:
      "یک صندوق فروش لمسی‌محور برای خرده‌فروشی و رستوران. فروش، مرجوعی، کارت هدیه و باشگاه مشتریان را با دو لمس پردازش کنید، در زمان قطعی اینترنت به کار ادامه دهید و در پایان روز با ERP تسویه کنید.\n\nاز چاپگر رسید، کشو پول، اسکنر بارکد و نمایشگر مشتری پشتیبانی می‌کند.",
    categorySlug: "desktop-productivity",
    type: "DesktopApp",
    platform: "ویندوز ۱۰/۱۱ (بهینه‌شده برای لمس)",
    accentColor: "#0369a1",
    popularity: 803,
    isFeatured: false,
    trialDays: 30,
    features: [
      "صفحه صندوق لمسی با میان‌بُرهای صفحه‌کلید",
      "حالت آفلاین با همگام‌سازی خودکار پایان روز",
      "کارت هدیه، باشگاه مشتریان و موتور تخفیف",
      "پشتیبانی سخت‌افزار چاپگر، کشو و نمایشگر",
      "گزارش شیفت و تسویه نقدی",
    ],
    requirements: ["ویندوز ۱۰/۱۱ شصت‌وچهاربیتی", "۴ گیگابایت رم", "گرافیک سازگار با DirectX 11", "سخت‌افزار صندوق (اختیاری)"],
    gallery: ["صفحه صندوق", "گزارش شیفت", "سازنده تخفیف"],
    plans: [
      { name: "یک صندوق", tier: "SingleUser", billing: "OneTime", price: 99000, seats: 1, description: "یک صندوق، لایسنس دائمی." },
      { name: "فروشگاه (۵ صندوق)", tier: "MultiUser", billing: "OneTime", price: 349000, seats: 5, popular: true, description: "پنج صندوق با مدیریت متمرکز قیمت." },
      { name: "زنجیره", tier: "Enterprise", billing: "Annual", price: 129900, seats: 1000, description: "صندوق نامحدود در همه شعب." },
    ],
  },
  {
    slug: "northwind-document-manager",
    name: "مدیریت اسناد نورث‌ویند",
    tagline: "هر فاکتور، قرارداد و نقشه در یک جای قابل جستجو",
    description:
      "یک برنامه دسکتاپ مدیریت اسناد با جستجوی متن کامل، تاریخچه نسخه‌ها، OCR و سیاست‌های نگهداشت. فایل‌ها را بکشید و رها کنید، به مشتریان یا پروژه‌ها متصل کنید و هر چیزی را در کمتر از یک ثانیه پیدا کنید.\n\nشامل موتور قواعدی است که اسناد اسکن‌شده ورودی را خودکار بایگانی می‌کند.",
    categorySlug: "desktop-productivity",
    type: "DesktopApp",
    platform: "ویندوز ۱۰/۱۱",
    accentColor: "#4d7c0f",
    popularity: 366,
    isFeatured: false,
    trialDays: 30,
    features: [
      "جستجوی متن کامل با OCR فایل‌های PDF اسکن‌شده",
      "تاریخچه نسخه‌ها با مقایسه کنار هم",
      "سیاست نگهداشت و توقف قضایی",
      "قواعد بایگانی خودکار اسناد ورودی",
      "یکپارچه‌سازی با ویندوز اکسپلورر",
    ],
    requirements: ["ویندوز ۱۰/۱۱ شصت‌وچهاربیتی", "۴ گیگابایت رم", "۲ گیگابایت فضای خالی", "اختیاری: اسکنر TWAIN"],
    gallery: ["نتایج جستجو", "مقایسه نسخه‌ها", "قواعد نگهداشت"],
    plans: [
      { name: "تک‌کاربره", tier: "SingleUser", billing: "OneTime", price: 54000, seats: 1, description: "لایسنس یک دستگاه با ۱۰ گیگابایت آرشیو." },
      { name: "تیمی (۵ نفر)", tier: "MultiUser", billing: "OneTime", price: 189000, seats: 5, popular: true, description: "آرشیو مشترک با مدیریت دسترسی." },
      { name: "سازمانی", tier: "Enterprise", billing: "Annual", price: 39900, seats: 1000, description: "آرشیو نامحدود با بسته انطباق." },
    ],
  },
  {
    slug: "northwind-bi-connector",
    name: "کانکتور هوش تجاری نورث‌ویند",
    tagline: "انتقال مستقیم داده ERP به Power BI و Tableau",
    description:
      "کانکتور هوش تجاری یک مدل معنایی مستند و پردازش‌شده از داده‌های ERP شما — ابعاد، واقعیت‌ها و شاخص‌ها — را به‌صورت یک نقطه پایانی سریع OData و SQL در اختیار می‌گذارد. دیگر نیازی به نوشتن کوئری‌های استخراج دستی نیست.\n\nهمراه با ۳۰ قالب گزارش Power BI از پیش ساخته‌شده عرضه می‌شود.",
    categorySlug: "addons-integrations",
    type: "AddOn",
    platform: "ویندوز سرور ۲۰۱۹ به بالا · لینوکس (Docker)",
    accentColor: "#0891b2",
    popularity: 528,
    isFeatured: true,
    trialDays: 14,
    features: [
      "مدل معنایی پردازش‌شده با بیش از ۴۰۰ شاخص",
      "نقاط پایانی OData نسخه ۴ و SQL",
      "به‌روزرسانی افزایشی با رهگیری تغییرات",
      "۳۰ قالب آماده Power BI",
      "انتقال امنیت در سطح ردیف",
    ],
    requirements: ["ویندوز سرور ۲۰۱۹ به بالا یا هاست Docker", "۴ گیگابایت رم", "هسته ERP نورث‌ویند نسخه ۲۰۲۴٫۱ یا بالاتر", "Power BI Desktop 2024 به بالا (برای قالب‌ها)"],
    gallery: ["مرورگر مدل", "پایش به‌روزرسانی", "گالری قالب‌ها"],
    plans: [
      { name: "تک‌کاربره", tier: "SingleUser", billing: "Annual", price: 39000, seats: 1, description: "اشتراک سالانه برای یک تحلیلگر." },
      { name: "تیم تحلیل", tier: "MultiUser", billing: "Annual", price: 129000, seats: 10, popular: true, description: "ده تحلیلگر با حاکمیت مدل مشترک." },
      { name: "سازمانی", tier: "Enterprise", billing: "Annual", price: 29900, seats: 500, description: "تحلیلگر نامحدود با ورود یکپارچه." },
    ],
  },
  {
    slug: "northwind-einvoice-gateway",
    name: "درگاه فاکتور الکترونیکی نورث‌ویند",
    tagline: "انطباق با الزامات فاکتور الکترونیکی",
    description:
      "فاکتورهای ساختاریافته را در قالب‌های Peppol BIS 3.0، UBL و XRechnung ارسال و دریافت کنید. این درگاه هر سند را اعتبارسنجی، امضا، مسیریابی و بایگانی می‌کند و رهگیری کامل قانونی فراهم می‌کند.\n\nالزامات اتحادیه اروپا، بریتانیا و سنگاپور را پوشش می‌دهد و قالب‌های جدید به‌مرور اضافه می‌شوند.",
    categorySlug: "addons-integrations",
    type: "AddOn",
    platform: "ویندوز سرور ۲۰۱۹ به بالا · Docker",
    accentColor: "#a16207",
    popularity: 297,
    isFeatured: false,
    trialDays: 14,
    features: [
      "پشتیبانی Peppol BIS 3.0، UBL 2.1 و XRechnung",
      "اعتبارسنجی ساختار پیش از ارسال",
      "امضای دیجیتال با گواهی‌های معتبر",
      "آرشیو قانونی هفت‌ساله",
      "Webhook وضعیت تحویل",
    ],
    requirements: ["ویندوز سرور ۲۰۱۹ به بالا یا هاست Docker", "۲ گیگابایت رم", "مالی نورث‌ویند نسخه ۲۰۲۴٫۱ یا بالاتر", "گواهی امضای معتبر"],
    gallery: ["نمایشگر سند", "پایش انطباق", "جستجوی آرشیو"],
    plans: [
      { name: "کسب‌وکار کوچک", tier: "SingleUser", billing: "Annual", price: 29000, seats: 1, description: "تا ۵۰۰ سند در ماه." },
      { name: "کسب‌وکار در حال رشد", tier: "MultiUser", billing: "Annual", price: 79000, seats: 5, popular: true, description: "تا ۱۰٬۰۰۰ سند در ماه." },
      { name: "سازمانی", tier: "Enterprise", billing: "Annual", price: 19900, seats: 500, description: "حجم نامحدود با مسیریابی اختصاصی." },
    ],
  },
  {
    slug: "northwind-warehouse-scanner",
    name: "اسکنر انبار نورث‌ویند",
    tagline: "هر دستگاه اندرویدی را به ترمینال اسکن تبدیل کنید",
    description:
      "افزونه اسکنر انبار، جریان‌های سریع برداشت، بسته‌بندی و جابه‌جایی را از طریق دستگاه‌های دستی اندرویدی مقاوم یا گوشی‌های معمولی به کنترل موجودی اضافه می‌کند. صف آفلاین، راهنمای صوتی و مدرک تصویری تحویل نیز شامل است.\n\nپروفایل‌های مدیریت دستگاه، استقرار روی ۵۰۰ دستگاه را به کاری یک‌نفره تبدیل می‌کند.",
    categorySlug: "addons-integrations",
    type: "AddOn",
    platform: "اندروید ۱۰ به بالا · سرور ۲۰۱۹ به بالا",
    accentColor: "#c2410c",
    popularity: 254,
    isFeatured: false,
    trialDays: 14,
    features: [
      "جریان‌های برداشت، بسته‌بندی و جابه‌جایی",
      "صف آفلاین با حل تعارض",
      "مدرک تصویری تحویل",
      "پروفایل مدیریت دستگاه و حالت کیوسک",
      "پشتیبانی دستگاه‌های مقاوم (Zebra، Honeywell، Datalogic)",
    ],
    requirements: ["اندروید ۱۰ یا بالاتر", "کنترل موجودی نورث‌ویند ۲۰۲۴٫۱ به بالا", "وای‌فای در انبار", "حساب سرویس با نقش انبار"],
    gallery: ["جریان برداشت", "پروفایل دستگاه‌ها", "مدرک تحویل"],
    plans: [
      { name: "۵ دستگاه", tier: "SingleUser", billing: "Annual", price: 45000, seats: 5, description: "اشتراک سالانه برای ۵ دستگاه." },
      { name: "۲۵ دستگاه", tier: "MultiUser", billing: "Annual", price: 149000, seats: 25, popular: true, description: "۲۵ دستگاه با مدیریت کیوسک." },
      { name: "سازمانی", tier: "Enterprise", billing: "Annual", price: 39900, seats: 1000, description: "دستگاه نامحدود با یکپارچه‌سازی MDM." },
    ],
  },
];

const CUSTOMERS = [
  { email: "admin@northwindsoft.example", fullName: "الکساندرا ریز", role: "Admin" as const, company: "نورث‌ویند", country: "ایالات متحده" },
  { email: "casey.demo@example.com", fullName: "کیسی ویتفیلد", role: "Customer" as const, company: "تولیدی ساحل", country: "ایالات متحده" },
  { email: "priya.demo@example.com", fullName: "پریا راگاوان", role: "Customer" as const, company: "توزیع پیشرو", country: "بریتانیا" },
  { email: "marcus.demo@example.com", fullName: "مارکوس دلگادو", role: "Customer" as const, company: "گروه خرده‌فروشی دلگادو", country: "اسپانیا" },
  { email: "hana.demo@example.com", fullName: "هانا کوبایاشی", role: "Customer" as const, company: "دقت کوبایاشی", country: "ژاپن" },
];

const REVIEW_SEEDS: { productSlug: string; author: string; company: string; rating: number; title: string; body: string; status: "Approved" | "Pending" | "Rejected" }[] = [
  { productSlug: "northwind-erp-core", author: "تام برانت", company: "قطعات هلیکس", rating: 5, title: "بستن حساب از ۹ روز به ۳ روز رسید", body: "سه سیستم جدا را با هسته ERP به‌همراه ماژول مالی جایگزین کردیم. ابزار مهاجرت شش سال داده را در یک آخر هفته وارد کرد و تاریخچه حسابرسی دو بار در حسابرسی‌های فروشنده نجاتمان داد.", status: "Approved" },
  { productSlug: "northwind-erp-core", author: "ریتا آلوارز", company: "غذایی نورت‌گیت", rating: 4, title: "قدرتمند، اما نیازمند یادگیری", body: "عمق این محصول واقعاً چشمگیر است. برای آموزش وقت بگذارید — تیم ما دو هفته لازم داشت — اما وقتی مسلط شدند دیگر هیچ‌کس نمی‌خواهد به صفحات گسترده برگردد.", status: "Approved" },
  { productSlug: "northwind-erp-core", author: "دنیل اوسِی", company: "فلزات اوسید", rating: 5, title: "تجمیع چندشرکتی واقعاً کار می‌کند", body: "۷ شرکت حقوقی در ۴ ارز اجرا می‌کنیم. تجمیع قبلاً کاری دو‌نفره و پنج‌روزه بود. الان یک اجرای گزارش است.", status: "Approved" },
  { productSlug: "northwind-financials", author: "ماریون فاوست", company: "فاوست و شرکا", rating: 5, title: "حسابرس‌ها برگه‌کار را دوست دارند", body: "پایان سال یعنی یک هفته اسکرین‌شات گرفتن. الان خروجی برگه‌کار یک کلیک است و حسابرس ما بدون حتی یک سؤال تکمیلی همه را پذیرفت.", status: "Approved" },
  { productSlug: "northwind-financials", author: "سون لیندکوییست", company: "بالتیک ترید", rating: 4, title: "صورتحساب بانکی زمان‌ساز است", body: "تطبیق خودکار حدود ۸۵٪ ردیف‌های ما را مدیریت می‌کند. موتور قواعد سریع یاد می‌گیرد. کاش ماژول دارایی ثابت قالب‌های استهلاک بیشتری داشت.", status: "Approved" },
  { productSlug: "northwind-inventory-control", author: "گریس ام‌بکی", company: "کشاورزی دره ریفت", rating: 5, title: "شمارش دوره‌ای عملیات ما را تغییر داد", body: "از شمارش سالانه به شمارش دوره‌ای روزانه رفتیم. تأیید مغایرت همه را صادق نگه می‌دارد و دقت ما از ۹۱٪ به ۹۹٫۴٪ رسید.", status: "Approved" },
  { productSlug: "northwind-inventory-control", author: "پیتر نوواک", company: "لجستیک نوواک", rating: 4, title: "عالی، اپ موبایل می‌تواند سریع‌تر باشد", body: "ماژول دسکتاپ کاملاً پایدار است. همراه موبایل کاربردی است اما روی دستگاه‌های قدیمی کمی کند است.", status: "Approved" },
  { productSlug: "northwind-hr-payroll", author: "لنا فیشر", company: "کارخان فیشر", rating: 4, title: "حقوق بدون دردسر اجرا می‌شود", body: "محاسبات بازگشتی قبلاً کابوس بود. الان یک تب در اجرای حقوق است. کاش بومی‌سازی بیشتری برای اتریش داشت.", status: "Approved" },
  { productSlug: "northwind-crm-desktop", author: "اوون بلیک", company: "صنایع بلیک", rating: 5, title: "واقعاً سریع است", body: "در کمتر از دو ثانیه باز می‌شود و در قطع اینترنت هم کار می‌کند. تیم میدانی ما بالاخره تماس‌هایش را ثبت می‌کند چون بی‌زحمت است.", status: "Approved" },
  { productSlug: "northwind-crm-desktop", author: "سوفیا مارکتی", company: "استودیو مارکتی", rating: 5, title: "سازنده پیش‌فاکتور گنج پنهان است", body: "صدور پیش‌فاکتور مستقیم از یک فرصت فروش، با قالب‌ها و قواعد قیمت‌گذاری ما، روزی یک ساعت وقتم را آزاد می‌کند.", status: "Approved" },
  { productSlug: "northwind-crm-desktop", author: "خریدار تأییدنشده", company: "", rating: 3, title: "قابل قبول اما ویرایش گروهی ندارد", body: "با ویرایش گروهی فرصت‌های فروش پنج ستاره می‌شد.", status: "Pending" },
  { productSlug: "northwind-point-of-sale", author: "آمارا دیالو", company: "فروشگاه‌های دیالو", rating: 5, title: "قطعی اینترنت ما را از پای درنیاورد", body: "اینترنت ما در شلوغ‌ترین ساعت شنبه چهار ساعت قطع شد. صندوق به‌صورت آفلاین به فروش ادامه داد و بعداً بی‌نقص تسویه کرد.", status: "Approved" },
  { productSlug: "northwind-point-of-sale", author: "یوناس وبر", company: "وبر گاسترو", rating: 4, title: "صندوق محکم، نصب سخت‌افزار آسان", body: "دو صندوق با چاپگر و کشو پول را در حدود ۲۰ دقیقه برای هر ایستگاه راه‌اندازی کردم.", status: "Approved" },
  { productSlug: "northwind-document-manager", author: "النا پترووا", company: "حقوقی پترووا", rating: 4, title: "دقت OCR شگفت‌آور است", body: "چهل هزار صفحه قرارداد قدیمی را اسکن کردم. جستجو بند‌ها را در چند ثانیه پیدا می‌کند. سیاست‌های نگهداشت ما را منطبق نگه می‌دارد.", status: "Approved" },
  { productSlug: "northwind-bi-connector", author: "ویکتور سورنسن", company: "سورنسن مارین", rating: 5, title: "اسکریپت‌های استخراج ما حذف شد", body: "چهار هزار خط SQL دست‌نویس را پاک کردیم. مدل معنایی مستند است و قالب‌های Power BI نقطه شروع خوبی هستند.", status: "Approved" },
  { productSlug: "northwind-bi-connector", author: "آنا دوآرته", company: "تحلیل دوآرته", rating: 4, title: "مدل عالی، شاخص‌های بیشتری می‌خواهم", body: "انتقال امنیت در سطح ردیف خوب کار می‌کند. دوست دارم شاخص‌های بیشتری از زنجیره تأمین در دسترس بود.", status: "Approved" },
  { productSlug: "northwind-einvoice-gateway", author: "لوکاس مایر", company: "مایر هندل", rating: 5, title: "انطباق XRechnung حل شد", body: "انطباق با الزام آلمان بدون استخدام مشاور. اعتبارسنجی خطاهای ما را قبل از اداره مالیات پیدا می‌کند.", status: "Approved" },
  { productSlug: "northwind-warehouse-scanner", author: "فاطمه ناصر", company: "خلیج فریت", rating: 4, title: "استقرار روی ۱۲۰ دستگاه دستی", body: "پروفایل دستگاه‌ها استقرار را به کاری یک‌نفره تبدیل کرد. صف آفلاین نقاط کور راهروهای انبار را پوشش می‌دهد.", status: "Approved" },
  { productSlug: "northwind-warehouse-scanner", author: "ناشناس", company: "", rating: 2, title: "پشتیبانی دستگاه‌های قدیمی ضعیف است", body: "با دستگاه‌های دستی سال ۲۰۱۵ ما کار نکرد.", status: "Pending" },
  { productSlug: "northwind-document-manager", author: "ربات هرزنامه", company: "", rating: 5, title: "اینجا دنبال‌کننده ارزان بخرید", body: "محتوای تبلیغاتی کاملاً بی‌ربط.", status: "Rejected" },
];

const TESTIMONIALS = [
  { authorName: "اینگرید هالورسن", authorRole: "مدیر مالی", company: "غذایی نورت‌گیت", quote: "هفت شرکت را در یک استقرار هسته ERP تجمیع کردیم. بستن ماهانه از نه روز به سه روز رسید و حسابرسان بدون یک سؤال تکمیلی تأیید کردند.", rating: 5, sortOrder: 1 },
  { authorName: "مارکوس دلگادو", authorRole: "مدیر فناوری اطلاعات", company: "گروه خرده‌فروشی دلگادو", quote: "چهل‌ویک شعبه، یک لیست قیمت، صفر مهاجرت آخر هفته. تنها حالت آفلاین صندوق، هزینه پروژه را در فصل اول برگرداند.", rating: 5, sortOrder: 2 },
  { authorName: "هانا کوبایاشی", authorRole: "مدیر عملیات", company: "دقت کوبایاشی", quote: "دقت موجودی پس از گذر به شمارش دوره‌ای با افزونه اسکنر از ۹۱٪ به ۹۹٫۴٪ رسید. مشتریان ما زودتر از خودمان متوجه شدند.", rating: 5, sortOrder: 3 },
  { authorName: "پریا راگاوان", authorRole: "رئیس مالی", company: "توزیع پیشرو", quote: "کانکتور هوش تجاری، انباری از SQL دست‌نویس را با مدلی مستند جایگزین کرد که تحلیلگران ما واقعاً به آن اعتماد دارند.", rating: 5, sortOrder: 4 },
  { authorName: "تام برانت", authorRole: "مدیرعامل", company: "قطعات هلیکس", quote: "پشتیبانی در چند ساعت پاسخ می‌دهد، نه چند روز. وقتی به یک حالت مرزی در قواعد مالیاتی خوردیم، وصله در همان هفته منتشر شد.", rating: 5, sortOrder: 5 },
  { authorName: "آمارا دیالو", authorRole: "مالک", company: "فروشگاه‌های دیالو", quote: "من حسابدار نیستم و باز هم حساب‌هایم را خودم مدیریت می‌کنم. جادوگر راه‌اندازی واقعاً کار می‌کند.", rating: 5, sortOrder: 6 },
];

const FAQS = [
  { question: "لایسنس این مجموعه چگونه است؟", answer: "هر محصول با پلن تک‌کاربره، چندکاربره و سازمانی عرضه می‌شود. ماژول‌های ERP و برنامه‌های دسکتاپ به‌صورت لایسنس دائمی (پرداخت یک‌باره) همراه با ۱۲ ماه به‌روزرسانی موجودند و افزونه‌ها و پلن سازمانی به‌صورت سالانه صورتحساب می‌شوند.", sortOrder: 1 },
  { question: "نسخه آزمایشی رایگان دارید؟", answer: "بله — هر محصول یک نسخه آزمایشی کامل دارد (۳۰ روز برای ماژول‌ها و برنامه‌های دسکتاپ، ۱۴ روز برای افزونه‌ها). نیازی به کارت بانکی نیست و داده‌های آزمایشی به نصب لایسنس‌شده شما منتقل می‌شود.", sortOrder: 2 },
  { question: "تخفیف حجمی یا سازمانی ارائه می‌دهید؟", answer: "بله. پلن‌های حجمی از ۱۰ کاربر شروع می‌شوند و مؤسسات غیرانتفاعی و آموزشی ثبت‌شده ۴۰٪ تخفیف از قیمت فهرستی دریافت می‌کنند. برای پیشنهاد اختصاصی با فروش تماس بگیرید.", sortOrder: 3 },
  { question: "پشتیبانی شامل چه مواردی می‌شود؟", answer: "همه پلن‌ها شامل دسترسی به دانشنامه و انجمن کاربران است. پلن‌های چندکاربره و سازمانی پشتیبانی ایمیل و تلفنی در ساعات کاری با هدف پاسخ اولیه ۴ ساعته را نیز اضافه می‌کنند.", sortOrder: 4 },
  { question: "می‌توانم سرور پایگاه داده خودم را اجرا کنم؟", answer: "قطعاً. مجموعه از SQL Server یا PostgreSQL درون‌سازمانی پشتیبانی می‌کند و ما هرگز داده شما را گروگان نمی‌گیریم — خروجی کامل در هر زمان از کنسول مدیریت در دسترس است.", sortOrder: 5 },
  { question: "فرایند ارتقا چگونه است؟", answer: "نسخه‌های فرعی درجا و در کمتر از ۱۰ دقیقه نصب می‌شوند. نسخه‌های اصلی با یک برنامه‌ریز مهاجرت عرضه می‌شوند که پیش از تأیید، شخصی‌سازی‌ها را اعتبارسنجی می‌کند و تا ۳۰ روز امکان بازگشت دارید.", sortOrder: 6 },
  { question: "سیاست بازگشت وجه چیست؟", answer: "لایسنس‌های دائمی ۳۰ روز ضمانت بازگشت وجه بدون قید و شرط دارند. اشتراک‌های سالانه در ۶۰ روز اول به‌صورت تناسبی قابل لغو هستند.", sortOrder: 7 },
  { question: "با سیستم‌های فعلی ما یکپارچه می‌شود؟", answer: "پلتفرم برای تمام موجودیت‌های کسب‌وکار یک API مستند و Webhook ارائه می‌کند و کانکتورهای تأییدشده برای Power BI، Tableau، Shopify و بیش از ۴۰ سرویس پرداخت و لجستیک دارد.", sortOrder: 8 },
];

function daysAgo(days: number) {
  return new Date(Date.now() - days * 86_400_000);
}

function licenseKey(index: number) {
  const charset = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  const group = (seed: number, n: number) =>
    Array.from({ length: n }, (_, i) => charset[(seed * (i + 3) * 31 + index * 17) % charset.length]).join("");
  return `NW-${group(1, 5)}-${group(7, 5)}-${group(13, 5)}-${group(19, 5)}`;
}

export async function isSeeded(): Promise<boolean> {
  const [row] = await db.select({ value: count() }).from(products);
  return (row?.value ?? 0) > 0;
}

export async function seedDatabase(): Promise<{ seeded: boolean }> {
  if (await isSeeded()) return { seeded: false };

  const passwordHash = hashPassword(DEMO_PASSWORD);

  const insertedUsers = await db
    .insert(users)
    .values(
      CUSTOMERS.map((c, i) => ({
        email: c.email,
        fullName: c.fullName,
        company: c.company,
        country: c.country,
        role: c.role,
        passwordHash,
        phone: `+1 (555) 01${(10 + i).toString().padStart(2, "0")}`,
        createdAt: daysAgo(300 - i * 20),
        lastLoginAt: daysAgo(i),
      })),
    )
    .returning();
  const userByEmail = new Map(insertedUsers.map((u) => [u.email, u]));

  const insertedCategories = await db.insert(categories).values(CATEGORY_DATA.map((c) => ({ ...c }))).returning();
  const categoryBySlug = new Map(insertedCategories.map((c) => [c.slug, c]));

  const productIds: Record<string, string> = {};
  const planIdByProduct: Record<string, string[]> = {};

  for (const p of PRODUCTS) {
    const [row] = await db
      .insert(products)
      .values({
        slug: p.slug,
        name: p.name,
        tagline: p.tagline,
        description: p.description,
        categoryId: categoryBySlug.get(p.categorySlug)!.id,
        type: p.type,
        platform: p.platform,
        version: "2025.2.1",
        basePriceCents: p.plans[0].price,
        accentColor: p.accentColor,
        popularity: p.popularity,
        isFeatured: p.isFeatured,
        isActive: true,
        features: p.features,
        systemRequirements: p.requirements,
        gallery: p.gallery,
        demoVideoUrl: "https://cdn.northwindsoft.example/demos/product-tour.mp4",
        trialDays: p.trialDays,
        createdAt: daysAgo(400 - Math.round(p.popularity / 10)),
        updatedAt: daysAgo(6),
      })
      .returning();
    productIds[p.slug] = row.id;

    const plans = await db
      .insert(productPlans)
      .values(
        p.plans.map((plan, idx) => ({
          productId: row.id,
          name: plan.name,
          tier: plan.tier,
          billingType: plan.billing,
          priceCents: plan.price,
          seats: plan.seats,
          description: plan.description,
          isPopular: Boolean(plan.popular),
          sortOrder: idx,
        })),
      )
      .returning();
    planIdByProduct[p.slug] = plans.map((pl) => pl.id);

    await db.insert(productVersions).values(
      [
        { version: "2025.2.1", days: 6, notes: "افزودن موتور قواعد مغایرت‌گیری، بازطراحی سازنده داشبورد و بهبود ۴۰٪ کارایی اسناد حجیم." },
        { version: "2025.1.3", days: 74, notes: "انتشار نگهدارتی: ۲۷ رفع خطا، به‌روزرسانی قالب‌های قانونی فصل اول و حالت تاریک در تمام صفحات ثبت." },
        { version: "2024.4.0", days: 168, notes: "انتشار اصلی با معرفی API نسخه ۲، همراه موبایل آفلاین و بهینه‌سازی جابه‌جایی در چند انبار." },
      ].map((v) => ({
        productId: row.id,
        version: v.version,
        releasedAt: daysAgo(v.days),
        notes: v.notes,
        installerUrl: `https://cdn.northwindsoft.example/installers/${p.slug}/${v.version}/setup.exe`,
        sizeMb: 120 + (p.popularity % 180),
        platform: p.platform.split(" · ")[0],
      })),
    );
  }

  await db.insert(reviews).values(
    REVIEW_SEEDS.map((r, i) => ({
      productId: productIds[r.productSlug],
      userId: insertedUsers[(i % 4) + 1].id,
      authorName: r.author,
      authorCompany: r.company || null,
      rating: r.rating,
      title: r.title,
      body: r.body,
      status: r.status,
      createdAt: daysAgo(3 + i * 4),
    })),
  );

  await db.execute(sql`
    update products p set
      rating_avg = coalesce((select round(avg(r.rating) * 10) from reviews r where r.product_id = p.id and r.status = 'Approved'), 0),
      rating_count = coalesce((select count(*) from reviews r where r.product_id = p.id and r.status = 'Approved'), 0)
  `);

  await db.insert(discountCodes).values([
    { code: "LAUNCH25", description: "جشنواره عرضه — ۲۵٪ تخفیف روی هر لایسنس دائمی", percentOff: 25, maxRedemptions: 500, timesRedeemed: 132, expiresAt: daysAgo(-60), isActive: true },
    { code: "BUNDLE15", description: "۱۵٪ تخفیف برای خرید دو ماژول یا بیشتر", percentOff: 15, maxRedemptions: 0, timesRedeemed: 41, isActive: true },
    { code: "RENEW10", description: "۱۰٪ تخفیف تمدید برای مشتریان فعلی", percentOff: 10, maxRedemptions: 0, timesRedeemed: 210, isActive: true },
    { code: "EXPIRED20", description: "جشنواره آرشیوشده زمستان", percentOff: 20, maxRedemptions: 200, timesRedeemed: 200, expiresAt: daysAgo(45), isActive: false },
  ]);

  const orderPlan: { email: string; productSlug: string; planIndex: number; qty: number; days: number; status: "Completed" | "Paid" | "Processing" | "Refunded"; code?: string }[] = [
    { email: "casey.demo@example.com", productSlug: "northwind-erp-core", planIndex: 1, qty: 1, days: 210, status: "Completed", code: "LAUNCH25" },
    { email: "casey.demo@example.com", productSlug: "northwind-financials", planIndex: 1, qty: 1, days: 208, status: "Completed" },
    { email: "casey.demo@example.com", productSlug: "northwind-bi-connector", planIndex: 1, qty: 2, days: 96, status: "Completed" },
    { email: "priya.demo@example.com", productSlug: "northwind-erp-core", planIndex: 2, qty: 1, days: 175, status: "Completed", code: "BUNDLE15" },
    { email: "priya.demo@example.com", productSlug: "northwind-inventory-control", planIndex: 1, qty: 1, days: 122, status: "Completed" },
    { email: "priya.demo@example.com", productSlug: "northwind-warehouse-scanner", planIndex: 1, qty: 1, days: 38, status: "Paid" },
    { email: "marcus.demo@example.com", productSlug: "northwind-point-of-sale", planIndex: 1, qty: 2, days: 150, status: "Completed" },
    { email: "marcus.demo@example.com", productSlug: "northwind-crm-desktop", planIndex: 0, qty: 3, days: 64, status: "Completed" },
    { email: "marcus.demo@example.com", productSlug: "northwind-document-manager", planIndex: 1, qty: 1, days: 21, status: "Paid" },
    { email: "hana.demo@example.com", productSlug: "northwind-erp-core", planIndex: 1, qty: 1, days: 118, status: "Completed" },
    { email: "hana.demo@example.com", productSlug: "northwind-hr-payroll", planIndex: 1, qty: 1, days: 44, status: "Processing" },
    { email: "hana.demo@example.com", productSlug: "northwind-einvoice-gateway", planIndex: 0, qty: 1, days: 12, status: "Paid" },
    { email: "casey.demo@example.com", productSlug: "northwind-crm-desktop", planIndex: 1, qty: 1, days: 5, status: "Paid" },
    { email: "marcus.demo@example.com", productSlug: "northwind-bi-connector", planIndex: 0, qty: 1, days: 30, status: "Refunded" },
  ];

  let orderSeq = 0;
  const year = new Date().getFullYear();
  for (const line of orderPlan) {
    orderSeq += 1;
    const user = userByEmail.get(line.email)!;
    const product = PRODUCTS.find((p) => p.slug === line.productSlug)!;
    const plan = product.plans[line.planIndex];
    const subtotal = plan.price * line.qty;
    const discount =
      line.code === "LAUNCH25"
        ? Math.round(subtotal * 0.25)
        : line.code === "BUNDLE15"
          ? Math.round(subtotal * 0.15)
          : 0;
    const tax = Math.round(((subtotal - discount) * 800) / 10_000);
    const total = subtotal - discount + tax;

    const [order] = await db
      .insert(orders)
      .values({
        orderNumber: `NW-${year}-${String(orderSeq).padStart(4, "0")}`,
        userId: user.id,
        status: line.status,
        subtotalCents: subtotal,
        discountCents: discount,
        taxCents: tax,
        totalCents: total,
        discountCode: line.code ?? null,
        billingName: user.fullName,
        billingCompany: user.company,
        billingEmail: user.email,
        billingCountry: user.country,
        placedAt: daysAgo(line.days),
      })
      .returning();

    await db.insert(orderItems).values({
      orderId: order.id,
      productId: productIds[product.slug],
      planId: planIdByProduct[product.slug][line.planIndex],
      productName: product.name,
      planName: plan.name,
      billingType: plan.billing,
      unitPriceCents: plan.price,
      quantity: line.qty,
      lineTotalCents: subtotal,
    });

    await db.insert(payments).values({
      orderId: order.id,
      provider: "MockGateway",
      method: line.days % 3 === 0 ? "bank-transfer" : "card",
      amountCents: total,
      status: line.status === "Refunded" ? "Refunded" : "Succeeded",
      transactionRef: `txn_seed_${orderSeq}${Math.random().toString(36).slice(2, 8)}`,
      paidAt: daysAgo(line.days),
      createdAt: daysAgo(line.days),
    });

    await db.insert(invoices).values({
      invoiceNumber: `INV-${year}-${String(orderSeq).padStart(4, "0")}`,
      orderId: order.id,
      status: line.status === "Paid" || line.status === "Completed" ? "Paid" : "Issued",
      totalCents: total,
      taxCents: tax,
      issuedAt: daysAgo(line.days),
      dueAt: daysAgo(line.days - 14),
    });

    if (line.status !== "Refunded") {
      const expiresAt = plan.billing === "Annual" ? new Date(daysAgo(line.days).getTime() + 365 * 86_400_000) : null;
      for (let i = 0; i < line.qty; i += 1) {
        const [license] = await db
          .insert(licenses)
          .values({
            licenseKey: licenseKey(orderSeq * 7 + i),
            userId: user.id,
            productId: productIds[product.slug],
            planId: planIdByProduct[product.slug][line.planIndex],
            orderId: order.id,
            seats: plan.seats,
            activationsUsed: Math.min(plan.seats, 1 + (orderSeq % 2)),
            status: "Active",
            issuedAt: daysAgo(line.days),
            expiresAt,
          })
          .returning();
        if (i === 0) {
          await db.insert(licenseActivations).values({
            licenseId: license.id,
            machineName: `${user.company?.split(" ")[0]?.toUpperCase()}-WS-01`,
            machineHash: `hash_${license.id.slice(0, 8)}`,
            activatedAt: daysAgo(Math.max(1, line.days - 1)),
          });
        }
      }
    }
  }

  const casey = userByEmail.get("casey.demo@example.com")!;
  await db
    .update(licenses)
    .set({ status: "Expired", expiresAt: daysAgo(2) })
    .where(
      sql`${licenses.userId} = ${casey.id} and ${licenses.expiresAt} is not null and ${licenses.expiresAt} < now() + interval '120 days'`,
    );

  const priya = userByEmail.get("priya.demo@example.com")!;
  await db
    .update(licenses)
    .set({ status: "Revoked" })
    .where(sql`${licenses.userId} = ${priya.id} and ${licenses.expiresAt} is null`);

  await db.insert(downloads).values(
    [
      { email: "casey.demo@example.com", slug: "northwind-erp-core", days: 200 },
      { email: "casey.demo@example.com", slug: "northwind-bi-connector", days: 90 },
      { email: "priya.demo@example.com", slug: "northwind-erp-core", days: 170 },
      { email: "priya.demo@example.com", slug: "northwind-warehouse-scanner", days: 30 },
      { email: "marcus.demo@example.com", slug: "northwind-point-of-sale", days: 140 },
      { email: "hana.demo@example.com", slug: "northwind-hr-payroll", days: 40 },
    ].map((d) => ({
      userId: userByEmail.get(d.email)!.id,
      productId: productIds[d.slug],
      versionId: null,
      kind: "installer",
      fileName: `${d.slug}-2025.2.1-setup.exe`,
      sizeMb: 180,
      downloadedAt: daysAgo(d.days),
    })),
  );

  interface SeedTicket {
    email: string;
    productSlug: string;
    subject: string;
    category: string;
    priority: "Low" | "Normal" | "High" | "Critical";
    status: "Open" | "InProgress" | "WaitingCustomer" | "Resolved" | "Closed";
    env: string;
    messages: { body: string; staff: boolean; days: number }[];
  }

  const TICKETS: SeedTicket[] = [
    {
      email: "casey.demo@example.com",
      productSlug: "northwind-erp-core",
      subject: "وارد کردن سند در ردیف‌هایی که کاما دارند با خطا متوقف می‌شود",
      category: "Technical",
      priority: "High",
      status: "InProgress",
      env: "ویندوز ۱۱ · هسته ERP 2025.2.1 · SQL Server 2022",
      messages: [
        { body: "وقتی فایل CSV پیوست را وارد می‌کنم، عملیات در ردیف ۱۱۸ با پیام «مرجع ناقص» متوقف می‌شود. ردیف‌های قبل درست وارد می‌شوند. سه بار روی پایگاه داده تمیز بازتولید کردم.", staff: false, days: 4 },
        { body: "کیسی، از جزئیات ممنونم. این خطا را اینجا هم بازتولید کردم — تجزیه‌گر روی کامای داخل ستون مرجع شکست می‌خورد وقتی فایل از جداکننده نقطه‌ویرگول استفاده می‌کند. راه‌حل امروز: ستون مرجع را در گیومه بگذارید. رفع دائمی در نسخه ۲۰۲۵٫۲٫۲ هفته آینده منتشر می‌شود.", staff: true, days: 3 },
        { body: "گذاشتن در گیومه جواب داد، ممنون. تیکت را باز نگه می‌دارم تا وصله منتشر شود و تأیید کنم.", staff: false, days: 3 },
      ],
    },
    {
      email: "priya.demo@example.com",
      productSlug: "northwind-inventory-control",
      subject: "ایمیل تأیید مغایرت شمارش دوره‌ای خالی است",
      category: "Technical",
      priority: "Normal",
      status: "WaitingCustomer",
      env: "ویندوز سرور ۲۰۲۲ · کنترل موجودی 2025.1.3",
      messages: [
        { body: "اعلان تأیید با متن خالی می‌رسد. موضوع ایمیل درست است. برای هر سه مدیر انبار ما اتفاق می‌افتد.", staff: false, days: 9 },
        { body: "یک رگرسیون قالب در نسخه ۲۰۲۵٫۱٫۳ پیدا کردیم که وقتی زبان اعلان English (UK) است رخ می‌دهد. می‌توانید بگویید از کدام بسته زبانی استفاده می‌کنید؟", staff: true, days: 8 },
      ],
    },
    {
      email: "marcus.demo@example.com",
      productSlug: "northwind-point-of-sale",
      subject: "افزودن کشو پول دوم به صندوق شماره ۳",
      category: "Licensing",
      priority: "Low",
      status: "Open",
      env: "ویندوز ۱۱ · صندوق فروشگاهی 2025.2.1",
      messages: [
        { body: "می‌خواهیم برای کیوسک سلف‌سرویس یک کشو پول دوم اضافه کنیم. آیا به لایسنس صندوق جدید نیاز داریم یا یک پروفایل سخت‌افزاری کافی است؟", staff: false, days: 2 },
      ],
    },
    {
      email: "hana.demo@example.com",
      productSlug: "northwind-hr-payroll",
      subject: "قالب قانونی فصل اول ژاپن موجود نیست",
      category: "Technical",
      priority: "Critical",
      status: "Resolved",
      env: "ویندوز سرور ۲۰۱۹ · منابع انسانی و حقوق 2025.1.3",
      messages: [
        { body: "قالب قانونی فصل اول ۲۰۲۵ ژاپن در فهرست به‌روزرسانی نیست و نمی‌توانیم فصل را ببندیم. این موضوع حقوق ۲۴۰ کارمند ما را متوقف کرده است.", staff: false, days: 26 },
        { body: "متوجه شدیم — برای ما هم مسئله‌ساز است. قالب ژاپن فصل اول ۲۰۲۵ به همین تیکت پیوست شده و از نسخه ۲۰۲۵٫۲٫۱ در کانال عمومی به‌روزرسانی قرار می‌گیرد.", staff: true, days: 25 },
        { body: "قالب اعمال شد و فصل بسته شد. از پاسخ سریع ممنونم.", staff: false, days: 22 },
      ],
    },
    {
      email: "casey.demo@example.com",
      productSlug: "northwind-bi-connector",
      subject: "درخواست: افزودن شاخص‌های زنجیره تأمین به مدل معنایی",
      category: "Feature Request",
      priority: "Normal",
      status: "Closed",
      env: "Docker · کانکتور هوش تجاری 2025.1.3",
      messages: [
        { body: "دوست داریم شاخص‌های تحویل به‌موقع تأمین‌کننده و نرخ سفارش تأمین‌نشده هم اضافه شود. در حال حاضر این اتصال را بیرون از مدل می‌زنیم.", staff: false, days: 60 },
        { body: "هر دو شاخص در نقشه راه نسخه ۲۰۲۵٫۳ هستند. این تیکت را به قابلیت مربوطه وصل می‌کنم تا هنگام انتشار مطلع شوید.", staff: true, days: 58 },
      ],
    },
  ];

  for (let i = 0; i < TICKETS.length; i += 1) {
    const t = TICKETS[i];
    const user = userByEmail.get(t.email)!;
    const [ticket] = await db
      .insert(tickets)
      .values({
        reference: `TKT-${(1024 + i * 37).toString(16).toUpperCase()}`,
        userId: user.id,
        productId: productIds[t.productSlug],
        subject: t.subject,
        category: t.category,
        priority: t.priority,
        status: t.status,
        environment: t.env,
        createdAt: daysAgo(t.messages[0].days),
        updatedAt: daysAgo(t.messages[t.messages.length - 1].days),
      })
      .returning();
    for (const m of t.messages) {
      await db.insert(ticketMessages).values({
        ticketId: ticket.id,
        authorId: m.staff ? insertedUsers[0].id : user.id,
        authorName: m.staff ? "الکساندرا ریز (پشتیبانی)" : "شما",
        isStaff: m.staff,
        body: m.body,
        createdAt: daysAgo(m.days),
      });
    }
  }

  await db.insert(testimonials).values(TESTIMONIALS);
  await db.insert(faqs).values(FAQS);
  await db
    .insert(siteSettings)
    .values({
      id: 1,
      siteName: "نورث‌ویند",
      supportEmail: "support@northwindsoft.example",
      salesEmail: "sales@northwindsoft.example",
      supportPhone: "+1 (888) 555-0142",
      heroHeadline: "نرم‌افزار کسب‌وکاری که واقعاً منتشر می‌شود، مقیاس می‌یابد و می‌ماند",
      heroSubheading:
        "ده ماژول یکپارچه ERP، برنامه دسکتاپ و افزونه — با لایسنس دلخواه شما، روی زیرساخت خودتان، با پشتیبانی مهندسانی که پاسخ می‌دهند.",
      taxRateBps: 800,
      trialDays: 30,
      maintenanceMode: false,
      announcement:
        "نسخه ۲۰۲۵٫۲ نورث‌ویند منتشر شد — موتور قواعد مغایرت‌گیری، API نسخه ۲ و سازنده داشبورد بازطراحی‌شده.",
    })
    .onConflictDoNothing();

  return { seeded: true };
}

export async function resetAndSeed(): Promise<void> {
  await db.delete(ticketMessages);
  await db.delete(tickets);
  await db.delete(licenseActivations);
  await db.delete(licenses);
  await db.delete(downloads);
  await db.delete(payments);
  await db.delete(invoices);
  await db.delete(orderItems);
  await db.delete(orders);
  await db.delete(reviews);
  await db.delete(productVersions);
  await db.delete(productPlans);
  await db.delete(products);
  await db.delete(categories);
  await db.delete(discountCodes);
  await db.delete(testimonials);
  await db.delete(faqs);
  await db.delete(siteSettings);
  const [admin] = await db.select().from(users).where(eq(users.email, CUSTOMERS[0].email)).limit(1);
  await db.delete(users);
  if (admin) await db.insert(users).values({ ...admin, id: admin.id }).onConflictDoNothing();
  await seedDatabase();
}
