import {
  boolean,
  index,
  integer,
  jsonb,
  pgEnum,
  pgTable,
  text,
  timestamp,
  uniqueIndex,
  uuid,
} from "drizzle-orm/pg-core";

/* ------------------------------------------------------------------ */
/* Enums (Domain)                                                      */
/* ------------------------------------------------------------------ */

export const userRoleEnum = pgEnum("user_role", ["Admin", "Customer"]);
export const productTypeEnum = pgEnum("product_type", ["Module", "DesktopApp", "AddOn"]);
export const planTierEnum = pgEnum("plan_tier", ["SingleUser", "MultiUser", "Enterprise"]);
export const billingTypeEnum = pgEnum("billing_type", ["OneTime", "Annual"]);
export const orderStatusEnum = pgEnum("order_status", [
  "Pending",
  "Paid",
  "Processing",
  "Completed",
  "Refunded",
  "Cancelled",
]);
export const paymentStatusEnum = pgEnum("payment_status", ["Pending", "Succeeded", "Failed", "Refunded"]);
export const licenseStatusEnum = pgEnum("license_status", ["Active", "Expired", "Revoked"]);
export const ticketStatusEnum = pgEnum("ticket_status", [
  "Open",
  "InProgress",
  "WaitingCustomer",
  "Resolved",
  "Closed",
]);
export const ticketPriorityEnum = pgEnum("ticket_priority", ["Low", "Normal", "High", "Critical"]);
export const reviewStatusEnum = pgEnum("review_status", ["Pending", "Approved", "Rejected"]);
export const invoiceStatusEnum = pgEnum("invoice_status", ["Draft", "Issued", "Paid", "Void"]);

/* ------------------------------------------------------------------ */
/* Identity                                                            */
/* ------------------------------------------------------------------ */

export const users = pgTable(
  "users",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    email: text("email").notNull(),
    fullName: text("full_name").notNull(),
    company: text("company"),
    phone: text("phone"),
    passwordHash: text("password_hash").notNull(),
    role: userRoleEnum("role").notNull().default("Customer"),
    country: text("country"),
    isLocked: boolean("is_locked").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    lastLoginAt: timestamp("last_login_at", { withTimezone: true }),
  },
  (t) => [uniqueIndex("users_email_uq").on(t.email)],
);

export const refreshTokens = pgTable(
  "refresh_tokens",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    tokenHash: text("token_hash").notNull(),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    revokedAt: timestamp("revoked_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    uniqueIndex("refresh_tokens_hash_uq").on(t.tokenHash),
    index("refresh_tokens_user_idx").on(t.userId),
  ],
);

/* ------------------------------------------------------------------ */
/* Catalog                                                             */
/* ------------------------------------------------------------------ */

export const categories = pgTable(
  "categories",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    name: text("name").notNull(),
    slug: text("slug").notNull(),
    description: text("description"),
    icon: text("icon").notNull().default("package"),
    sortOrder: integer("sort_order").notNull().default(0),
    isActive: boolean("is_active").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("categories_slug_uq").on(t.slug)],
);

export const products = pgTable(
  "products",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    slug: text("slug").notNull(),
    name: text("name").notNull(),
    tagline: text("tagline").notNull(),
    description: text("description").notNull(),
    categoryId: uuid("category_id")
      .notNull()
      .references(() => categories.id, { onDelete: "restrict" }),
    type: productTypeEnum("type").notNull().default("Module"),
    platform: text("platform").notNull().default("Windows"),
    version: text("version").notNull().default("1.0.0"),
    basePriceCents: integer("base_price_cents").notNull().default(0),
    ratingAvg: integer("rating_avg").notNull().default(0), // rating * 10
    ratingCount: integer("rating_count").notNull().default(0),
    popularity: integer("popularity").notNull().default(0),
    heroImage: text("hero_image"),
    accentColor: text("accent_color").notNull().default("#4f46e5"),
    gallery: jsonb("gallery").$type<string[]>(),
    features: jsonb("features").$type<string[]>(),
    systemRequirements: jsonb("system_requirements").$type<string[]>(),
    demoVideoUrl: text("demo_video_url"),
    trialDays: integer("trial_days").notNull().default(30),
    isFeatured: boolean("is_featured").notNull().default(false),
    isActive: boolean("is_active").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    uniqueIndex("products_slug_uq").on(t.slug),
    index("products_category_idx").on(t.categoryId),
    index("products_popularity_idx").on(t.popularity),
  ],
);

export const productPlans = pgTable(
  "product_plans",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    productId: uuid("product_id")
      .notNull()
      .references(() => products.id, { onDelete: "cascade" }),
    name: text("name").notNull(),
    tier: planTierEnum("tier").notNull().default("SingleUser"),
    billingType: billingTypeEnum("billing_type").notNull().default("OneTime"),
    priceCents: integer("price_cents").notNull(),
    seats: integer("seats").notNull().default(1),
    description: text("description"),
    isPopular: boolean("is_popular").notNull().default(false),
    sortOrder: integer("sort_order").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("product_plans_product_idx").on(t.productId)],
);

export const productVersions = pgTable(
  "product_versions",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    productId: uuid("product_id")
      .notNull()
      .references(() => products.id, { onDelete: "cascade" }),
    version: text("version").notNull(),
    releasedAt: timestamp("released_at", { withTimezone: true }).notNull().defaultNow(),
    notes: text("notes").notNull(),
    installerUrl: text("installer_url"),
    sizeMb: integer("size_mb").notNull().default(0),
    platform: text("platform").notNull().default("Windows"),
  },
  (t) => [index("product_versions_product_idx").on(t.productId)],
);

export const reviews = pgTable(
  "reviews",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    productId: uuid("product_id")
      .notNull()
      .references(() => products.id, { onDelete: "cascade" }),
    userId: uuid("user_id").references(() => users.id, { onDelete: "set null" }),
    authorName: text("author_name").notNull(),
    authorCompany: text("author_company"),
    rating: integer("rating").notNull(),
    title: text("title").notNull(),
    body: text("body").notNull(),
    status: reviewStatusEnum("status").notNull().default("Pending"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("reviews_product_idx").on(t.productId), index("reviews_status_idx").on(t.status)],
);

/* ------------------------------------------------------------------ */
/* Commerce                                                            */
/* ------------------------------------------------------------------ */

export const carts = pgTable(
  "carts",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    sessionKey: text("session_key").notNull(),
    userId: uuid("user_id").references(() => users.id, { onDelete: "set null" }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("carts_session_uq").on(t.sessionKey)],
);

export const cartItems = pgTable(
  "cart_items",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    cartId: uuid("cart_id")
      .notNull()
      .references(() => carts.id, { onDelete: "cascade" }),
    planId: uuid("plan_id")
      .notNull()
      .references(() => productPlans.id, { onDelete: "cascade" }),
    quantity: integer("quantity").notNull().default(1),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("cart_items_cart_idx").on(t.cartId)],
);

export const discountCodes = pgTable(
  "discount_codes",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    code: text("code").notNull(),
    description: text("description"),
    percentOff: integer("percent_off").notNull().default(0),
    maxRedemptions: integer("max_redemptions").notNull().default(0),
    timesRedeemed: integer("times_redeemed").notNull().default(0),
    expiresAt: timestamp("expires_at", { withTimezone: true }),
    isActive: boolean("is_active").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("discount_codes_code_uq").on(t.code)],
);

export const orders = pgTable(
  "orders",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    orderNumber: text("order_number").notNull(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "restrict" }),
    status: orderStatusEnum("status").notNull().default("Pending"),
    subtotalCents: integer("subtotal_cents").notNull().default(0),
    discountCents: integer("discount_cents").notNull().default(0),
    taxCents: integer("tax_cents").notNull().default(0),
    totalCents: integer("total_cents").notNull().default(0),
    currency: text("currency").notNull().default("USD"),
    discountCode: text("discount_code"),
    billingName: text("billing_name"),
    billingCompany: text("billing_company"),
    billingEmail: text("billing_email"),
    billingCountry: text("billing_country"),
    notes: text("notes"),
    placedAt: timestamp("placed_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    uniqueIndex("orders_number_uq").on(t.orderNumber),
    index("orders_user_idx").on(t.userId),
    index("orders_placed_idx").on(t.placedAt),
  ],
);

export const orderItems = pgTable(
  "order_items",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    orderId: uuid("order_id")
      .notNull()
      .references(() => orders.id, { onDelete: "cascade" }),
    productId: uuid("product_id").references(() => products.id, { onDelete: "set null" }),
    planId: uuid("plan_id").references(() => productPlans.id, { onDelete: "set null" }),
    productName: text("product_name").notNull(),
    planName: text("plan_name").notNull(),
    billingType: billingTypeEnum("billing_type").notNull().default("OneTime"),
    unitPriceCents: integer("unit_price_cents").notNull(),
    quantity: integer("quantity").notNull().default(1),
    lineTotalCents: integer("line_total_cents").notNull(),
  },
  (t) => [index("order_items_order_idx").on(t.orderId)],
);

export const payments = pgTable(
  "payments",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    orderId: uuid("order_id")
      .notNull()
      .references(() => orders.id, { onDelete: "cascade" }),
    provider: text("provider").notNull().default("MockGateway"),
    method: text("method").notNull().default("card"),
    amountCents: integer("amount_cents").notNull(),
    status: paymentStatusEnum("status").notNull().default("Pending"),
    transactionRef: text("transaction_ref"),
    paidAt: timestamp("paid_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("payments_order_idx").on(t.orderId)],
);

export const invoices = pgTable(
  "invoices",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    invoiceNumber: text("invoice_number").notNull(),
    orderId: uuid("order_id")
      .notNull()
      .references(() => orders.id, { onDelete: "cascade" }),
    status: invoiceStatusEnum("status").notNull().default("Issued"),
    issuedAt: timestamp("issued_at", { withTimezone: true }).notNull().defaultNow(),
    dueAt: timestamp("due_at", { withTimezone: true }),
    totalCents: integer("total_cents").notNull(),
    taxCents: integer("tax_cents").notNull().default(0),
  },
  (t) => [uniqueIndex("invoices_number_uq").on(t.invoiceNumber)],
);

export const licenses = pgTable(
  "licenses",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    licenseKey: text("license_key").notNull(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    productId: uuid("product_id")
      .notNull()
      .references(() => products.id, { onDelete: "cascade" }),
    planId: uuid("plan_id").references(() => productPlans.id, { onDelete: "set null" }),
    orderId: uuid("order_id").references(() => orders.id, { onDelete: "set null" }),
    seats: integer("seats").notNull().default(1),
    activationsUsed: integer("activations_used").notNull().default(0),
    status: licenseStatusEnum("status").notNull().default("Active"),
    issuedAt: timestamp("issued_at", { withTimezone: true }).notNull().defaultNow(),
    expiresAt: timestamp("expires_at", { withTimezone: true }),
  },
  (t) => [
    uniqueIndex("licenses_key_uq").on(t.licenseKey),
    index("licenses_user_idx").on(t.userId),
    index("licenses_expiry_idx").on(t.expiresAt),
  ],
);

export const licenseActivations = pgTable(
  "license_activations",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    licenseId: uuid("license_id")
      .notNull()
      .references(() => licenses.id, { onDelete: "cascade" }),
    machineName: text("machine_name").notNull(),
    machineHash: text("machine_hash"),
    activatedAt: timestamp("activated_at", { withTimezone: true }).notNull().defaultNow(),
    lastSeenAt: timestamp("last_seen_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("license_activations_license_idx").on(t.licenseId)],
);

export const downloads = pgTable(
  "downloads",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id").references(() => users.id, { onDelete: "cascade" }),
    productId: uuid("product_id")
      .notNull()
      .references(() => products.id, { onDelete: "cascade" }),
    versionId: uuid("version_id").references(() => productVersions.id, { onDelete: "set null" }),
    kind: text("kind").notNull().default("installer"),
    fileName: text("file_name").notNull(),
    sizeMb: integer("size_mb").notNull().default(0),
    downloadedAt: timestamp("downloaded_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("downloads_user_idx").on(t.userId), index("downloads_product_idx").on(t.productId)],
);

/* ------------------------------------------------------------------ */
/* Support & content                                                   */
/* ------------------------------------------------------------------ */

export const tickets = pgTable(
  "tickets",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    reference: text("reference").notNull(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    productId: uuid("product_id").references(() => products.id, { onDelete: "set null" }),
    subject: text("subject").notNull(),
    category: text("category").notNull().default("Technical"),
    priority: ticketPriorityEnum("priority").notNull().default("Normal"),
    status: ticketStatusEnum("status").notNull().default("Open"),
    environment: text("environment"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    uniqueIndex("tickets_reference_uq").on(t.reference),
    index("tickets_user_idx").on(t.userId),
    index("tickets_status_idx").on(t.status),
  ],
);

export const ticketMessages = pgTable(
  "ticket_messages",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    ticketId: uuid("ticket_id")
      .notNull()
      .references(() => tickets.id, { onDelete: "cascade" }),
    authorId: uuid("author_id").references(() => users.id, { onDelete: "set null" }),
    authorName: text("author_name").notNull(),
    isStaff: boolean("is_staff").notNull().default(false),
    body: text("body").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("ticket_messages_ticket_idx").on(t.ticketId)],
);

export const testimonials = pgTable("testimonials", {
  id: uuid("id").primaryKey().defaultRandom(),
  authorName: text("author_name").notNull(),
  authorRole: text("author_role").notNull(),
  company: text("company").notNull(),
  quote: text("quote").notNull(),
  rating: integer("rating").notNull().default(5),
  sortOrder: integer("sort_order").notNull().default(0),
});

export const faqs = pgTable("faqs", {
  id: uuid("id").primaryKey().defaultRandom(),
  question: text("question").notNull(),
  answer: text("answer").notNull(),
  sortOrder: integer("sort_order").notNull().default(0),
});

export const contactMessages = pgTable("contact_messages", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  company: text("company"),
  topic: text("topic").notNull().default("General"),
  message: text("message").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const demoRequests = pgTable("demo_requests", {
  id: uuid("id").primaryKey().defaultRandom(),
  productId: uuid("product_id").references(() => products.id, { onDelete: "set null" }),
  name: text("name").notNull(),
  email: text("email").notNull(),
  company: text("company"),
  companySize: text("company_size"),
  message: text("message"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const siteSettings = pgTable("site_settings", {
  id: integer("id").primaryKey().default(1),
  siteName: text("site_name").notNull().default("Northwind Software"),
  supportEmail: text("support_email").notNull().default("support@northwindsoft.example"),
  salesEmail: text("sales_email").notNull().default("sales@northwindsoft.example"),
  supportPhone: text("support_phone").notNull().default("+1 (888) 555-0142"),
  heroHeadline: text("hero_headline").notNull().default("Software that runs the whole business"),
  heroSubheading: text("hero_subheading").notNull().default(""),
  taxRateBps: integer("tax_rate_bps").notNull().default(800),
  trialDays: integer("trial_days").notNull().default(30),
  maintenanceMode: boolean("maintenance_mode").notNull().default(false),
  announcement: text("announcement").notNull().default(""),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});
