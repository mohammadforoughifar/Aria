"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import { useAuth, useCart } from "@/lib/client/api";
import { Button, cn } from "@/components/ui";
import { initials, faNum } from "@/lib/format";

const NAV = [
  { href: "/catalog", label: "محصولات" },
  { href: "/compare", label: "مقایسه" },
  { href: "/support", label: "پشتیبانی" },
  { href: "/about", label: "درباره ما" },
  { href: "/contact", label: "تماس" },
];

export function SiteHeader({ siteName }: { siteName?: string }) {
  const pathname = usePathname();
  const { user, status, logout } = useAuth();
  const { cart } = useCart();
  const [open, setOpen] = useState(false);
  const itemCount = cart?.itemCount ?? 0;

  return (
    <header className="sticky top-0 z-40 border-b border-slate-200/80 bg-white/85 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center gap-4 px-4 sm:px-6 lg:px-8">
        <Link href="/" className="flex items-center gap-2.5">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-600 to-violet-500 text-sm font-black text-white shadow-md shadow-indigo-600/30">
            NW
          </span>
          <span className="hidden text-base font-bold tracking-tight text-slate-900 sm:block">
            {siteName ?? "نورث‌ویند"}
          </span>
        </Link>

        <nav className="hidden items-center gap-1 lg:flex">
          {NAV.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "rounded-lg px-3 py-2 text-sm font-medium transition",
                pathname === item.href
                  ? "bg-indigo-50 text-indigo-700"
                  : "text-slate-600 hover:bg-slate-100 hover:text-slate-900",
              )}
            >
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="ms-auto flex items-center gap-2">
          <Link
            href="/cart"
            className="relative flex h-10 items-center gap-2 rounded-lg px-3 text-sm font-medium text-slate-600 transition hover:bg-slate-100 hover:text-slate-900"
          >
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className="h-5 w-5">
              <path d="M2.25 3h1.5l1.7 10.2a2.25 2.25 0 002.22 1.88h8.6a2.25 2.25 0 002.2-1.78l1.28-6.05H5.2" />
              <circle cx="9" cy="19.5" r="1.4" />
              <circle cx="17" cy="19.5" r="1.4" />
            </svg>
            <span className="hidden sm:inline">سبد خرید</span>
            {itemCount > 0 && (
              <span className="absolute -end-0.5 -top-0.5 flex h-5 min-w-5 items-center justify-center rounded-full bg-indigo-600 px-1 text-[11px] font-bold text-white">
                {itemCount}
              </span>
            )}
          </Link>

          {status === "loading" ? (
            <div className="h-10 w-24 animate-pulse rounded-lg bg-slate-100" />
          ) : user ? (
            <div className="flex items-center gap-2">
              <Link
                href="/dashboard"
                className="flex h-10 items-center gap-2 rounded-lg border border-slate-200 px-2.5 text-sm font-semibold text-slate-700 transition hover:border-slate-300 hover:bg-slate-50"
              >
                <span className="flex h-6 w-6 items-center justify-center rounded-full bg-gradient-to-br from-indigo-500 to-violet-500 text-[10px] font-bold text-white">
                  {initials(user.fullName)}
                </span>
                <span className="hidden sm:inline">داشبورد</span>
              </Link>
              <Button variant="ghost" size="sm" onClick={() => void logout()} className="hidden sm:inline-flex">
                خروج
              </Button>
            </div>
          ) : (
            <>
              <Link href="/login" className="hidden sm:block">
                <Button variant="outline" size="sm">
                  ورود
                </Button>
              </Link>
              <Link href="/register">
                <Button size="sm">شروع کنید</Button>
              </Link>
            </>
          )}

          <button
            onClick={() => setOpen((v) => !v)}
            aria-label="باز و بسته کردن منو"
            className="flex h-10 w-10 items-center justify-center rounded-lg text-slate-600 transition hover:bg-slate-100 lg:hidden"
          >
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className="h-5 w-5">
              {open ? <path d="M6 6l12 12M18 6L6 18" /> : <path d="M4 7h16M4 12h16M4 17h16" />}
            </svg>
          </button>
        </div>
      </div>

      {open && (
        <nav className="border-t border-slate-200 bg-white px-4 py-3 lg:hidden">
          <div className="grid gap-1">
            {NAV.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                onClick={() => setOpen(false)}
                className="rounded-lg px-3 py-2 text-sm font-medium text-slate-700 transition hover:bg-slate-100"
              >
                {item.label}
              </Link>
            ))}
            {!user && (
              <Link
                href="/login"
                onClick={() => setOpen(false)}
                className="rounded-lg px-3 py-2 text-sm font-medium text-indigo-700 transition hover:bg-indigo-50"
              >
                ورود
              </Link>
            )}
          </div>
        </nav>
      )}
    </header>
  );
}

export function SiteFooter({ settings }: { settings?: { supportEmail: string; supportPhone: string } }) {
  return (
    <footer className="border-t border-slate-200 bg-slate-900 text-slate-300">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-14 sm:px-6 lg:grid-cols-4 lg:px-8">
        <div>
          <div className="flex items-center gap-2.5">
            <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-500 to-violet-500 text-sm font-black text-white">
              NW
            </span>
            <span className="text-base font-bold text-white">نورث‌ویند</span>
          </div>
          <p className="mt-4 max-w-xs text-sm leading-relaxed text-slate-400">
            ماژول‌های یکپارچه ERP، برنامه‌های دسکتاپ و افزونه‌ها برای شرکت‌های متوسط تولیدی، پخش و خرده‌فروشی. فعال از سال ۲۰۰۴.
          </p>
          <p className="mt-4 text-sm text-slate-400">
            {settings?.supportEmail ?? "support@northwindsoft.example"}
            <br />
            {settings?.supportPhone ?? "+1 (888) 555-0142"}
          </p>
        </div>

        <FooterColumn
          title="محصولات"
          links={[
            { href: "/catalog", label: "همه محصولات" },
            { href: "/catalog?category=erp-suite", label: "مجموعه ERP" },
            { href: "/catalog?category=desktop-productivity", label: "برنامه‌های دسکتاپ" },
            { href: "/catalog?category=addons-integrations", label: "افزونه‌ها" },
            { href: "/compare", label: "مقایسه محصولات" },
          ]}
        />
        <FooterColumn
          title="شرکت"
          links={[
            { href: "/about", label: "درباره ما" },
            { href: "/contact", label: "تماس" },
            { href: "/support", label: "مرکز پشتیبانی" },
            { href: "/dashboard", label: "پورتال مشتریان" },
          ]}
        />
        <FooterColumn
          title="حقوقی"
          links={[
            { href: "/legal/شرایط استفاده", label: "شرایط استفاده" },
            { href: "/legal/privacy", label: "سیاست حریم خصوصی" },
            { href: "/legal/eula", label: "قرارداد کاربر نهایی" },
            { href: "/api-docs", label: "مستندات API" },
          ]}
        />
      </div>
      <div className="border-t border-slate-800">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-3 px-4 py-5 text-xs text-slate-500 sm:px-6 lg:px-8">
          <p>© {faNum(new Date().getFullYear())} نورث‌ویند؛ همه حقوق محفوظ است.</p>
          <p className="flex items-center gap-4">
            <span>SOC 2 Type II</span>
            <span>ISO 27001</span>
            <span>GDPR ready</span>
          </p>
        </div>
      </div>
    </footer>
  );
}

function FooterColumn({ title, links }: { title: string; links: { href: string; label: string }[] }) {
  return (
    <div>
      <h3 className="text-xs font-semibold uppercase tracking-wider text-white">{title}</h3>
      <ul className="mt-4 space-y-2.5">
        {links.map((link) => (
          <li key={link.href + link.label}>
            <Link href={link.href} className="text-sm text-slate-400 transition hover:text-white">
              {link.label}
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
