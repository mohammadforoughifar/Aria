"use client";

import Link from "next/link";
import { Badge, RatingStars, cn } from "@/components/ui";
import { formatMoney, faNum, toFa } from "@/lib/format";
import type { ProductListItemDto } from "@/shared/contracts";

export function MockScreenshot({
  label,
  accent,
  className,
  compact = false,
}: {
  label: string;
  accent: string;
  className?: string;
  compact?: boolean;
}) {
  return (
    <div
      className={cn("relative overflow-hidden rounded-xl ring-1 ring-slate-900/10", className)}
      style={{ background: `linear-gradient(135deg, ${accent}18, ${accent}05)` }}
    >
      <div className="flex items-center gap-1.5 border-b border-slate-900/10 bg-white/70 px-3 py-2">
        <span className="h-2.5 w-2.5 rounded-full bg-rose-400" />
        <span className="h-2.5 w-2.5 rounded-full bg-amber-400" />
        <span className="h-2.5 w-2.5 rounded-full bg-emerald-400" />
        <span className="ms-2 truncate text-[10px] font-semibold text-slate-500">{label}</span>
      </div>
      <div className={cn("grid gap-3 p-3", compact ? "grid-cols-3" : "grid-cols-4")}>
        <div className="col-span-1 space-y-2">
          {Array.from({ length: compact ? 4 : 6 }).map((_, i) => (
            <div key={i} className="h-2 rounded-full bg-slate-900/10" style={{ width: `${60 + ((i * 17) % 40)}%` }} />
          ))}
        </div>
        <div className={cn("space-y-3", compact ? "col-span-2" : "col-span-3")}>
          <div className="grid grid-cols-3 gap-2">
            {[0, 1, 2].map((i) => (
              <div key={i} className="rounded-lg bg-white/80 p-2 shadow-sm">
                <div className="h-1.5 w-8 rounded-full bg-slate-300" />
                <div className="mt-1.5 h-3 w-12 rounded bg-slate-800/70" />
              </div>
            ))}
          </div>
          <div className="rounded-lg bg-white/80 p-2 shadow-sm">
            <div className="flex h-16 items-end gap-1.5 px-1">
              {[35, 55, 42, 70, 58, 82, 64, 91, 48, 76, 61, 88].map((h, i) => (
                <div
                  key={i}
                  className="flex-1 rounded-sm"
                  style={{ height: `${h}%`, background: i % 3 === 0 ? accent : `${accent}88` }}
                />
              ))}
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2">
            {[0, 1].map((i) => (
              <div key={i} className="space-y-1.5 rounded-lg bg-white/80 p-2 shadow-sm">
                <div className="h-1.5 w-2/3 rounded-full bg-slate-300" />
                <div className="h-1.5 w-1/2 rounded-full bg-slate-200" />
                <div className="h-1.5 w-3/4 rounded-full bg-slate-200" />
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

export function ProductCard({
  product,
  onCompare,
  compared,
}: {
  product: ProductListItemDto;
  onCompare?: (id: string) => void;
  compared?: boolean;
}) {
  return (
    <div className="group flex flex-col overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm transition hover:-translate-y-0.5 hover:border-indigo-200 hover:shadow-lg hover:shadow-indigo-100/60">
      <Link href={`/products/${product.slug}`} className="block p-4">
        <div className="flex items-start justify-between gap-3">
          <div
            className="flex h-10 w-10 items-center justify-center rounded-xl text-base shadow-sm ring-1 ring-inset"
            style={{ background: `${product.accentColor}18`, color: product.accentColor }}
          >
            {product.type === "Module" ? "🧩" : product.type === "DesktopApp" ? "🖥️" : "🔌"}
          </div>
          <Badge tone="slate">{product.categoryName}</Badge>
        </div>
        <h3 className="mt-3 text-base font-semibold tracking-tight text-slate-900 group-hover:text-indigo-700">
          {product.name}
        </h3>
        <p className="mt-1 line-clamp-2 text-sm text-slate-500">{product.tagline}</p>
        <div className="mt-3 flex items-center gap-2 text-xs text-slate-500">
          <RatingStars value={product.ratingAvg} />
          <span className="font-medium text-slate-600">{toFa(product.ratingAvg.toFixed(1))}</span>
          <span>({faNum(product.ratingCount)})</span>
        </div>
      </Link>
      <div className="mt-auto flex items-center justify-between gap-2 border-t border-slate-100 px-4 py-3">
        <div>
          <p className="text-[11px] font-semibold uppercase tracking-wide text-slate-400">از</p>
          <p className="text-sm font-bold text-slate-900">{formatMoney(product.basePriceCents)}</p>
        </div>
        <div className="flex items-center gap-1.5">
          {onCompare && (
            <button
              onClick={() => onCompare(product.id)}
              className={cn(
                "rounded-lg border px-2.5 py-1.5 text-xs font-semibold transition",
                compared
                  ? "border-indigo-300 bg-indigo-50 text-indigo-700"
                  : "border-slate-200 text-slate-600 hover:border-slate-300 hover:bg-slate-50",
              )}
            >
              {compared ? "در مقایسه" : "مقایسه"}
            </button>
          )}
          <Link
            href={`/products/${product.slug}`}
            className="rounded-lg bg-slate-900 px-2.5 py-1.5 text-xs font-semibold text-white transition hover:bg-slate-800"
          >مشاهده</Link>
        </div>
      </div>
    </div>
  );
}
