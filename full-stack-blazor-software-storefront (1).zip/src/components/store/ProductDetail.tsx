"use client";

import Link from "next/link";
import { useState } from "react";
import { MockScreenshot } from "@/components/store/ProductCard";
import {
  Badge,
  Button,
  Card,
  Field,
  Input,
  Modal,
  RatingStars,
  Select,
  Tabs,
  Textarea,
  cn,
  useToast,
} from "@/components/ui";
import { formatDate, formatMoney, formatSize, faNum, toFa } from "@/lib/format";
import { api, useAuth, useCart } from "@/lib/client/api";
import type { ProductDetailDto, ReviewDto } from "@/shared/contracts";

export function ProductDetail({
  product,
  initialReviews,
}: {
  product: ProductDetailDto;
  initialReviews: ReviewDto[];
}) {
  const { addItem } = useCart();
  const { user } = useAuth();
  const { push } = useToast();
  const [tab, setTab] = useState("overview");
  const [selectedPlan, setSelectedPlan] = useState(
    product.plans.find((p) => p.isPopular)?.id ?? product.plans[0]?.id ?? "",
  );
  const [quantity, setQuantity] = useState(1);
  const [shot, setShot] = useState(0);
  const [reviews, setReviews] = useState(initialReviews);
  const [reviewOpen, setReviewOpen] = useState(false);
  const [demoOpen, setDemoOpen] = useState(false);
  const [adding, setAdding] = useState(false);

  const plan = product.plans.find((p) => p.id === selectedPlan) ?? product.plans[0];

  async function handleAddToCart() {
    if (!plan) return;
    setAdding(true);
    try {
      await addItem(plan.id, quantity);
      push({ tone: "success", title: "به سبد اضافه شد", description: `${product.name} — ${plan.name}` });
    } catch (error) {
      push({
        tone: "error",
        title: "افزودن به سبد ناموفق بود",
        description: error instanceof Error ? error.message : undefined,
      });
    } finally {
      setAdding(false);
    }
  }

  async function handleTrial() {
    try {
      const { data } = await api.post<{ manifest: { چک‌سام: string } }>("/api/downloads", {
        productId: product.id,
        kind: "trial",
        fileName: `${product.slug}-${product.versions[0]?.version ?? "latest"}-trial.exe`,
      });
      push({
        tone: "success",
        title: "دانلود نسخه آزمایشی آغاز شد",
        description: `${product.trialDays}-day trial · چک‌سام ${data.manifest.چک‌سام}`,
      });
    } catch (error) {
      push({
        tone: "error",
        title: "دانلود ناموفق بود",
        description: error instanceof Error ? error.message : undefined,
      });
    }
  }

  const galleryLabels = product.gallery.length ? product.gallery : ["Product overview"];

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
      <nav className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
        <Link href="/" className="hover:text-slate-800">خانه</Link>
        <span>/</span>
        <Link href="/catalog" className="hover:text-slate-800">محصولات</Link>
        <span>/</span>
        <Link href={`/catalog?category=${product.categorySlug}`} className="hover:text-slate-800">
          {product.categoryName}
        </Link>
        <span>/</span>
        <span className="font-medium text-slate-700">{product.name}</span>
      </nav>

      <div className="mt-6 grid gap-8 lg:grid-cols-[1fr_380px]">
        <div>
          <div className="flex flex-wrap items-center gap-2">
            <Badge tone="indigo">{product.categoryName}</Badge>
            <Badge tone="slate">
              {product.type === "Module" ? "ماژول ERP" : product.type === "DesktopApp" ? "برنامه دسکتاپ" : "افزونه"}
            </Badge>
            {product.isFeatured && <Badge tone="amber">⭐ پرفروش</Badge>}
            <Badge tone="green">v{product.version}</Badge>
          </div>
          <h1 className="mt-3 text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl">{product.name}</h1>
          <p className="mt-2 text-lg text-slate-600">{product.tagline}</p>
          <div className="mt-3 flex flex-wrap items-center gap-3 text-sm text-slate-500">
            <span className="flex items-center gap-1.5">
              <RatingStars value={product.ratingAvg} size={16} />
              <span className="font-semibold text-slate-700">{product.ratingAvg.toFixed(1)}</span>
              <span>({faNum(product.ratingCount)} نظر)</span>
            </span>
            <span>·</span>
            <span>{product.platform}</span>
          </div>

          <div className="mt-6 overflow-hidden rounded-2xl border border-slate-200 bg-white p-3 shadow-sm">
            <MockScreenshot label={`${product.name} — ${galleryLabels[shot]}`} accent={product.accentColor} className="w-full" />
            <div className="mt-3 flex flex-wrap gap-2">
              {galleryLabels.map((label, i) => (
                <button
                  key={label}
                  onClick={() => setShot(i)}
                  className={cn(
                    "rounded-lg border px-3 py-1.5 text-xs font-medium transition",
                    i === shot
                      ? "border-indigo-300 bg-indigo-50 text-indigo-700"
                      : "border-slate-200 text-slate-600 hover:bg-slate-50",
                  )}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>

          <div className="mt-8">
            <Tabs
              tabs={[
                { id: "overview", label: "معرفی" },
                { id: "requirements", label: "پیش‌نیازها" },
                { id: "changelog", label: "تاریخچه نسخه‌ها" },
                { id: "reviews", label: "نظرات", badge: reviews.length },
              ]}
              active={tab}
              onChange={setTab}
            />
          </div>

          <div className="mt-6">
            {tab === "overview" && (
              <div className="space-y-8">
                <div>
                  {product.description.split("\n\n").map((para, i) => (
                    <p key={i} className="mb-4 text-[15px] leading-7 text-slate-700">
                      {para}
                    </p>
                  ))}
                </div>
                <div>
                  <h3 className="text-base font-semibold text-slate-900">قابلیت‌های کلیدی</h3>
                  <ul className="mt-4 grid gap-3 sm:grid-cols-2">
                    {product.features.map((feature) => (
                      <li
                        key={feature}
                        className="flex items-start gap-3 rounded-lg border border-slate-200 bg-white p-3.5 text-sm text-slate-700"
                      >
                        <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-emerald-100 text-[11px] font-bold text-emerald-700">
                          ✓
                        </span>
                        {feature}
                      </li>
                    ))}
                  </ul>
                </div>
                <Card>
                  <div className="flex flex-wrap items-center justify-between gap-4">
                    <div>
                      <h3 className="text-base font-semibold text-slate-900">تماشای ویدیوی معرفی</h3>
                      <p className="mt-1 text-sm text-slate-500">
                        یک معرفی ضبط‌شده از ماژول توسط مهندسان ما.
                      </p>
                    </div>
                    <Button variant="outline" onClick={() => setDemoOpen(true)}>
                      ▶ پخش ویدیو
                    </Button>
                  </div>
                </Card>
              </div>
            )}

            {tab === "requirements" && (
              <Card>
                <h3 className="text-base font-semibold text-slate-900">پیش‌نیازهای سیستم</h3>
                <ul className="mt-4 space-y-3">
                  {product.systemRequirements.map((req) => (
                    <li key={req} className="flex items-start gap-3 text-sm text-slate-700">
                      <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-indigo-500" />
                      {req}
                    </li>
                  ))}
                </ul>
                <div className="mt-6 grid gap-3 sm:grid-cols-3">
                  {[
                    { label: "حجم نصب‌کننده", value: formatSize(product.versions[0]?.sizeMb ?? 180) },
                    { label: "مدت نسخه آزمایشی", value: `${product.trialDays} days` },
                    { label: "آخرین نسخه", value: product.versions[0]?.version ?? product.version },
                  ].map((item) => (
                    <div key={item.label} className="rounded-lg bg-slate-50 p-3">
                      <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">{item.label}</p>
                      <p className="mt-1 text-sm font-semibold text-slate-900">{item.value}</p>
                    </div>
                  ))}
                </div>
              </Card>
            )}

            {tab === "changelog" && (
              <div className="space-y-4">
                {product.versions.map((version, i) => (
                  <Card key={version.id}>
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-3">
                        <span className="rounded-lg bg-slate-900 px-2.5 py-1 text-xs font-bold text-white">
                          v{version.version}
                        </span>
                        {i === 0 && <Badge tone="green">آخرین</Badge>}
                      </div>
                      <span className="text-xs font-medium text-slate-500">
                        {formatDate(version.releasedAt)} · {version.platform}
                      </span>
                    </div>
                    <p className="mt-3 text-sm leading-relaxed text-slate-700">{version.notes}</p>
                    <div className="mt-4 flex items-center gap-3">
                      <Button variant="outline" size="sm" onClick={() => void handleTrial()}>
                        دانلود نسخه {toFa(version.version)}
                      </Button>
                      <span className="text-xs text-slate-500">{formatSize(version.sizeMb)}</span>
                    </div>
                  </Card>
                ))}
              </div>
            )}

            {tab === "reviews" && (
              <div className="space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center gap-4">
                    <div className="text-center">
                      <p className="text-3xl font-bold text-slate-900">{product.ratingAvg.toFixed(1)}</p>
                      <RatingStars value={product.ratingAvg} />
                      <p className="mt-1 text-xs text-slate-500">{faNum(product.ratingCount)} نظر</p>
                    </div>
                    <div className="space-y-1">
                      {[5, 4, 3, 2, 1].map((star) => {
                        const count = reviews.filter((r) => r.rating === star).length;
                        const pct = reviews.length ? (count / reviews.length) * 100 : 0;
                        return (
                          <div key={star} className="flex items-center gap-2 text-xs text-slate-500">
                            <span className="w-3 text-end">{star}</span>
                            <div className="h-1.5 w-32 overflow-hidden rounded-full bg-slate-200">
                              <div className="h-full rounded-full bg-amber-400" style={{ width: `${pct}%` }} />
                            </div>
                            <span>{count}</span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                  <Button variant="outline" onClick={() => setReviewOpen(true)}>
                    ثبت نظر
                  </Button>
                </div>

                {reviews.length === 0 ? (
                  <Card>
                    <p className="text-sm text-slate-500">
                      هنوز نظری منتشر نشده — اولین کسی باشید که تجربه خود را به اشتراک می‌گذارد.
                    </p>
                  </Card>
                ) : (
                  reviews.map((review) => (
                    <Card key={review.id}>
                      <div className="flex flex-wrap items-start justify-between gap-3">
                        <div>
                          <p className="text-sm font-semibold text-slate-900">{review.title}</p>
                          <p className="mt-0.5 text-xs text-slate-500">
                            {review.authorName}
                            {review.authorCompany ? ` · ${review.authorCompany}` : ""} · {formatDate(review.createdAt)}
                          </p>
                        </div>
                        <RatingStars value={review.rating} />
                      </div>
                      <p className="mt-3 text-sm leading-relaxed text-slate-700">{review.body}</p>
                    </Card>
                  ))
                )}
              </div>
            )}
          </div>
        </div>

        <div className="lg:sticky lg:top-24 lg:self-start">
          <Card>
            <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">انتخاب نوع لایسنس</p>
            <div className="mt-4 space-y-2.5">
              {product.plans.map((p) => (
                <button
                  key={p.id}
                  onClick={() => setSelectedPlan(p.id)}
                  className={cn(
                    "w-full rounded-xl border p-4 text-start transition",
                    p.id === plan?.id
                      ? "border-indigo-500 bg-indigo-50/70 ring-2 ring-indigo-500/20"
                      : "border-slate-200 hover:border-slate-300 hover:bg-slate-50",
                  )}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <p className="flex items-center gap-2 text-sm font-semibold text-slate-900">
                        {p.name}
                        {p.isPopular && <Badge tone="indigo">پیشنهادی</Badge>}
                      </p>
                      <p className="mt-0.5 text-xs text-slate-500">
                        {p.tier === "SingleUser" ? "1 named user" : `${p.seats} seats`} ·{" "}
                        {p.billingType === "OneTime" ? "one-time" : "per year"}
                      </p>
                    </div>
                    <div className="text-end">
                      <p className="text-sm font-bold text-slate-900">{formatMoney(p.priceCents)}</p>
                      {p.billingType === "Annual" && <p className="text-[11px] text-slate-500">/ سال</p>}
                    </div>
                  </div>
                  {p.description && <p className="mt-2 text-xs leading-relaxed text-slate-500">{p.description}</p>}
                </button>
              ))}
            </div>

            <div className="mt-4 flex items-center justify-between rounded-lg border border-slate-200 p-3">
              <span className="text-xs font-semibold uppercase tracking-wide text-slate-500">تعداد</span>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm" onClick={() => setQuantity((q) => Math.max(1, q - 1))} aria-label="کاهش تعداد">
                  −
                </Button>
                <span className="w-8 text-center text-sm font-semibold">{quantity}</span>
                <Button variant="outline" size="sm" onClick={() => setQuantity((q) => Math.min(50, q + 1))} aria-label="افزایش تعداد">
                  +
                </Button>
              </div>
            </div>

            <div className="mt-4 space-y-2">
              <Button className="w-full" size="lg" loading={adding} onClick={() => void handleAddToCart()}>
                افزودن به سبد · {formatMoney((plan?.priceCents ?? 0) * quantity)}
              </Button>
              <div className="grid grid-cols-2 gap-2">
                <Button variant="outline" onClick={() => void handleTrial()}>نسخه آزمایشی</Button>
                <Button variant="outline" onClick={() => setDemoOpen(true)}>
                  ثبت درخواست دمو
                </Button>
              </div>
            </div>

            <ul className="mt-5 space-y-2 border-t border-slate-100 pt-4 text-xs text-slate-500">
              <li>✓ {faNum(product.trialDays)} روز نسخه آزمایشی کامل، بدون نیاز به کارت بانکی</li>
              <li>✓ ۱۲ ماه به‌روزرسانی همراه لایسنس دائمی</li>
              <li>✓ ۳۰ روز ضمانت بازگشت وجه</li>
              <li>✓ تخفیف حجمی و سازمانی موجود است</li>
            </ul>
          </Card>

          <Card className="mt-4">
            <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">مقایسه</p>
            <div className="mt-3 flex flex-wrap gap-2">
              <Link href={`/compare?ids=${product.id}`}>
                <Button variant="outline" size="sm">مقایسه محصولات</Button>
              </Link>
              <Link href="/contact?topic=Sales">
                <Button variant="ghost" size="sm">
                  گفتگو با تیم فروش
                </Button>
              </Link>
            </div>
          </Card>
        </div>
      </div>

      <ReviewModal
        open={reviewOpen}
        onClose={() => setReviewOpen(false)}
        product={product}
        authenticated={Boolean(user)}
        onSubmitted={(review) => {
          setReviews((prev) => [review, ...prev]);
          push({ tone: "success", title: "نظر ثبت شد", description: "سپاس! نظر شما برای بررسی ثبت شد." });
        }}
      />

      <DemoModal open={demoOpen} onClose={() => setDemoOpen(false)} product={product} />
    </div>
  );
}

function ReviewModal({
  open,
  onClose,
  product,
  authenticated,
  onSubmitted,
}: {
  open: boolean;
  onClose: () => void;
  product: ProductDetailDto;
  authenticated: boolean;
  onSubmitted: (review: ReviewDto) => void;
}) {
  const [rating, setRating] = useState(5);
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [company, setCompany] = useState("");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { push } = useToast();

  async function submit() {
    setSaving(true);
    setError(null);
    try {
      const { data } = await api.post<ReviewDto>("/api/reviews", {
        productId: product.id,
        rating,
        title,
        body,
        authorCompany: company || null,
      });
      onSubmitted(data);
      onClose();
      setTitle("");
      setBody("");
    } catch (err) {
      const message = err instanceof Error ? err.message : "ثبت نظر ناموفق بود";
      setError(message);
      push({ tone: "error", title: "ثبت نظر ناموفق بود", description: message });
    } finally {
      setSaving(false);
    }
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={`ثبت نظر برای ${product.name}`}
      description="نظرات پیش از انتشار بررسی می‌شوند — معمولاً در یک روز کاری."
      footer={
        <>
          <Button variant="ghost" onClick={onClose}>انصراف</Button>
          <Button loading={saving} onClick={() => void submit()} disabled={!authenticated || title.length < 3 || body.length < 10}>
            ثبت نظر
          </Button>
        </>
      }
    >
      {!authenticated ? (
        <div className="rounded-lg border border-amber-200 bg-amber-50 p-4 text-sm text-amber-800">
          برای ثبت نظر باید وارد حساب خود شوید.{" "}
          <Link href="/login" className="font-semibold underline">
            ورود
          </Link>{" "} یا{" "} <Link href="/register" className="font-semibold underline">
            ایجاد حساب کاربری
          </Link>
          .
        </div>
      ) : (
        <div className="space-y-4">
          <Field label="امتیاز شما">
            <div className="flex items-center gap-2">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  onClick={() => setRating(star)}
                  className={cn(
                    "h-10 w-10 rounded-lg border text-lg transition",
                    star <= rating
                      ? "border-amber-300 bg-amber-50 text-amber-500"
                      : "border-slate-200 text-slate-300 hover:border-slate-300",
                  )}
                >
                  ★
                </button>
              ))}
            </div>
          </Field>
          <Field label="عنوان" required>
            <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="خلاصه تجربه شما" />
          </Field>
          <Field label="متن نظر" required hint="حداقل ۱۰ کاراکتر">
            <Textarea
              value={body}
              onChange={(e) => setBody(e.target.value)}
              placeholder="چه کاری با آن انجام دادید؟ چه چیزی خوب کار کرد؟ چه چیزی بهتر می‌شود؟"
              rows={5}
            />
          </Field>
          <Field label="شرکت (اختیاری)">
            <Input value={company} onChange={(e) => setCompany(e.target.value)} placeholder="صنایع نمونه" />
          </Field>
          {error && <p className="text-sm font-medium text-rose-600">{error}</p>}
        </div>
      )}
    </Modal>
  );
}

function DemoModal({
  open,
  onClose,
  product,
}: {
  open: boolean;
  onClose: () => void;
  product: ProductDetailDto;
}) {
  const [form, setForm] = useState({ name: "", email: "", company: "", companySize: "11-50", message: "" });
  const [saving, setSaving] = useState(false);
  const [done, setDone] = useState(false);
  const { push } = useToast();

  async function submit() {
    setSaving(true);
    try {
      await api.post("/api/demos", {
        productId: product.id,
        name: form.name,
        email: form.email,
        company: form.company || null,
        companySize: form.companySize,
        message: form.message || null,
      });
      setDone(true);
      push({
        tone: "success",
        title: "دمو درخواست شد",
        description: "تیم ما در یک روز کاری با شما تماس می‌گیرد.",
      });
    } catch (err) {
      push({
        tone: "error",
        title: "ثبت درخواست دمو ناموفق بود",
        description: err instanceof Error ? err.message : undefined,
      });
    } finally {
      setSaving(false);
    }
  }

  return (
    <Modal
      open={open}
      onClose={() => {
        onClose();
        setDone(false);
      }}
      title={done ? "درخواست دمو ثبت شد" : `درخواست دمو از ${product.name}`}
      description={
        done
          ? "یک مهندس راه‌حل برای هماهنگی یک جلسه ۳۰ دقیقه‌ای با شما تماس می‌گیرد."
          : "کمی درباره محیط خود بگویید تا دمو را متناسب با آن آماده کنیم."
      }
      footer={
        done ? (
          <Button onClick={onClose}>بستن</Button>
        ) : (
          <>
            <Button variant="ghost" onClick={onClose}>انصراف</Button>
            <Button loading={saving} onClick={() => void submit()} disabled={!form.name || !form.email.includes("@")}>
              ثبت درخواست دمو
            </Button>
          </>
        )
      }
    >
      {done ? (
        <div className="rounded-lg border border-emerald-200 bg-emerald-50 p-4 text-sm text-emerald-800">
          {form.name} ممنون! یک تأییدیه به {form.email} ایمیل شد.
        </div>
      ) : (
        <div className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="نام و نام خانوادگی" required>
              <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
            </Field>
            <Field label="ایمیل سازمانی" required>
              <Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
            </Field>
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="شرکت">
              <Input value={form.company} onChange={(e) => setForm({ ...form, company: e.target.value })} />
            </Field>
            <Field label="اندازه سازمان">
              <Select value={form.companySize} onChange={(e) => setForm({ ...form, companySize: e.target.value })}>
                {["1-10", "11-50", "51-200", "201-1000", "1000+"].map((size) => (
                  <option key={size} value={size}>
                    {size} کارمند
                  </option>
                ))}
              </Select>
            </Field>
          </div>
          <Field label="چه چیزی می‌خواهید ببینید؟">
            <Textarea
              value={form.message}
              onChange={(e) => setForm({ ...form, message: e.target.value })}
              rows={3}
              placeholder="سیستم‌های فعلی، تعداد کاربران، هر نکته خاص..."
            />
          </Field>
        </div>
      )}
    </Modal>
  );
}
