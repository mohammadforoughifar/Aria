"use client";

import { useState } from "react";
import { cn } from "@/components/ui";

export interface ChartPoint {
  label: string;
  value: number;
}

export function BarChart({
  data,
  formatValue,
  height = 220,
}: {
  data: ChartPoint[];
  formatValue?: (value: number) => string;
  height?: number;
}) {
  const [hover, setHover] = useState<number | null>(null);
  const max = Math.max(1, ...data.map((d) => d.value));
  return (
    <div className="w-full">
      <div className="flex items-end gap-3" style={{ height }}>
        {data.map((point, i) => (
          <div
            key={`${point.label}-${i}`}
            className="group relative flex h-full flex-1 flex-col justify-end"
            onMouseEnter={() => setHover(i)}
            onMouseLeave={() => setHover(null)}
          >
            {hover === i && (
              <div className="absolute -top-1 left-1/2 z-10 -translate-x-1/2 whitespace-nowrap rounded-lg bg-slate-900 px-2 py-1 text-xs font-semibold text-white shadow-lg">
                {formatValue ? formatValue(point.value) : point.value}
              </div>
            )}
            <div
              className={cn(
                "w-full rounded-t-md bg-gradient-to-t from-indigo-500 to-indigo-400 transition-all",
                hover === i && "from-indigo-600 to-violet-400",
              )}
              style={{ height: `${Math.max(4, (point.value / max) * 100)}%` }}
            />
          </div>
        ))}
      </div>
      <div className="mt-2 flex gap-3">
        {data.map((point, i) => (
          <div key={`label-${point.label}-${i}`} className="flex-1 truncate text-center text-[11px] font-medium text-slate-500">
            {point.label}
          </div>
        ))}
      </div>
    </div>
  );
}

export function AreaChart({
  data,
  formatValue,
  height = 220,
}: {
  data: ChartPoint[];
  formatValue?: (value: number) => string;
  height?: number;
}) {
  const [hover, setHover] = useState<number | null>(null);
  if (!data.length) {
    return <div className="flex h-40 items-center justify-center text-sm text-slate-400">هنوز داده‌ای موجود نیست</div>;
  }
  const max = Math.max(1, ...data.map((d) => d.value));
  const step = data.length > 1 ? 100 / (data.length - 1) : 100;
  const points = data.map((d, i) => ({ x: i * step, y: 100 - (d.value / max) * 92, ...d }));
  const line = points.map((p, i) => `${i === 0 ? "M" : "L"} ${p.x.toFixed(2)} ${p.y.toFixed(2)}`).join(" ");
  const area = `${line} L 100 100 L 0 100 Z`;

  return (
    <div className="relative w-full" style={{ height }}>
      <svg viewBox="0 0 100 100" preserveAspectRatio="none" className="h-full w-full">
        <defs>
          <linearGradient id="area-fill" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#6366f1" stopOpacity="0.35" />
            <stop offset="100%" stopColor="#6366f1" stopOpacity="0" />
          </linearGradient>
        </defs>
        {[25, 50, 75].map((y) => (
          <line key={y} x1="0" y1={y} x2="100" y2={y} stroke="#e2e8f0" strokeWidth="0.4" />
        ))}
        <path d={area} fill="url(#area-fill)" />
        <path d={line} fill="none" stroke="#4f46e5" strokeWidth="1.4" vectorEffect="non-scaling-stroke" />
        {points.map((p, i) => (
          <circle key={i} cx={p.x} cy={p.y} r={hover === i ? 1.6 : 1} fill="#4f46e5" stroke="#fff" strokeWidth="0.5" />
        ))}
      </svg>
      <div className="absolute inset-0 flex">
        {data.map((_, i) => (
          <div key={i} className="h-full flex-1" onMouseEnter={() => setHover(i)} onMouseLeave={() => setHover(null)} />
        ))}
      </div>
      {hover !== null && (
        <div
          className="pointer-events-none absolute top-0 -translate-x-1/2 whitespace-nowrap rounded-lg bg-slate-900 px-2 py-1 text-xs font-semibold text-white shadow-lg"
          style={{ left: `${(hover / Math.max(1, data.length - 1)) * 100}%` }}
        >
          {data[hover].label}: {formatValue ? formatValue(data[hover].value) : data[hover].value}
        </div>
      )}
      <div className="mt-1 flex">
        {data.map((point, i) => (
          <div key={i} className="flex-1 truncate text-center text-[11px] font-medium text-slate-500">
            {point.label}
          </div>
        ))}
      </div>
    </div>
  );
}

export function DonutChart({
  data,
  formatValue,
  size = 180,
}: {
  data: { label: string; value: number; color?: string }[];
  formatValue?: (value: number) => string;
  size?: number;
}) {
  const palette = ["#4f46e5", "#0ea5e9", "#10b981", "#f59e0b", "#f43f5e", "#8b5cf6", "#64748b"];
  const total = data.reduce((sum, d) => sum + d.value, 0) || 1;
  let offset = 0;
  const radius = 42;
  const circumference = 2 * Math.PI * radius;

  return (
    <div className="flex flex-wrap items-center gap-6">
      <svg viewBox="0 0 100 100" style={{ width: size, height: size }} className="shrink-0 -rotate-90">
        <circle cx="50" cy="50" r={radius} fill="none" stroke="#f1f5f9" strokeWidth="14" />
        {data.map((d, i) => {
          const portion = (d.value / total) * circumference;
          const el = (
            <circle
              key={d.label}
              cx="50"
              cy="50"
              r={radius}
              fill="none"
              stroke={d.color ?? palette[i % palette.length]}
              strokeWidth="14"
              strokeDasharray={`${portion} ${circumference - portion}`}
              strokeDashoffset={-offset}
              strokeLinecap="butt"
            />
          );
          offset += portion;
          return el;
        })}
      </svg>
      <ul className="min-w-40 flex-1 space-y-2">
        {data.map((d, i) => (
          <li key={d.label} className="flex items-center justify-between gap-3 text-sm">
            <span className="flex items-center gap-2 text-slate-600">
              <span className="h-2.5 w-2.5 rounded-full" style={{ background: d.color ?? palette[i % palette.length] }} />
              {d.label}
            </span>
            <span className="font-semibold text-slate-900">{formatValue ? formatValue(d.value) : d.value}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}
