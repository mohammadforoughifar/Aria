"use client";

import { useSearchParams } from "next/navigation";
import { Suspense, useState } from "react";
import { Badge, Button, Card, Field, Input, Select, Textarea, useToast } from "@/components/ui";
import { api } from "@/lib/client/api";

function ContactForm() {
  const params = useSearchParams();
  const { push } = useToast();
  const [form, setForm] = useState({
    name: "",
    email: "",
    company: "",
    topic: params.get("topic") ?? "Sales",
    message: "",
  });
  const [saving, setSaving] = useState(false);
  const [done, setDone] = useState(false);

  async function submit() {
    setSaving(true);
    try {
      await api.post("/api/contact", { ...form, company: form.company || null });
      setDone(true);
      push({ tone: "success", title: "پیام ارسال شد", description: "در یک روز کاری پاسخ می‌دهیم." });
    } catch (error) {
      push({
        tone: "error",
        title: "ارسال پیام ناموفق بود",
        description: error instanceof Error ? error.message : undefined,
      });
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
      <Badge tone="indigo">تماس</Badge>
      <h1 className="mt-3 text-3xl font-bold tracking-tight text-slate-900">با یک انسان صحبت کنید</h1>
      <p className="mt-1.5 max-w-2xl text-slate-600">
        پرسش‌های فروش، بررسی فنی عمیق یا ایده‌های همکاری — این فرم مستقیماً به تیم درست می‌رسد.
      </p>

      <div className="mt-8 grid gap-6 lg:grid-cols-[1fr_340px]">
        <Card>
          {done ? (
            <div className="py-10 text-center">
              <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-emerald-100 text-2xl">✅</div>
              <h2 className="mt-4 text-lg font-semibold text-slate-900">{form.name} عزیز، ممنون!</h2>
              <p className="mt-1 text-sm text-slate-600">
                پیام شما دریافت شد و در یک روز کاری به {form.email} پاسخ می‌دهیم.
              </p>
              <Button className="mt-6" variant="outline" onClick={() => setDone(false)}>
                ارسال پیام دیگر
              </Button>
            </div>
          ) : (
            <>
              <h2 className="text-base font-semibold text-slate-900">برای ما پیام بگذارید</h2>
              <div className="mt-4 grid gap-4 sm:grid-cols-2">
                <Field label="نام و نام خانوادگی" required>
                  <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
                </Field>
                <Field label="ایمیل سازمانی" required>
                  <Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
                </Field>
                <Field label="شرکت">
                  <Input value={form.company} onChange={(e) => setForm({ ...form, company: e.target.value })} />
                </Field>
                <Field label="موضوع">
                  <Select value={form.topic} onChange={(e) => setForm({ ...form, topic: e.target.value })}>
                    {["Sales", "Support", "Partnership", "General"].map((t) => (
                      <option key={t}>{t}</option>
                    ))}
                  </Select>
                </Field>
                <Field label="پیام" required className="sm:col-span-2">
                  <Textarea
                    value={form.message}
                    onChange={(e) => setForm({ ...form, message: e.target.value })}
                    rows={6}
                    placeholder="درباره محیط اجرا، اندازه تیم و مسئله‌ای که می‌خواهید حل کنید بنویسید."
                  />
                </Field>
              </div>
              <div className="mt-5 flex justify-end">
                <Button
                  loading={saving}
                  disabled={form.name.length < 2 || !form.email.includes("@") || form.message.length < 10}
                  onClick={() => void submit()}
                >
                  ارسال پیام
                </Button>
              </div>
            </>
          )}
        </Card>

        <div className="space-y-4">
          <Card>
            <h3 className="text-sm font-semibold text-slate-900">راه‌های ارتباطی</h3>
            <dl className="mt-3 space-y-3 text-sm">
              {[
                ["Sales", "sales@northwindsoft.example"],
                ["Support", "support@northwindsoft.example"],
                ["Phone", "+1 (888) 555-0142"],
                ["Office", "هالوسترأت ۴۲، روتردام، هلند"],
              ].map(([label, value]) => (
                <div key={label}>
                  <dt className="text-xs font-semibold uppercase tracking-wide text-slate-500">{label}</dt>
                  <dd className="mt-0.5 text-slate-700">{value}</dd>
                </div>
              ))}
            </dl>
          </Card>
          <Card>
            <h3 className="text-sm font-semibold text-slate-900">ساعات کاری</h3>
            <ul className="mt-3 space-y-2 text-sm text-slate-600">
              <li className="flex justify-between">
                <span>دوشنبه تا جمعه</span>
                <span className="font-medium text-slate-900">۰۷:۰۰ تا ۱۹:۰۰ CET</span>
              </li>
              <li className="flex justify-between">
                <span>شنبه</span>
                <span className="font-medium text-slate-900">۰۹:۰۰ تا ۱۳:۰۰ CET</span>
              </li>
              <li className="flex justify-between">
                <span>حوادث بحرانی</span>
                <span className="font-medium text-emerald-600">24 / 7</span>
              </li>
            </ul>
          </Card>
        </div>
      </div>
    </div>
  );
}

export default function ContactPage() {
  return (
    <Suspense fallback={<div className="mx-auto max-w-3xl px-4 py-16">در حال بارگذاری…</div>}>
      <ContactForm />
    </Suspense>
  );
}
