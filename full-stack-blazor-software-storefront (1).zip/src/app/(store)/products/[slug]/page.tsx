import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { ProductDetail } from "@/components/store/ProductDetail";
import { getProductBySlug, listReviews } from "@/server/services/catalog";
import { ensureSeeded } from "@/server/bootstrap";

export const dynamic = "force-dynamic";

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  try {
    const product = await getProductBySlug(slug);
    return { title: `${product.name} — نورث‌ویند`, description: product.tagline };
  } catch {
    return { title: "محصول پیدا نشد" };
  }
}

export default async function ProductPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  await ensureSeeded();
  let product;
  try {
    product = await getProductBySlug(slug);
  } catch {
    notFound();
  }
  const reviews = await listReviews({ productId: product.id, status: "Approved", page: 1, pageSize: 20 });
  return <ProductDetail product={product} initialReviews={reviews.items} />;
}
