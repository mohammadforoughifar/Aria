"use client";

import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useState } from "react";
import { Badge, Button, Card, EmptyState, RatingStars, Select, SkeletonCard, useToast } from "@/components/ui";
import { useApi, useCart } from "@/lib/client/api";
import { formatMoney, faNum } from "@/lib/format";
import type { ProductDetailDto } from "@/shared/contracts";

function CompareInner() {
  const params = useSearchParams();
  const router = useRouter();
  const { addItem } = useCart();
  const { push } = useToast();
  const ids = (params.get("ids") ?? "").split(",").filter(Boolean);
  const { data, loading } = useApi<{ items: ProductDetailDto[] }>(
    ids.length ? `/api/products/compare?ids=${ids.join(",")}` : null,
  );
  const [selection, setSelection] = useState<Record<string, string>>({});

  const products = data?.items ?? [];

  async function add(product: ProductDetailDto) {
    const planId = selection[product.id] ?? product.plans[0]?.id;
    if (!planId) return;
    try {
      await addItem(planId, 1);
      push({ tone: "success", title: "به سبد اضافه شد", description: product.name });
    } catch (error) {
      push({
        tone: "error",
        title: "افزودن به سبد ناموفق بود",
        description: error instanceof Error ? error.message : undefined,
      });
    }
  }

  if (!ids.length) {
    return (
      <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <EmptyState
          icon="search"
          title="چیزی برای مقایسه نیست"
          description="تا چهار محصول را از فهرست انتخاب کنید تا کنار هم نمایش دهیم."
          action={
            <Link href="/catalog">
              <Button>مشاهده فهرست محصولات</Button>
            </Link>
          }
        />
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <Badge tone="violet">مقایسه کنار هم</Badge>
          <h1 className="mt-3 text-3xl font-bold tracking-tight text-slate-900">مقایسه محصولات</h1>
          <p className="mt-1.5 text-slate-600">
            گزینه‌های لایسنس، قابلیت‌ها و پیش‌نیازها، کنار هم.
          </p>
        </div>
        <Link href="/catalog">
          <Button variant="outline">بازگشت به فهرست محصولات →</Button>
        </Link>
      </div>

      {loading ? (
        <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {ids.slice(0, 4).map((id) => (
            <SkeletonCard key={id} />
          ))}
        </div>
      ) : products.length === 0 ? (
        <div className="mt-8">
          <EmptyState
            icon="box"
            title="این محصولات پیدا نشدند"
            description="ممکن است از فهرست حذف شده باشند."
            action={
              <Link href="/catalog">
                <Button>مشاهده فهرست محصولات</Button>
              </Link>
            }
          />
        </div>
      ) : (
        <div className="mt-8 overflow-x-auto">
          <table className="w-full min-w-[720px] border-separate border-spacing-0">
            <thead>
              <tr>
                <th className="w-48 border-b border-slate-200 pb-4 text-start text-xs font-semibold uppercase tracking-wide text-slate-500">ویژگی</th>
                {products.map((product) => (
                  <th key={product.id} className="border-b border-slate-200 pb-4 ps-4 text-start align-bottom">
                    <div
                      className="flex h-10 w-10 items-center justify-center rounded-xl text-lg"
                      style={{ background: `${product.accentColor}1a`, color: product.accentColor }}
                    >
                      {product.type === "Module" ? "🧩" : product.type === "DesktopApp" ? "🖥️" : "🔌"}
                    </div>
                    <Link
                      href={`/products/${product.slug}`}
                      className="mt-2 block text-sm font-semibold text-slate-900 hover:text-indigo-700"
                    >
                      {product.name}
                    </Link>
                    <p className="mt-0.5 line-clamp-2 text-xs font-normal text-slate-500">{product.tagline}</p>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="text-sm">
              <Row label="دسته‌بندی" products={products} render={(p) => p.categoryName} />
              <Row
                label="نوع محصول"
                products={products}
                render={(p) => (p.type === "DesktopApp" ? "Desktop app" : p.type === "AddOn" ? "Add-on" : "ERP module")}
              />
              <Row
                label="امتیاز"
                products={products}
                render={(p) => (
                  <span className="flex items-center gap-1.5">
                    <RatingStars value={p.ratingAvg} />
                    <span className="text-xs text-slate-500">({p.ratingCount})</span>
                  </span>
                )}
              />
              <Row label="قیمت شروع" products={products} render={(p) => formatMoney(p.basePriceCents)} />
              <Row label="آخرین نسخه" products={products} render={(p) => `v${p.version}`} />
              <Row label="پلتفرم" products={products} render={(p) => p.platform} />
              <Row label="نسخه آزمایشی" products={products} render={(p) => `${p.trialDays} days`} />
              <Row
                label="پلن‌ها"
                products={products}
                render={(p) => (
                  <ul className="space-y-1">
                    {p.plans.map((plan) => (
                      <li key={plan.id} className="flex items-center justify-between gap-2 text-xs">
                        <span className="text-slate-600">{plan.name}</span>
                        <span className="font-semibold text-slate-900">{formatMoney(plan.priceCents)}</span>
                      </li>
                    ))}
                  </ul>
                )}
              />
              <Row
                label="قابلیت‌های کلیدی"
                products={products}
                render={(p) => (
                  <ul className="space-y-1.5">
                    {p.features.slice(0, 4).map((f) => (
                      <li key={f} className="text-xs text-slate-600">
                        ✓ {f}
                      </li>
                    ))}
                    {p.features.length > 4 && (
                      <li className="text-xs font-medium text-indigo-600">+{faNum(p.features.length - 4)} مورد دیگر</li>
                    )}
                  </ul>
                )}
              />
              <Row
                label="پیش‌نیازها"
                products={products}
                render={(p) => (
                  <ul className="space-y-1">
                    {p.systemRequirements.slice(0, 3).map((r) => (
                      <li key={r} className="text-xs text-slate-600">
                        · {r}
                      </li>
                    ))}
                  </ul>
                )}
              />
              <tr>
                <td className="border-t border-slate-200 py-4" />
                {products.map((product) => (
                  <td key={product.id} className="border-t border-slate-200 py-4 ps-4">
                    <Select
                      value={selection[product.id] ?? product.plans[0]?.id ?? ""}
                      onChange={(e) => setSelection((prev) => ({ ...prev, [product.id]: e.target.value }))}
                      aria-label={`انتخاب پلن برای ${product.name}`}
                    >
                      {product.plans.map((plan) => (
                        <option key={plan.id} value={plan.id}>
                          {plan.name} — {formatMoney(plan.priceCents)}
                        </option>
                      ))}
                    </Select>
                    <Button className="mt-2 w-full" size="sm" onClick={() => void add(product)}>افزودن به سبد</Button>
                  </td>
                ))}
              </tr>
            </tbody>
          </table>
        </div>
      )}

      <Card className="mt-8">
        <p className="text-sm text-slate-600">
          برای بسته چند ماژولی قیمت بهتری می‌خواهید؟{" "}
          <button
            className="font-semibold text-indigo-600 hover:text-indigo-500"
            onClick={() => router.push("/contact?topic=Sales")}
          >
            گفتگو با تیم فروش
          </button>{" "}
          — پلن‌های حجمی از ۱۰ کاربر شروع می‌شوند و سازمان‌های غیرانتفاعی ۴۰٪ تخفیف می‌گیرند.
        </p>
      </Card>
    </div>
  );
}

function Row({
  label,
  products,
  render,
}: {
  label: string;
  products: ProductDetailDto[];
  render: (product: ProductDetailDto) => React.ReactNode;
}) {
  return (
    <tr className="align-top">
      <th className="border-t border-slate-200 py-4 text-start text-xs font-semibold uppercase tracking-wide text-slate-500">
        {label}
      </th>
      {products.map((product) => (
        <td key={product.id} className="border-t border-slate-200 py-4 ps-4 text-slate-700">
          {render(product)}
        </td>
      ))}
    </tr>
  );
}

export default function ComparePage() {
  return (
    <Suspense
      fallback={
        <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {Array.from({ length: 4 }).map((_, i) => (
              <SkeletonCard key={i} />
            ))}
          </div>
        </div>
      }
    >
      <CompareInner />
    </Suspense>
  );
}
