"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { Badge, Button, Card, EmptyState, Field, Input, Select, SkeletonRows, Textarea, useToast } from "@/components/ui";
import { api, useAuth, useCart } from "@/lib/client/api";
import { formatMoney, faNum, toFa } from "@/lib/format";
import type { OrderDto } from "@/shared/contracts";

export default function CheckoutPage() {
  const router = useRouter();
  const { user, status } = useAuth();
  const { cart, loading, discountCode } = useCart();
  const { push } = useToast();
  const [placing, setPlacing] = useState(false);
  const [order, setOrder] = useState<OrderDto | null>(null);
  const [form, setForm] = useState({
    name: "",
    company: "",
    email: "",
    country: "United States",
    vatId: "",
    paymentMethod: "card" as "card" | "invoice" | "bank-transfer",
    cardName: "",
    cardNumber: "",
    notes: "",
  });

  useEffect(() => {
    if (user) {
      setForm((prev) => ({
        ...prev,
        name: prev.name || user.fullName,
        email: prev.email || user.email,
        company: prev.company || user.company || "",
        country: user.country || "United States",
      }));
    }
  }, [user]);

  async function placeOrder() {
    setPlacing(true);
    try {
      const { data } = await api.post<OrderDto>("/api/orders", {
        discountCode,
        paymentMethod: form.paymentMethod,
        cardName: form.cardName,
        cardNumber: form.cardNumber.replace(/\s/g, ""),
        billing: {
          name: form.name,
          company: form.company || null,
          email: form.email,
          country: form.country,
          vatId: form.vatId || null,
        },
        notes: form.notes || null,
      });
      setOrder(data);
      push({
        tone: "success",
        title: "پرداخت موفق",
        description: `Order ${data.orderNumber} confirmed.`,
      });
      router.refresh();
    } catch (error) {
      push({
        tone: "error",
        title: "تسویه حساب ناموفق بود",
        description: error instanceof Error ? error.message : undefined,
      });
    } finally {
      setPlacing(false);
    }
  }

  if (status === "loading" || loading) {
    return (
      <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
        <SkeletonRows rows={4} cols={3} />
      </div>
    );
  }

  if (order) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-16 sm:px-6 lg:px-8">
        <Card className="text-center">
          <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-emerald-100 text-3xl">✅</div>
          <h1 className="mt-5 text-2xl font-bold tracking-tight text-slate-900">
            سپاسگزاریم — سفارش شما تأیید شد
          </h1>
          <p className="mt-2 text-slate-600">شماره سفارش<span className="font-semibold text-slate-900">{order.orderNumber}</span> ·{" "}
            {formatMoney(order.totalCents)} · {faNum(order.items.length)} محصول
          </p>

          <div className="mt-8 space-y-3 text-start">
            {order.items.map((item) => (
              <div key={item.id} className="flex items-center justify-between gap-4 rounded-lg border border-slate-200 p-4">
                <div>
                  <p className="text-sm font-semibold text-slate-900">{item.productName}</p>
                  <p className="text-xs text-slate-500">
                    {item.planName} × {item.quantity} · {item.billingType === "OneTime" ? "دائمی" : "سالانه"}
                  </p>
                </div>
                <p className="text-sm font-semibold">{formatMoney(item.lineTotalCents)}</p>
              </div>
            ))}
          </div>

          <div className="mt-8 grid gap-3 sm:grid-cols-2">
            <Link href="/dashboard/licenses">
              <Button className="w-full">مشاهده کلیدهای لایسنس</Button>
            </Link>
            <Link href="/dashboard/invoices">
              <Button variant="outline" className="w-full">
                دانلود فاکتور
              </Button>
            </Link>
          </div>
          <p className="mt-4 text-xs text-slate-500">
            یک تأییدیه به {order.billingEmail ?? order.customerEmail} ایمیل شد. نصب‌کننده‌ها بلافاصله در صفحه دانلودهای شما در دسترس هستند.
          </p>
        </Card>
      </div>
    );
  }

  if (status === "anonymous") {
    return (
      <div className="mx-auto max-w-3xl px-4 py-16 sm:px-6 lg:px-8">
        <EmptyState
          icon="key"
          title="برای تکمیل خرید وارد شوید"
          description="لایسنس‌ها به حساب شما متصل هستند، پس پیش از تسویه باید وارد شوید. سبد خرید شما ذخیره می‌شود."
          action={
            <div className="flex flex-wrap justify-center gap-2">
              <Link href="/login?redirect=/checkout">
                <Button size="lg">ورود</Button>
              </Link>
              <Link href="/register?redirect=/checkout">
                <Button size="lg" variant="outline">
                  ایجاد حساب کاربری
                </Button>
              </Link>
            </div>
          }
        />
      </div>
    );
  }

  if (!cart || cart.items.length === 0) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-16 sm:px-6 lg:px-8">
        <EmptyState
          icon="cart"
          title="چیزی برای تسویه وجود ندارد"
          description="سبد خرید شما خالی است. یک پلن محصول اضافه کنید و بازگردید."
          action={
            <Link href="/catalog">
              <Button size="lg">مشاهده محصولات</Button>
            </Link>
          }
        />
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
      <Badge tone="indigo">مرحله ۲ از ۲</Badge>
      <h1 className="mt-3 text-3xl font-bold tracking-tight text-slate-900">تسویه حساب</h1>
      <p className="mt-1.5 text-slate-600">
        وارد شده‌اید با {user?.email}. کلیدهای لایسنس به‌محض تأیید پرداخت صادر می‌شوند.
      </p>

      <div className="mt-8 grid gap-6 lg:grid-cols-[1fr_360px]">
        <div className="space-y-6">
          <Card>
            <h2 className="text-base font-semibold text-slate-900">اطلاعات صورتحساب</h2>
            <div className="mt-4 grid gap-4 sm:grid-cols-2">
              <Field label="نام و نام خانوادگی" required>
                <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
              </Field>
              <Field label="ایمیل" required>
                <Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
              </Field>
              <Field label="شرکت">
                <Input value={form.company} onChange={(e) => setForm({ ...form, company: e.target.value })} />
              </Field>
              <Field label="کشور" required>
                <Select value={form.country} onChange={(e) => setForm({ ...form, country: e.target.value })}>
                  {["United States", "United Kingdom", "Germany", "Spain", "Japan", "Canada", "Australia", "Singapore"].map(
                    (c) => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ),
                  )}
                </Select>
              </Field>
              <Field label="کد مالیاتی / VAT" hint="اختیاری — روی فاکتور درج می‌شود">
                <Input value={form.vatId} onChange={(e) => setForm({ ...form, vatId: e.target.value })} />
              </Field>
            </div>
          </Card>

          <Card>
            <h2 className="text-base font-semibold text-slate-900">روش پرداخت</h2>
            <div className="mt-4 grid gap-3 sm:grid-cols-3">
              {[
                { id: "card", label: "کارت بانکی", hint: "تحویل فوری" },
                { id: "invoice", label: "فاکتور", hint: "شرط ۱۴ روزه" },
                { id: "bank-transfer", label: "انتقال بانکی", hint: "۱ تا ۲ روز" },
              ].map((method) => (
                <button
                  key={method.id}
                  onClick={() => setForm({ ...form, paymentMethod: method.id as typeof form.paymentMethod })}
                  className={
                    form.paymentMethod === method.id
                      ? "rounded-xl border-2 border-indigo-500 bg-indigo-50/60 p-4 text-start"
                      : "rounded-xl border border-slate-200 p-4 text-start transition hover:border-slate-300"
                  }
                >
                  <p className="text-sm font-semibold text-slate-900">{method.label}</p>
                  <p className="mt-0.5 text-xs text-slate-500">{method.hint}</p>
                </button>
              ))}
            </div>

            {form.paymentMethod === "card" && (
              <div className="mt-5 grid gap-4 sm:grid-cols-2">
                <Field label="نام روی کارت" required className="sm:col-span-2">
                  <Input value={form.cardName} onChange={(e) => setForm({ ...form, cardName: e.target.value })} />
                </Field>
                <Field label="شماره کارت" required className="sm:col-span-2">
                  <Input
                    value={form.cardNumber}
                    onChange={(e) => setForm({ ...form, cardNumber: e.target.value })}
                    placeholder="4242 4242 4242 4242"
                    inputMode="numeric"
                  />
                </Field>
              </div>
            )}

            <Field label="یادداشت سفارش" className="mt-4">
              <Textarea
                value={form.notes}
                onChange={(e) => setForm({ ...form, notes: e.target.value })}
                rows={3}
                placeholder="هر نکته‌ای که تیم صدور لایسنس باید بداند (شماره سفارش خرید، مرکز هزینه…)"
              />
            </Field>
            <p className="mt-4 text-xs text-slate-500">
              این یک محیط نمایشی است — هر شماره کارتی وارد کنید، هزینه‌ای دریافت نمی‌شود.
            </p>
          </Card>
        </div>

        <div className="lg:sticky lg:top-24 lg:self-start">
          <Card>
            <h2 className="text-base font-semibold text-slate-900">سفارش شما</h2>
            <ul className="mt-4 space-y-3">
              {cart.items.map((item) => (
                <li key={item.id} className="flex items-start justify-between gap-3 text-sm">
                  <span>
                    <span className="font-medium text-slate-900">{item.productName}</span>
                    <span className="block text-xs text-slate-500">
                      {item.planName} × {item.quantity}
                    </span>
                  </span>
                  <span className="font-semibold text-slate-900">{formatMoney(item.lineTotalCents)}</span>
                </li>
              ))}
            </ul>
            <div className="mt-4 space-y-2 border-t border-slate-200 pt-4 text-sm">
              <div className="flex justify-between text-slate-600">
                <span>جمع جزء</span>
                <span>{formatMoney(cart.subtotalCents)}</span>
              </div>
              {cart.discountCents > 0 && (
                <div className="flex justify-between text-emerald-600">
                  <span>تخفیف ({cart.discountCode})</span>
                  <span>−{formatMoney(cart.discountCents)}</span>
                </div>
              )}
              <div className="flex justify-between text-slate-600">
                <span>مالیات ({toFa((cart.taxRateBps / 100).toFixed(1))}٪)</span>
                <span>{formatMoney(cart.taxCents)}</span>
              </div>
              <div className="flex justify-between border-t border-slate-200 pt-2 text-base font-bold text-slate-900">
                <span>مجموع</span>
                <span>{formatMoney(cart.totalCents)}</span>
              </div>
            </div>
            <Button
              className="mt-5 w-full"
              size="lg"
              loading={placing}
              disabled={
                !form.name ||
                !form.email.includes("@") ||
                (form.paymentMethod === "card" && form.cardNumber.length < 4)
              }
              onClick={() => void placeOrder()}
            >
              پرداخت {formatMoney(cart.totalCents)}
            </Button>
            <p className="mt-3 text-center text-xs text-slate-500">
              با پرداخت،{" "}
              <Link href="/legal/terms" className="font-medium text-indigo-600 hover:text-indigo-500">
                شرایط استفاده
              </Link>
              .
            </p>
          </Card>
        </div>
      </div>
    </div>
  );
}
