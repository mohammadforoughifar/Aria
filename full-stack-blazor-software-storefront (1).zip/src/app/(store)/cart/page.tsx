"use client";

import Link from "next/link";
import { useState } from "react";
import { Badge, Button, Card, EmptyState, Input, SkeletonRows, useToast } from "@/components/ui";
import { useCart } from "@/lib/client/api";
import { formatMoney } from "@/lib/format";

export default function CartPage() {
  const { cart, loading, setQuantity, removeItem, applyDiscount, clearDiscount, discountCode } = useCart();
  const { push } = useToast();
  const [code, setCode] = useState("");
  const [applying, setApplying] = useState(false);

  async function handleApply() {
    if (!code.trim()) return;
    setApplying(true);
    try {
      await applyDiscount(code.trim().toUpperCase());
      push({
        tone: "success",
        title: "تخفیف اعمال شد",
        description: `$کد {code.trim().toUpperCase()} روی سفارش شما اعمال شد.`,
      });
      setCode("");
    } catch (error) {
      push({
        tone: "error",
        title: "تخفیف اعمال نشد",
        description: error instanceof Error ? error.message : undefined,
      });
    } finally {
      setApplying(false);
    }
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
      <Badge tone="indigo">مرحله ۱ از ۲</Badge>
      <h1 className="mt-3 text-3xl font-bold tracking-tight text-slate-900">سبد خرید شما</h1>
      <p className="mt-1.5 text-slate-600">
        لایسنس‌ها بلافاصله پس از پرداخت صادر می‌شوند — کلیدها در داشبورد شما نمایش داده می‌شوند.
      </p>

      {loading ? (
        <div className="mt-8">
          <SkeletonRows rows={3} cols={4} />
        </div>
      ) : !cart || cart.items.length === 0 ? (
        <div className="mt-8">
          <EmptyState
            icon="cart"
            title="سبد خرید شما خالی است"
            description="فهرست محصولات را ببینید و یک لایسنس اضافه کنید — می‌توانید ماژول، برنامه دسکتاپ و افزونه را در یک سفارش ترکیب کنید."
            action={
              <Link href="/catalog">
                <Button size="lg">مشاهده محصولات</Button>
              </Link>
            }
          />
        </div>
      ) : (
        <div className="mt-8 grid gap-6 lg:grid-cols-[1fr_360px]">
          <div className="space-y-4">
            {cart.items.map((item) => (
              <Card key={item.id} className="flex flex-wrap items-start gap-4">
                <div
                  className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl text-xl"
                  style={{ background: `${item.accentColor}1a`, color: item.accentColor }}
                >
                  {item.tier === "Enterprise" ? "🏢" : item.tier === "MultiUser" ? "👥" : "👤"}
                </div>
                <div className="min-w-48 flex-1">
                  <Link href={`/products/${item.productSlug}`} className="text-sm font-semibold text-slate-900 hover:text-indigo-700">
                    {item.productName}
                  </Link>
                  <p className="mt-0.5 text-xs text-slate-500">
                    {item.planName} · {item.billingType === "OneTime" ? "لایسنس یک‌باره" : "اشتراک سالانه"}
                  </p>
                  <p className="mt-2 text-sm font-semibold text-slate-900">
                    {formatMoney(item.unitPriceCents)}
                    <span className="ms-1 text-xs font-normal text-slate-500">هر لایسنس</span>
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => void setQuantity(item.id, Math.max(1, item.quantity - 1))}
                    aria-label="کاهش تعداد"
                  >
                    −
                  </Button>
                  <span className="w-8 text-center text-sm font-semibold">{item.quantity}</span>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => void setQuantity(item.id, Math.min(50, item.quantity + 1))}
                    aria-label="افزایش تعداد"
                  >
                    +
                  </Button>
                </div>
                <div className="ms-auto text-end">
                  <p className="text-sm font-bold text-slate-900">{formatMoney(item.lineTotalCents)}</p>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="mt-1 text-rose-600 hover:bg-rose-50"
                    onClick={() => void removeItem(item.id)}
                  >حذف</Button>
                </div>
              </Card>
            ))}
          </div>

          <div className="lg:sticky lg:top-24 lg:self-start">
            <Card>
              <h2 className="text-base font-semibold text-slate-900">خلاصه سفارش</h2>
              <div className="mt-4 space-y-2.5">
                <Row
                  label={`Subtotal (${cart.itemCount} item${cart.itemCount === 1 ? "" : "s"})`}
                  value={formatMoney(cart.subtotalCents)}
                />
                {cart.discountCents > 0 && (
                  <Row
                    label={
                      <span className="flex items-center gap-2">تخفیف<Badge tone="green">{cart.discountCode}</Badge>
                      </span>
                    }
                    value={`−${formatMoney(cart.discountCents)}`}
                    positive
                  />
                )}
                <Row label={`Tax (${(cart.taxRateBps / 100).toFixed(1)}%)`} value={formatMoney(cart.taxCents)} />
                <div className="border-t border-slate-200 pt-3">
                  <Row label="مجموع" value={formatMoney(cart.totalCents)} bold />
                </div>
              </div>

              <div className="mt-5">
                {cart.discountCode ? (
                  <div className="flex items-center justify-between rounded-lg border border-emerald-200 bg-emerald-50 px-3 py-2.5">
                    <span className="text-xs font-semibold text-emerald-800">کد {cart.discountCode} اعمال شد</span>
                    <Button variant="ghost" size="sm" onClick={() => void clearDiscount()}>حذف</Button>
                  </div>
                ) : (
                  <>
                    <div className="flex gap-2">
                      <Input
                        value={code}
                        onChange={(e) => setCode(e.target.value.toUpperCase())}
                        placeholder="کد تخفیف"
                        aria-label="کد تخفیف"
                      />
                      <Button variant="outline" loading={applying} onClick={() => void handleApply()}>اعمال</Button>
                    </div>
                    {discountCode === null && (
                      <p className="mt-2 text-xs text-slate-500">کد LAUNCH25 را برای ۲۵٪ تخفیف امتحان کنید.</p>
                    )}
                  </>
                )}
              </div>

              <Link href="/checkout" className="mt-5 block">
                <Button className="w-full" size="lg">ادامه تسویه حساب</Button>
              </Link>
              <Link href="/catalog" className="mt-2 block">
                <Button variant="ghost" className="w-full">
                  ادامه خرید
                </Button>
              </Link>
            </Card>

            <Card className="mt-4">
              <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">شامل</p>
              <ul className="mt-3 space-y-2 text-xs text-slate-600">
                <li>✓ کلید لایسنس فوری پس از پرداخت</li>
                <li>✓ نصب‌کننده و نسخه‌های پیشین در پورتال شما</li>
                <li>✓ فایل PDF فاکتور برای حسابداری</li>
                <li>✓ ۳۰ روز ضمانت بازگشت وجه</li>
              </ul>
            </Card>
          </div>
        </div>
      )}
    </div>
  );
}

function Row({
  label,
  value,
  bold,
  positive,
}: {
  label: React.ReactNode;
  value: string;
  bold?: boolean;
  positive?: boolean;
}) {
  return (
    <div className="flex items-center justify-between gap-4 text-sm">
      <span className={bold ? "font-semibold text-slate-900" : "text-slate-600"}>{label}</span>
      <span
        className={
          bold
            ? "text-lg font-bold text-slate-900"
            : positive
              ? "font-semibold text-emerald-600"
              : "font-medium text-slate-900"
        }
      >
        {value}
      </span>
    </div>
  );
}
