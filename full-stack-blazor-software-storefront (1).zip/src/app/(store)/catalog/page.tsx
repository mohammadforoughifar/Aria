"use client";

import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useEffect, useMemo, useState } from "react";
import { ProductCard } from "@/components/store/ProductCard";
import { Button, EmptyState, Input, Pagination, Select, SkeletonCard } from "@/components/ui";
import { useApi, useCart } from "@/lib/client/api";
import type { CategoryDto, ProductListItemDto } from "@/shared/contracts";
import { faNum } from "@/lib/format";

const PAGE_SIZE = 9;

const SORTS = [
  { value: "newest", label: "جدیدترین" },
  { value: "popular", label: "محبوب‌ترین" },
  { value: "rating", label: "بیشترین امتیاز" },
  { value: "price-asc", label: "قیمت: کم به زیاد" },
  { value: "price-desc", label: "قیمت: زیاد به کم" },
  { value: "name", label: "نام الف تا ی" },
];

function CatalogInner() {
  const router = useRouter();
  const params = useSearchParams();
  const { cart } = useCart();

  const [search, setSearch] = useState(params.get("search") ?? "");
  const [debounced, setDebounced] = useState(search);
  const [compare, setCompare] = useState<string[]>([]);

  const category = params.get("category") ?? "all";
  const type = params.get("type") ?? "all";
  const sortBy = params.get("sortBy") ?? "newest";
  const page = Number(params.get("page") ?? 1) || 1;

  useEffect(() => {
    const timer = setTimeout(() => setDebounced(search), 350);
    return () => clearTimeout(timer);
  }, [search]);

  const query = useMemo(() => {
    const qs = new URLSearchParams({ pageSize: String(PAGE_SIZE), sortBy, page: String(page) });
    if (category !== "all") qs.set("category", category);
    if (type !== "all") qs.set("type", type);
    if (debounced.trim()) qs.set("search", debounced.trim());
    return qs.toString();
  }, [category, type, sortBy, page, debounced]);

  const { data, meta, loading, error } = useApi<{ items: ProductListItemDto[] }>(`/api/products?${query}`);
  const { data: categoryداده‌ها } = useApi<{ items: CategoryDto[] }>("/api/categories");

  const setParam = (key: string, value: string) => {
    const next = new URLSearchParams(params.toString());
    if (!value || value === "all") next.delete(key);
    else next.set(key, value);
    if (key !== "page") next.delete("page");
    router.replace(`/catalog${next.toString() ? `?${next.toString()}` : ""}`, { scroll: false });
  };

  const activeCategory = categoryداده‌ها?.items.find((c) => c.slug === category);
  const items = data?.items ?? [];

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <span className="inline-flex items-center rounded-full bg-indigo-50 px-2.5 py-0.5 text-xs font-semibold text-indigo-700 ring-1 ring-inset ring-indigo-200">
            فهرست محصولات
          </span>
          <h1 className="mt-3 text-3xl font-bold tracking-tight text-slate-900">
            {activeCategory ? activeCategory.name : "همه محصولات"}
          </h1>
          <p className="mt-1.5 max-w-2xl text-slate-600">
            {activeCategory?.description ??
              "ماژول‌های ERP، برنامه‌های دسکتاپ و افزونه‌ها. همه محصولات با یک لایه داده پایه یکپارچه می‌شوند."}
          </p>
        </div>
        {compare.length > 0 && (
          <div className="flex items-center gap-3 rounded-xl border border-indigo-200 bg-indigo-50 px-4 py-2.5">
            <span className="text-sm font-medium text-indigo-900">
              {faNum(compare.length)} محصول برای مقایسه انتخاب شد
            </span>
            <Link href={`/compare?ids=${compare.join(",")}`}>
              <Button size="sm">مقایسه</Button>
            </Link>
            <Button size="sm" variant="ghost" onClick={() => setCompare([])}>پاک کردن</Button>
          </div>
        )}
      </div>

      <div className="mt-8 grid gap-3 rounded-xl border border-slate-200 bg-white p-4 shadow-sm sm:grid-cols-2 lg:grid-cols-4">
        <Input
          value={search}
          onChange={(e) => {
            setSearch(e.target.value);
            setParam("page", "1");
          }}
          placeholder="جستجوی محصولات…"
          aria-label="جستجوی محصولات"
        />
        <Select value={category} onChange={(e) => setParam("category", e.target.value)} aria-label="فیلتر بر اساس دسته‌بندی">
          <option value="all">همه دسته‌بندی‌ها</option>
          {categoryداده‌ها?.items.map((c) => (
            <option key={c.id} value={c.slug}>
              {c.name} ({c.productCount ?? 0})
            </option>
          ))}
        </Select>
        <Select value={type} onChange={(e) => setParam("type", e.target.value)} aria-label="فیلتر بر اساس نوع">
          <option value="all">همه انواع محصول</option>
          <option value="Module">ماژول‌های ERP</option>
          <option value="DesktopApp">برنامه‌های دسکتاپ</option>
          <option value="AddOn">افزونه‌ها</option>
        </Select>
        <Select value={sortBy} onChange={(e) => setParam("sortBy", e.target.value)} aria-label="مرتب‌سازی محصولات">
          {SORTS.map((s) => (
            <option key={s.value} value={s.value}>
              {s.label}
            </option>
          ))}
        </Select>
      </div>

      <div className="mt-8">
        {loading ? (
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {Array.from({ length: 6 }).map((_, i) => (
              <SkeletonCard key={i} />
            ))}
          </div>
        ) : error ? (
          <EmptyState
            icon="search"
            title="فهرست محصولات بارگذاری نشد"
            description={error}
            action={
              <Button variant="outline" onClick={() => router.refresh()}>
                تلاش دوباره
              </Button>
            }
          />
        ) : items.length === 0 ? (
          <EmptyState
            icon="box"
            title="محصولی با این فیلترها پیدا نشد"
            description="عبارت جستجوی دیگری را امتحان کنید یا فیلترها را پاک کنید تا فهرست کامل را ببینید."
            action={
              <Button
                variant="outline"
                onClick={() => {
                  setSearch("");
                  router.replace("/catalog");
                }}
              >پاک کردن فیلترها</Button>
            }
          />
        ) : (
          <>
            <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {items.map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  compared={compare.includes(product.id)}
                  onCompare={(id) =>
                    setCompare((prev) =>
                      prev.includes(id) ? prev.filter((p) => p !== id) : [...prev, id].slice(-4),
                    )
                  }
                />
              ))}
            </div>
            <div className="mt-6 overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
              <Pagination
                page={meta?.page ?? page}
                totalPages={meta?.totalPages ?? 1}
                totalCount={meta?.totalCount}
                onChange={(p) => setParam("page", String(p))}
              />
            </div>
            <p className="mt-4 text-center text-xs text-slate-500">
              نمایش {faNum(items.length)} از {faNum(meta?.totalCount ?? items.length)} محصول ·{" "}
              {cart?.itemCount ? `${faNum(cart.itemCount)} قلم در سبد خرید شما است` : "سبد خرید شما خالی است"}
            </p>
          </>
        )}
      </div>
    </div>
  );
}

export default function CatalogPage() {
  return (
    <Suspense
      fallback={
        <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {Array.from({ length: 6 }).map((_, i) => (
              <SkeletonCard key={i} />
            ))}
          </div>
        </div>
      }
    >
      <CatalogInner />
    </Suspense>
  );
}
