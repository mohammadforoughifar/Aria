"use client";

import { useMemo, useState } from "react";
import { Badge, Card, Input, SkeletonRows } from "@/components/ui";
import { useApi } from "@/lib/client/api";

interface OpenApiDoc {
  info: { title: string; version: string; description: string };
  paths: Record<string, Record<string, { tags: string[]; summary: string; security?: unknown[] }>>;
}

const METHOD_TONES: Record<string, "green" | "blue" | "amber" | "violet" | "red"> = {
  get: "green",
  post: "blue",
  patch: "amber",
  put: "violet",
  delete: "red",
};

export default function ApiDocsPage() {
  const { data, loading } = useApi<OpenApiDoc>("/api/openapi");
  const [filter, setFilter] = useState("");
  const [tag, setTag] = useState("all");

  const entries = useMemo(() => {
    if (!data) return [];
    return Object.entries(data.paths).flatMap(([path, methods]) =>
      Object.entries(methods).map(([method, detail]) => ({
        path,
        method: method.toUpperCase(),
        tag: detail.tags?.[0] ?? "Other",
        summary: detail.summary,
        secured: Boolean(detail.security?.length),
      })),
    );
  }, [data]);

  const tags = useMemo(() => ["all", ...new Set(entries.map((e) => e.tag))], [entries]);
  const filtered = entries.filter(
    (entry) =>
      (tag === "all" || entry.tag === tag) &&
      (filter === "" ||
        entry.path.toLowerCase().includes(filter.toLowerCase()) ||
        entry.summary.toLowerCase().includes(filter.toLowerCase())),
  );

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6 lg:px-8">
      <Badge tone="violet">توسعه‌دهندگان</Badge>
      <h1 className="mt-3 text-3xl font-bold tracking-tight text-slate-900">مستندات API</h1>
      <p className="mt-2 max-w-3xl text-slate-600">
        {data?.info.description ??
          "تمام صفحات فروشگاه و پورتال با این API REST کار می‌کنند. پاسخ‌ها ساختار یکسانی دارند."}
      </p>

      <div className="mt-6 grid gap-3 sm:grid-cols-3">
        <Card>
          <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">آدرس پایه</p>
          <p className="mt-1 font-mono text-sm text-slate-900">/api</p>
        </Card>
        <Card>
          <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">احراز هویت</p>
          <p className="mt-1 text-sm text-slate-900">توکن JWT به‌همراه کوکی نوسازی نشست</p>
        </Card>
        <Card>
          <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">OpenAPI</p>
          <a href="/api/openapi" className="mt-1 text-sm font-semibold text-indigo-600 hover:text-indigo-500">
            دانلود JSON ←
          </a>
        </Card>
      </div>

      <div className="mt-6 flex flex-wrap items-center gap-3">
        <Input
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
          placeholder="فیلتر نقاط پایانی…"
          className="max-w-xs"
          aria-label="فیلتر نقاط پایانی"
        />
        <div className="flex flex-wrap gap-1.5">
          {tags.map((t) => (
            <button
              key={t}
              onClick={() => setTag(t)}
              className={
                t === tag
                  ? "rounded-full bg-indigo-600 px-3 py-1.5 text-xs font-semibold text-white"
                  : "rounded-full bg-white px-3 py-1.5 text-xs font-semibold text-slate-600 ring-1 ring-inset ring-slate-200 hover:bg-slate-50"
              }
            >
              {t}
            </button>
          ))}
        </div>
      </div>

      <div className="mt-6">
        {loading ? (
          <SkeletonRows rows={8} cols={3} />
        ) : (
          <div className="overflow-hidden rounded-xl border border-slate-200 bg-white">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-slate-50 text-start text-xs font-semibold uppercase tracking-wide text-slate-500">
                  <tr>
                    <th className="px-5 py-3">متد</th>
                    <th className="px-5 py-3">نقطه پایانی</th>
                    <th className="px-5 py-3">توضیحات</th>
                    <th className="px-5 py-3">احراز هویت</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filtered.map((entry) => (
                    <tr key={`${entry.method}-${entry.path}`} className="hover:bg-slate-50/60">
                      <td className="px-5 py-3">
                        <Badge tone={METHOD_TONES[entry.method.toLowerCase()] ?? "slate"}>{entry.method}</Badge>
                      </td>
                      <td className="px-5 py-3 font-mono text-xs text-slate-800">{entry.path}</td>
                      <td className="px-5 py-3 text-slate-600">{entry.summary}</td>
                      <td className="px-5 py-3">
                        <Badge tone={entry.secured ? "indigo" : "green"}>
                          {entry.secured ? "نیاز به JWT" : "عمومی"}
                        </Badge>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {filtered.length === 0 && (
              <p className="px-5 py-10 text-center text-sm text-slate-500">نقطه پایانی‌ای با این فیلتر پیدا نشد.</p>
            )}
          </div>
        )}
      </div>

      <Card className="mt-8">
        <h2 className="text-base font-semibold text-slate-900">ساختار پاسخ</h2>
        <pre className="mt-3 overflow-x-auto rounded-lg bg-slate-900 p-4 text-xs leading-relaxed text-slate-100">
{`{
  "success": true,
  "data": { /* resource or array */ },
  "meta": { "page": 1, "pageSize": 12, "totalCount": 42, "totalPages": 4 }
}

// در صورت خطا
{
  "success": false,
  "error": {
    "code": "validation_failed",
    "message": "The request payload failed validation.",
    "details": { "email": ["Invalid email"] }
  }
}`}
        </pre>
      </Card>
    </div>
  );
}
