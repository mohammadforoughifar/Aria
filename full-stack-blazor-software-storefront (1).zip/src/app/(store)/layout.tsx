import type { ReactNode } from "react";
import { ensureSeeded } from "@/server/bootstrap";
import { getSettings } from "@/server/services/catalog";
import { SiteFooter, SiteHeader } from "@/components/site/SiteChrome";

export const dynamic = "force-dynamic";

export default async function StoreLayout({ children }: { children: ReactNode }) {
  await ensureSeeded();
  const settings = await getSettings();
  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader siteName={settings.siteName} />
      <main className="flex-1">{children}</main>
      <SiteFooter settings={settings} />
    </div>
  );
}
