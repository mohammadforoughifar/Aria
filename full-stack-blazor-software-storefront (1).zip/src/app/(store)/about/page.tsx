import Link from "next/link";
import { Badge, Button } from "@/components/ui";
import { faNum } from "@/lib/format";

export const metadata = { title: "درباره نورث‌ویند" };

const TIMELINE = [
  { year: "۲۰۰۴", title: "تأسیس در روتردام", body: "دو مشاور ERP یک ماژول کنترل موجودی برای یک پخش‌کننده محلی ساختند." },
  { year: "۲۰۰۹", title: "اولین مجموعه ERP", body: "مالی، خرید و انبار به‌صورت یک مجموعه یکپارچه با ۱۸۰ مشتری منتشر شد." },
  { year: "۲۰۱۵", title: "جدایی برنامه‌های دسکتاپ", body: "CRM دسکتاپ و صندوق فروشگاهی به‌عنوان محصولات مستقل با داده پایه مشترک عرضه شدند." },
  { year: "۲۰۲۰", title: "دورکاری، ۶۲ نفر", body: "تیم در ۱۴ کشور پخش شد و وعده پاسخ‌گویی ۴ ساعته حفظ شد." },
  { year: "۲۰۲۴", title: "REST نسخه ۲ و اکوسیستم افزونه", body: "کانکتور هوش تجاری و درگاه فاکتور الکترونیکی پلتفرم را به شرکا باز کردند." },
  { year: "۲۰۲۶", title: "۴٬۲۰۰ مشتری", body: "تولیدکنندگان، پخش‌کنندگان و خرده‌فروشان در ۳۸ کشور با نورث‌ویند کار می‌کنند." },
];

export default function AboutPage() {
  return (
    <div>
      <section className="border-b border-slate-200 bg-white py-16">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <Badge tone="indigo">درباره ما</Badge>
          <h1 className="mt-4 text-4xl font-black tracking-tight text-slate-900">
            برای کسب‌وکارهایی که چیزی می‌سازند، نرم‌افزار تولید می‌کنیم
          </h1>
          <p className="mt-5 text-lg leading-9 text-slate-600">
            نورث‌ویند از سال ۲۰۰۴ در حال تولید نرم‌افزار کسب‌وکار است. ما ۶۲ مهندس، حسابدار و متخصص انبار هستیم که
            معتقدیم شرکت‌های متوسط شایسته نرم‌افزاری هم‌سطح Fortune 500 هستند — بدون هزینه سازمانی و بدون اجرای
            چندساله.
          </p>
          <div className="mt-8 grid gap-6 sm:grid-cols-4">
            {[
              { label: "مشتریان", value: "۴٬۲۰۰+" },
              { label: "کشور", value: faNum(38) },
              { label: "اعضای تیم", value: faNum(62) },
              { label: "میانگین سابقه", value: `${faNum(7)} سال` },
            ].map((stat) => (
              <div key={stat.label}>
                <p className="text-3xl font-bold tracking-tight text-slate-900">{stat.value}</p>
                <p className="mt-1 text-xs font-semibold uppercase tracking-wide text-slate-500">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-4xl px-4 py-16 sm:px-6 lg:px-8">
        <h2 className="text-2xl font-bold tracking-tight text-slate-900">مسیر ما تا امروز</h2>
        <ol className="mt-8 space-y-6">
          {TIMELINE.map((item) => (
            <li key={item.year} className="relative rounded-xl border border-slate-200 bg-white p-6 ps-20">
              <span className="absolute start-6 top-6 flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-600 to-violet-500 text-[11px] font-bold text-white">
                {item.year}
              </span>
              <h3 className="text-sm font-semibold text-slate-900">{item.title}</h3>
              <p className="mt-1.5 text-sm leading-7 text-slate-600">{item.body}</p>
            </li>
          ))}
        </ol>
      </section>

      <section className="border-y border-slate-200 bg-white py-16">
        <div className="mx-auto grid max-w-5xl gap-8 px-4 sm:px-6 lg:grid-cols-2 lg:px-8">
          <div>
            <h2 className="text-2xl font-bold tracking-tight text-slate-900">تعهدات ما</h2>
            <ul className="mt-5 space-y-4">
              {[
                ["بدون قفل‌شدگی", "خروجی کامل داده در هر زمان، طرح پایگاه داده مستند و موتورهای پایگاه داده استاندارد."],
                ["بدون قیمت غافلگیرکننده", "هزینه لایسنس از پیش مشخص می‌شود. ۱۲ ماه به‌روزرسانی شامل قیمت است."],
                ["مهندسان به تیکت‌ها پاسخ می‌دهند", "پشتیبانی توسط سازندگان ماژول انجام می‌شود، نه یک تیم مطالعه‌شده از پیش."],
                ["انتشار هفتگی", "انتشار فرعی هر دو هفته، انتشار اصلی هر فصل، با نقشه راه عمومی."],
              ].map(([title, body]) => (
                <li key={title} className="flex gap-3">
                  <span className="mt-1 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-emerald-100 text-[11px] font-bold text-emerald-700">
                    ✓
                  </span>
                  <div>
                    <p className="text-sm font-semibold text-slate-900">{title}</p>
                    <p className="mt-0.5 text-sm leading-7 text-slate-600">{body}</p>
                  </div>
                </li>
              ))}
            </ul>
          </div>
          <div className="rounded-2xl bg-slate-900 p-8 text-slate-300">
            <h2 className="text-lg font-semibold text-white">کار در نورث‌ویند</h2>
            <p className="mt-3 text-sm leading-8">
              ما به‌صورت دورکاری در ۱۴ کشور فعالیم و مراکز مهندسی در روتردام، کراکوف و لیسبون داریم. افرادی را استخدام
              می‌کنیم که کارِ مورد نظر نرم‌افزار ما را انجام داده‌اند — حسابدارانی که برنامه‌نویسی می‌کنند و مسئولان
              انبار که فرایندها را خودکار می‌کنند.
            </p>
            <p className="mt-4 text-sm leading-8">
              فرصت‌های شغلی در صفحه استخدام ما منتشر می‌شوند. اگر ترجیح می‌دهید به‌عنوان شریک با ما بسازید، کیت توسعه
              افزونه ما عمومی است.
            </p>
            <div className="mt-6 flex flex-wrap gap-2">
              <Link href="/contact?topic=Partnership">
                <Button variant="outline" className="border-white/30 bg-white/10 text-white hover:bg-white/20">
                  همکاری با ما
                </Button>
              </Link>
              <Link href="/contact">
                <Button variant="secondary">تماس با ما</Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
