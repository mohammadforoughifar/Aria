import Link from "next/link";
import { ensureSeeded } from "@/server/bootstrap";
import {
  getSettings,
  listCategories,
  listFaqs,
  listProducts,
  listTestimonials,
} from "@/server/services/catalog";
import { MockScreenshot, ProductCard } from "@/components/store/ProductCard";
import { Badge, Button, RatingStars } from "@/components/ui";
import { faNum } from "@/lib/format";

export const dynamic = "force-dynamic";

const LOGOS = [
  "Northgate Foods",
  "Helix Components",
  "Kobayashi Precision",
  "Vantage Distribution",
  "Baltic Trade",
  "Delgado Retail",
];

const VALUE_PROPS = [
  { icon: "🏢", title: "یک لایه داده پایه", body: "هر ماژول مشتریان، اقلام و جدول حساب‌ها را به اشتراک می‌گذارد. دیگر هیچ‌وقت مغایرت‌گیری دستی لازم نیست." },
  { icon: "💾", title: "زیرساخت خودتان", body: "روی SQL Server یا PostgreSQL درون‌سازمانی یا در ابر خودتان اجرا کنید. داده شما هرگز از کنترل شما خارج نمی‌شود." },
  { icon: "🚀", title: "انتشار هفتگی", body: "انتشارهای فرعی هر دو هفته، انتشارهای اصلی هر فصل، همراه با برنامه‌ریز مهاجرت که ابتدا اعتبارسنجی می‌کند." },
  { icon: "🛠️", title: "مهندسان پاسخ می‌دهند", body: "تیکت‌های پشتیبانی go to the engineers who built the module. 4-hour first response on multi-user plans." },
];

export default async function HomePage() {
  await ensureSeeded();
  const [settings, categories, featured, testimonials, faqs, latest] = await Promise.all([
    getSettings(),
    listCategories(),
    listProducts({ page: 1, pageSize: 4, sortBy: "popular", featured: true }),
    listTestimonials(),
    listFaqs(),
    listProducts({ page: 1, pageSize: 3, sortBy: "newest" }),
  ]);

  return (
    <>
      {settings.announcement && (
        <div className="bg-gradient-to-r from-indigo-600 to-violet-600 px-4 py-2 text-center text-xs font-medium text-white sm:text-sm">
          {settings.announcement}
        </div>
      )}

      {/* Hero ---------------------------------------------------------- */}
      <section className="relative overflow-hidden border-b border-slate-200 bg-white">
        <div
          className="pointer-events-none absolute inset-0 opacity-70"
          style={{
            background:
              "radial-gradient(1000px 500px at 15% -10%, #e0e7ff 0%, transparent 60%), radial-gradient(800px 400px at 90% 10%, #f5d0fe33 0%, transparent 55%)",
          }}
        />
        <div className="relative mx-auto grid max-w-7xl items-center gap-12 px-4 py-16 sm:px-6 lg:grid-cols-2 lg:px-8 lg:py-24">
          <div>
            <Badge tone="indigo" className="mb-5">
              نسخه ۲۰۲۵٫۲ · بیش از ۴٬۲۰۰ شرکت از نورث‌ویند استفاده می‌کنند
            </Badge>
            <h1 className="text-4xl font-black leading-[1.05] tracking-tight text-slate-900 sm:text-5xl lg:text-6xl">
              {settings.heroHeadline}
            </h1>
            <p className="mt-5 max-w-xl text-lg leading-relaxed text-slate-600">{settings.heroSubheading}</p>
            <div className="mt-8 flex flex-wrap items-center gap-3">
              <Link href="/catalog">
                <Button size="lg">مشاهده فهرست محصولات</Button>
              </Link>
              <Link href="/contact?topic=Sales">
                <Button size="lg" variant="outline">رزرو دموی راهنما</Button>
              </Link>
            </div>
            <dl className="mt-10 grid max-w-lg grid-cols-3 gap-6">
              {[
                { label: "محصول در مجموعه", value: "۱۰" },
                { label: "میانگین زمان بستن حساب", value: "۳ روز" },
                { label: "زمان پاسخ پشتیبانی", value: "< ۴ ساعت" },
              ].map((stat) => (
                <div key={stat.label}>
                  <dt className="text-xs font-semibold uppercase tracking-wide text-slate-500">{stat.label}</dt>
                  <dd className="mt-1 text-2xl font-bold tracking-tight text-slate-900">{stat.value}</dd>
                </div>
              ))}
            </dl>
          </div>
          <div className="relative">
            <div className="absolute -inset-4 rounded-3xl bg-gradient-to-br from-indigo-200/60 to-violet-200/40 blur-2xl" />
            <div className="relative space-y-4 rounded-2xl border border-slate-200 bg-white p-4 shadow-2xl shadow-indigo-100/60">
              <MockScreenshot label="هسته ERP — داشبورد مدیریت" accent="#4f46e5" />
              <div className="grid grid-cols-2 gap-4">
                <MockScreenshot label="مالی — چک‌لیست بستن دوره" accent="#0f766e" compact />
                <MockScreenshot label="انبار — نقشه انبار" accent="#b45309" compact />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Logos --------------------------------------------------------- */}
      <section className="border-b border-slate-200 bg-slate-50 py-8">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <p className="text-center text-xs font-semibold uppercase tracking-widest text-slate-400">
            مورد اعتماد تولیدکنندگان، پخش‌کنندگان و خرده‌فروشان در ۳۸ کشور
          </p>
          <div className="mt-5 flex flex-wrap items-center justify-center gap-x-10 gap-y-4">
            {LOGOS.map((logo) => (
              <span key={logo} className="text-base font-bold tracking-tight text-slate-400">
                {logo}
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* دسته‌بندی‌ها ---------------------------------------------------- */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <h2 className="text-2xl font-bold tracking-tight text-slate-900">
              مجموعه خود را ماژول به ماژول بسازید
            </h2>
            <p className="mt-1.5 text-slate-600">
              با یک محصول شروع کنید و هر زمان لازم شد اضافه کنید. همه‌چیز به‌صورت بومی یکپارچه می‌شود.
            </p>
          </div>
          <Link href="/catalog" className="text-sm font-semibold text-indigo-600 hover:text-indigo-500">
            مشاهده همه محصولات ←
          </Link>
        </div>
        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
          {categories.map((category) => (
            <Link
              key={category.id}
              href={`/catalog?category=${category.slug}`}
              className="group rounded-xl border border-slate-200 bg-white p-5 transition hover:-translate-y-0.5 hover:border-indigo-300 hover:shadow-lg hover:shadow-indigo-100/60"
            >
              <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-slate-50 text-xl ring-1 ring-inset ring-slate-200 transition group-hover:bg-indigo-50">
                {category.icon === "layers"
                  ? "🧱"
                  : category.icon === "calculator"
                    ? "🧮"
                    : category.icon === "boxes"
                      ? "📦"
                      : category.icon === "monitor"
                        ? "🖥️"
                        : "🧩"}
              </span>
              <h3 className="mt-4 text-sm font-semibold text-slate-900">{category.name}</h3>
              <p className="mt-1 line-clamp-2 text-xs leading-relaxed text-slate-500">{category.description}</p>
              <p className="mt-3 text-xs font-semibold text-indigo-600">{faNum(category.productCount ?? 0)} محصول</p>
            </Link>
          ))}
        </div>
      </section>

      {/* ویژه ------------------------------------------------------ */}
      <section className="border-y border-slate-200 bg-white py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <h2 className="text-2xl font-bold tracking-tight text-slate-900">محبوب‌ترین‌های این فصل</h2>
              <p className="mt-1.5 text-slate-600">
                محصولاتی که مشتریان ما ابتدا نصب می‌کنند — بر اساس نصب‌های فعال.
              </p>
            </div>
            <Link href="/catalog?sortBy=popular" className="text-sm font-semibold text-indigo-600 hover:text-indigo-500">
              مشاهده رتبه‌بندی ←
            </Link>
          </div>
          <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {featured.items.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </section>

      {/* Value props --------------------------------------------------- */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <h2 className="text-center text-2xl font-bold tracking-tight text-slate-900">
          چرا تیم‌ها یک دهه می‌مانند
        </h2>
        <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {VALUE_PROPS.map((prop) => (
            <div key={prop.title} className="rounded-xl border border-slate-200 bg-white p-6">
              <span className="text-2xl">{prop.icon}</span>
              <h3 className="mt-3 text-sm font-semibold text-slate-900">{prop.title}</h3>
              <p className="mt-1.5 text-sm leading-relaxed text-slate-500">{prop.body}</p>
            </div>
          ))}
        </div>
      </section>

      {/* New arrivals -------------------------------------------------- */}
      <section className="border-y border-slate-200 bg-white py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <h2 className="text-2xl font-bold tracking-tight text-slate-900">تازه به‌روزرسانی‌شده</h2>
          <p className="mt-1.5 text-slate-600">انتشارهای تازه با جدیدترین قابلیت‌ها.</p>
          <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {latest.items.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials -------------------------------------------------- */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <h2 className="text-center text-2xl font-bold tracking-tight text-slate-900">
          نظر مشتریان پس از راه‌اندازی
        </h2>
        <div className="mt-10 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {testimonials.slice(0, 6).map((testimonial) => (
            <figure key={testimonial.id} className="flex flex-col rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
              <RatingStars value={testimonial.rating} size={16} />
              <blockquote className="mt-4 flex-1 text-sm leading-relaxed text-slate-700">
                “{testimonial.quote}”
              </blockquote>
              <figcaption className="mt-5 flex items-center gap-3 border-t border-slate-100 pt-4">
                <span className="flex h-9 w-9 items-center justify-center rounded-full bg-gradient-to-br from-indigo-500 to-violet-500 text-xs font-bold text-white">
                  {testimonial.authorName
                    .split(" ")
                    .map((p) => p[0])
                    .join("")}
                </span>
                <div>
                  <p className="text-sm font-semibold text-slate-900">{testimonial.authorName}</p>
                  <p className="text-xs text-slate-500">
                    {testimonial.authorRole}, {testimonial.company}
                  </p>
                </div>
              </figcaption>
            </figure>
          ))}
        </div>
      </section>

      {/* FAQ ----------------------------------------------------------- */}
      <section className="border-t border-slate-200 bg-white py-16">
        <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
          <h2 className="text-center text-2xl font-bold tracking-tight text-slate-900">
            پرسش‌های پرتکرار
          </h2>
          <div className="mt-8 divide-y divide-slate-200 overflow-hidden rounded-xl border border-slate-200">
            {faqs.map((faq) => (
              <details key={faq.id} className="group bg-white px-5 py-4 open:bg-slate-50/60">
                <summary className="flex cursor-pointer items-center justify-between gap-4 text-sm font-semibold text-slate-900 marker:content-none">
                  {faq.question}
                  <span className="text-slate-400 transition group-open:rotate-45">＋</span>
                </summary>
                <p className="mt-3 text-sm leading-relaxed text-slate-600">{faq.answer}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      {/* CTA ----------------------------------------------------------- */}
      <section className="bg-gradient-to-br from-indigo-600 to-violet-700 py-16">
        <div className="mx-auto flex max-w-5xl flex-col items-center gap-6 px-4 text-center sm:px-6">
          <h2 className="text-3xl font-bold tracking-tight text-white">
            هر محصول را {faNum(settings.trialDays)} روز رایگان امتحان کنید
          </h2>
          <p className="max-w-2xl text-indigo-100">
            نسخه آزمایشی کامل، بدون کارت بانکی، و داده‌های شما هنگام خرید لایسنس منتقل می‌شود. در انتخاب تردید دارید؟ مهندسان ما در یک تماس ۳۰ دقیقه‌ای نیازهای شما را بررسی می‌کنند.
          </p>
          <div className="flex flex-wrap justify-center gap-3">
            <Link href="/catalog">
              <Button size="lg" variant="secondary">
                شروع نسخه آزمایشی
              </Button>
            </Link>
            <Link href="/contact">
              <Button size="lg" variant="outline" className="border-white/40 bg-white/10 text-white hover:bg-white/20">
                گفتگو با تیم فروش
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}
