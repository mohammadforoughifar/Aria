"use client";

import Link from "next/link";
import { useState } from "react";
import {
  Badge,
  Button,
  Card,
  EmptyState,
  Field,
  Input,
  Select,
  SkeletonRows,
  Tabs,
  Textarea,
  statusTone,
  useToast,
} from "@/components/ui";
import { api, useApi, useAuth } from "@/lib/client/api";
import { timeAgo, faNum } from "@/lib/format";
import type { FaqDto, ProductListItemDto, TicketDto } from "@/shared/contracts";

export default function SupportPage() {
  const { user, status } = useAuth();
  const { push } = useToast();
  const { data: faqData, loading: faqLoading } = useApi<{ items: FaqDto[] }>("/api/content/faqs");
  const { data: productData } = useApi<{ items: ProductListItemDto[] }>("/api/products?pageSize=50");
  const tickets = useApi<{ items: TicketDto[] }>(user ? "/api/tickets?pageSize=10" : null, [status]);

  const [tab, setTab] = useState("faq");
  const [form, setForm] = useState({
    subject: "",
    category: "Technical",
    priority: "Normal",
    productId: "",
    environment: "",
    message: "",
  });
  const [saving, setSaving] = useState(false);

  async function submitTicket() {
    setSaving(true);
    try {
      await api.post("/api/tickets", {
        productId: form.productId || null,
        subject: form.subject,
        category: form.category,
        priority: form.priority,
        environment: form.environment || null,
        message: form.message,
      });
      push({
        tone: "success",
        title: "تیکت ثبت شد",
        description: "مهندسان ما در روزهای کاری تا ۴ ساعت پاسخ می‌دهند.",
      });
      setForm({ ...form, subject: "", message: "", environment: "" });
      await tickets.refresh();
      setTab("tickets");
    } catch (error) {
      push({
        tone: "error",
        title: "ثبت تیکت ناموفق بود",
        description: error instanceof Error ? error.message : undefined,
      });
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
      <Badge tone="blue">مرکز پشتیبانی</Badge>
      <h1 className="mt-3 text-3xl font-bold tracking-tight text-slate-900">چطور می‌توانیم کمک کنیم؟</h1>
      <p className="mt-1.5 max-w-2xl text-slate-600">
        دانشنامه را جستجو کنید، تیکت ثبت کنید یا با شماره ۵۵۵-۰۱۴۲-۸۸۸ تماس بگیرید. پشتیبانی توسط مهندسانی اداره می‌شود که ماژول‌ها را می‌سازند.
      </p>

      <div className="mt-8">
        <Tabs
          tabs={[
            { id: "faq", label: "دانشنامه" },
            { id: "tickets", label: "تیکت‌های من", badge: tickets.data?.items.length },
            { id: "new", label: "ثبت تیکت" },
          ]}
          active={tab}
          onChange={setTab}
        />
      </div>

      {tab === "faq" && (
        <div className="mt-6 grid gap-6 lg:grid-cols-[1fr_320px]">
          <div className="space-y-3">
            {faqLoading ? (
              <SkeletonRows rows={5} cols={2} />
            ) : faqData?.items.length ? (
              faqData.items.map((faq) => (
                <details key={faq.id} className="group rounded-xl border border-slate-200 bg-white px-5 py-4">
                  <summary className="flex cursor-pointer items-center justify-between gap-4 text-sm font-semibold text-slate-900">
                    {faq.question}
                    <span className="text-slate-400 transition group-open:rotate-45">＋</span>
                  </summary>
                  <p className="mt-3 text-sm leading-relaxed text-slate-600">{faq.answer}</p>
                </details>
              ))
            ) : (
              <EmptyState icon="folder" title="هنوز مقاله‌ای نیست" description="به‌زودی بازگردید." />
            )}
          </div>
          <div className="space-y-4">
            <Card>
              <h3 className="text-sm font-semibold text-slate-900">زمان پاسخ‌گویی</h3>
              <ul className="mt-3 space-y-2 text-sm text-slate-600">
                <li className="flex justify-between"><span>بحرانی</span><span className="font-semibold">۱ ساعت</span></li>
                <li className="flex justify-between"><span>بالا</span><span className="font-semibold">۴ ساعت</span></li>
                <li className="flex justify-between"><span>عادی</span><span className="font-semibold">۱ روز کاری</span></li>
                <li className="flex justify-between"><span>کم</span><span className="font-semibold">۳ روز کاری</span></li>
              </ul>
            </Card>
            <Card>
              <h3 className="text-sm font-semibold text-slate-900">خدمات خودکار</h3>
              <div className="mt-3 space-y-2">
                <Link href="/dashboard/downloads" className="block text-sm text-indigo-600 hover:text-indigo-500">
                  دانلود نصب‌کننده‌ها و راهنماها ←
                </Link>
                <Link href="/dashboard/licenses" className="block text-sm text-indigo-600 hover:text-indigo-500">
                  مدیریت کلیدهای لایسنس و فعال‌سازی‌ها ←
                </Link>
                <Link href="/api-docs" className="block text-sm text-indigo-600 hover:text-indigo-500">
                  مستندات REST API ←
                </Link>
              </div>
            </Card>
          </div>
        </div>
      )}

      {tab === "tickets" && (
        <div className="mt-6">
          {status === "anonymous" ? (
            <EmptyState
              icon="ticket"
              title="برای مشاهده تیکت‌ها وارد شوید"
              description="تاریخچه پشتیبانی شما به حساب مشتری متصل است."
              action={
                <Link href="/login?redirect=/support">
                  <Button>ورود</Button>
                </Link>
              }
            />
          ) : tickets.loading ? (
            <SkeletonRows rows={4} cols={4} />
          ) : tickets.data?.items.length ? (
            <div className="overflow-hidden rounded-xl border border-slate-200 bg-white">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-slate-50 text-start text-xs font-semibold uppercase tracking-wide text-slate-500">
                    <tr>
                      <th className="px-5 py-3">کد پیگیری</th>
                      <th className="px-5 py-3">موضوع</th>
                      <th className="px-5 py-3">وضعیت</th>
                      <th className="px-5 py-3">به‌روزرسانی</th>
                      <th className="px-5 py-3" />
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {tickets.data.items.map((ticket) => (
                      <tr key={ticket.id} className="hover:bg-slate-50/60">
                        <td className="px-5 py-3 font-mono text-xs text-slate-500">{ticket.reference}</td>
                        <td className="px-5 py-3">
                          <Link href={`/dashboard/tickets/${ticket.id}`} className="font-medium text-slate-900 hover:text-indigo-700">
                            {ticket.subject}
                          </Link>
                          <span className="block text-xs text-slate-500">
                            {ticket.productName ?? "General"} · {ticket.category}
                          </span>
                        </td>
                        <td className="px-5 py-3">
                          <Badge tone={statusTone(ticket.status)}>{ticket.status}</Badge>
                        </td>
                        <td className="px-5 py-3 text-xs text-slate-500">{timeAgo(ticket.updatedAt)}</td>
                        <td className="px-5 py-3 text-end">
                          <Link href={`/dashboard/tickets/${ticket.id}`}>
                            <Button variant="outline" size="sm">مشاهده</Button>
                          </Link>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          ) : (
            <EmptyState
              icon="ticket"
              title="تیکت پشتیبانی وجود ندارد"
              description="چیزی نیاز به بررسی ندارد. اگر مسئله‌ای پیش آمد، تیکت ثبت کنید تا رسیدگی کنیم."
              action={<Button onClick={() => setTab("new")}>ثبت تیکت</Button>}
            />
          )}
        </div>
      )}

      {tab === "new" && (
        <div className="mt-6 max-w-3xl">
          {status === "anonymous" ? (
            <EmptyState
              icon="key"
              title="ورود to open a ticket"
              description="تیکت‌ها باید به حساب مشتری متصل باشند تا لایسنس‌های شما را ببینیم."
              action={
                <Link href="/login?redirect=/support">
                  <Button>ورود</Button>
                </Link>
              }
            />
          ) : (
            <Card>
              <h2 className="text-base font-semibold text-slate-900">تیکت پشتیبانی جدید</h2>
              <div className="mt-4 grid gap-4 sm:grid-cols-2">
                <Field label="موضوع" required className="sm:col-span-2">
                  <Input
                    value={form.subject}
                    onChange={(e) => setForm({ ...form, subject: e.target.value })}
                    placeholder="خلاصه کوتاه مشکل"
                  />
                </Field>
                <Field label="محصول">
                  <Select value={form.productId} onChange={(e) => setForm({ ...form, productId: e.target.value })}>
                    <option value="">عمومی / مربوط به محصول خاصی نیست</option>
                    {productData?.items.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.name}
                      </option>
                    ))}
                  </Select>
                </Field>
                <Field label="دسته">
                  <Select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}>
                    {["Technical", "Billing", "Licensing", "Feature Request", "General"].map((c) => (
                      <option key={c}>{c}</option>
                    ))}
                  </Select>
                </Field>
                <Field label="اولویت">
                  <Select value={form.priority} onChange={(e) => setForm({ ...form, priority: e.target.value })}>
                    {["Low", "Normal", "High", "Critical"].map((p) => (
                      <option key={p}>{p}</option>
                    ))}
                  </Select>
                </Field>
                <Field label="محیط اجرا" hint="سیستم عامل، نسخه محصول، پایگاه داده">
                  <Input
                    value={form.environment}
                    onChange={(e) => setForm({ ...form, environment: e.target.value })}
                    placeholder="ویندوز ۱۱ · هسته ERP 2025.2.1 · SQL Server 2022"
                  />
                </Field>
                <Field label="توضیح مشکل" required className="sm:col-span-2">
                  <Textarea
                    value={form.message}
                    onChange={(e) => setForm({ ...form, message: e.target.value })}
                    rows={6}
                    placeholder="چه اتفاقی افتاد، چه انتظاری داشتید و مراحل بازتولید آن."
                  />
                </Field>
              </div>
              <div className="mt-5 flex justify-end gap-2">
                <Button variant="ghost" onClick={() => setTab("faq")}>انصراف</Button>
                <Button
                  loading={saving}
                  disabled={form.subject.length < 5 || form.message.length < 10}
                  onClick={() => void submitTicket()}
                >ثبت تیکت</Button>
              </div>
            </Card>
          )}
        </div>
      )}
    </div>
  );
}
