import { ensureSeeded } from "@/server/bootstrap";
import { handleApiRequest } from "@/server/router";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

interface RouteContext {
  params: Promise<{ path?: string[] }>;
}

async function handle(req: Request, context: RouteContext): Promise<Response> {
  const { path } = await context.params;
  await ensureSeeded();
  return handleApiRequest(req, path ?? []);
}

export const GET = handle;
export const POST = handle;
export const PATCH = handle;
export const PUT = handle;
export const DELETE = handle;
export const OPTIONS = handle;
