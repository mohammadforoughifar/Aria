import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { ToastProvider } from "@/components/ui";
import { AuthProvider, CartProvider } from "@/lib/client/api";

export const metadata: Metadata = {
  title: "نورث‌ویند — مجموعه نرم‌افزار کسب‌وکار",
  description:
    "ماژول‌های یکپارچه ERP، برنامه‌های دسکتاپ و افزونه‌ها برای کسب‌وکارهای متوسط. با لایسنس دلخواه شما، روی زیرساخت خودتان.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="fa" dir="rtl">
      <head>
        <link
          rel="stylesheet"
          href="https://cdn.jsdelivr.net/npm/vazirmatn@33.0.3/Vazirmatn-font-face.css"
        />
      </head>
      <body className="min-h-screen bg-slate-50 text-slate-900 antialiased">
        <ToastProvider>
          <AuthProvider>
            <CartProvider>{children}</CartProvider>
          </AuthProvider>
        </ToastProvider>
      </body>
    </html>
  );
}
