"use client";

import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useState } from "react";
import { Button, Card, Field, Input, useToast } from "@/components/ui";
import { useAuth } from "@/lib/client/api";

function RegisterInner() {
  const router = useRouter();
  const params = useSearchParams();
  const { register } = useAuth();
  const { push } = useToast();
  const [form, setForm] = useState({
    fullName: "",
    email: "",
    company: "",
    country: "United States",
    password: "",
    confirm: "",
  });
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const redirect = params.get("redirect") ?? "/dashboard";

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (form.password !== form.confirm) {
      setError("رمزهای عبور مطابقت ندارند.");
      return;
    }
    setLoading(true);
    setError(null);
    try {
      await register({
        fullName: form.fullName,
        email: form.email,
        password: form.password,
        company: form.company || undefined,
        country: form.country,
      });
      push({ tone: "success", title: "حساب کاربری ایجاد شد", description: "به نورث‌ویند خوش آمدید." });
      router.push(redirect);
    } catch (err) {
      setError(err instanceof Error ? err.message : "ثبت‌نام ناموفق بود");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-slate-50 px-4 py-12 sm:px-6">
      <div className="w-full max-w-lg">
        <Link href="/" className="mb-6 inline-flex items-center gap-2.5">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-600 to-violet-500 text-sm font-black text-white">
            NW
          </span>
          <span className="text-base font-bold text-slate-900">نورث‌ویند</span>
        </Link>
        <Card className="p-7">
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">ایجاد حساب کاربری</h1>
          <p className="mt-1.5 text-sm text-slate-600">
            قبلاً ثبت‌نام کرده‌اید؟{" "}
            <Link href={`/login?redirect=${redirect}`} className="font-semibold text-indigo-600 hover:text-indigo-500">
              ورود
            </Link>
          </p>

          <form onSubmit={submit} className="mt-6 space-y-4">
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="نام و نام خانوادگی" required>
                <Input value={form.fullName} onChange={(e) => setForm({ ...form, fullName: e.target.value })} />
              </Field>
              <Field label="ایمیل سازمانی" required>
                <Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
              </Field>
              <Field label="شرکت">
                <Input value={form.company} onChange={(e) => setForm({ ...form, company: e.target.value })} />
              </Field>
              <Field label="کشور">
                <Input value={form.country} onChange={(e) => setForm({ ...form, country: e.target.value })} />
              </Field>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="رمز عبور" required hint="حداقل ۸ کاراکتر">
                <Input
                  type="password"
                  value={form.password}
                  onChange={(e) => setForm({ ...form, password: e.target.value })}
                  autoComplete="new-password"
                />
              </Field>
              <Field label="تکرار رمز عبور" required>
                <Input
                  type="password"
                  value={form.confirm}
                  onChange={(e) => setForm({ ...form, confirm: e.target.value })}
                  autoComplete="new-password"
                />
              </Field>
            </div>
            {error && (
              <p className="rounded-lg border border-rose-200 bg-rose-50 px-3 py-2 text-sm text-rose-700">{error}</p>
            )}
            <Button type="submit" className="w-full" size="lg" loading={loading}>
              ایجاد حساب کاربری
            </Button>
          </form>

          <p className="mt-5 text-xs leading-relaxed text-slate-500">
            با ایجاد حساب،{" "}
            <Link href="/legal/terms" className="font-medium text-indigo-600">
              شرایط استفاده
            </Link>{" "}
            and{" "}
            <Link href="/legal/privacy" className="font-medium text-indigo-600">
              سیاست حریم خصوصی
            </Link>
            .
          </p>
        </Card>
      </div>
    </div>
  );
}

export default function RegisterPage() {
  return (
    <Suspense fallback={<div className="flex min-h-screen items-center justify-center">در حال بارگذاری…</div>}>
      <RegisterInner />
    </Suspense>
  );
}
