"use client";

import Link from "next/link";
import { useState } from "react";
import {
  Badge,
  Button,
  Card,
  CopyButton,
  EmptyState,
  Input,
  Modal,
  Select,
  SkeletonRows,
  StatCard,
  Tabs,
  statusTone,
  useToast,
} from "@/components/ui";
import { api, useApi } from "@/lib/client/api";
import { daysUntil, formatDate, faNum } from "@/lib/format";
import type { LicenseDto } from "@/shared/contracts";

export default function LicensesPage() {
  const { push } = useToast();
  const [status, setStatus] = useState("all");
  const [search, setSearch] = useState("");
  const [busy, setBusy] = useState<string | null>(null);
  const [activate, setActivate] = useState<LicenseDto | null>(null);
  const [machine, setMachine] = useState("WORKSTATION-01");

  const query = new URLSearchParams({ page: "1", pageSize: "50" });
  if (status !== "all") query.set("status", status);
  if (search) query.set("search", search);
  const { data, loading, setData } = useApi<{ items: LicenseDto[] }>(`/api/licenses?${query.toString()}`);

  const licenses = data?.items ?? [];

  async function act(license: LicenseDto, action: "extend" | "activate", payload: Record<string, unknown> = {}) {
    setBusy(license.id);
    try {
      const { data: updated } = await api.patch<LicenseDto>(`/api/licenses/${license.id}`, { action, ...payload });
      setData((prev) => (prev ? { items: prev.items.map((l) => (l.id === updated.id ? updated : l)) } : prev));
      push({
        tone: "success",
        title: action === "extend" ? "لایسنس تمدید شد" : "کاربر فعال شد",
        description:
          action === "extend" ? "۱۲ ماه اضافه شد." : `${updated.activationsUsed} of ${updated.seats} seats in use.`,
      });
    } catch (error) {
      push({
        tone: "error",
        title: "عملیات ناموفق بود",
        description: error instanceof Error ? error.message : undefined,
      });
    } finally {
      setBusy(null);
    }
  }

  const active = licenses.filter((l) => l.status === "Active");
  const expiring = active.filter((l) => (daysUntil(l.expiresAt) ?? 999) < 45);

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-bold tracking-tight text-slate-900">لایسنس‌های من</h2>
        <p className="mt-1 text-sm text-slate-600">
          کلید، تعداد کاربر و تاریخ انقضا برای همه محصولات شما. لایسنس‌های دائمی هرگز منقضی نمی‌شوند.
        </p>
      </div>

      <div className="grid gap-4 sm:grid-cols-3">
        <StatCard label="فعال" value={faNum(active.length)} icon="🔑" tone="green" />
        <StatCard label="انقضا در ۴۵ روز آینده" value={faNum(expiring.length)} icon="⏳" tone="amber" />
        <StatCard
          label="کاربران فعال"
          value={faNum(active.reduce((s, l) => s + l.activationsUsed, 0))}
          icon="👥"
          tone="blue"
        />
      </div>

      <div className="flex flex-wrap items-center gap-3">
        <Tabs
          tabs={[
            { id: "all", label: "همه" },
            { id: "Active", label: "فعال" },
            { id: "Expired", label: "منقضی" },
            { id: "Revoked", label: "ابطال‌شده" },
          ]}
          active={status}
          onChange={setStatus}
        />
        <Input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="جستجوی کلید یا محصول…"
          className="max-w-xs"
        />
      </div>

      {loading ? (
        <SkeletonRows rows={5} cols={5} />
      ) : licenses.length === 0 ? (
        <EmptyState
          icon="key"
          title="لایسنسی پیدا نشد"
          description="پس از خرید هر محصول، لایسنس آن به‌طور خودکار در اینجا نمایش داده می‌شود."
          action={
            <Link href="/catalog">
              <Button>مشاهده محصولات</Button>
            </Link>
          }
        />
      ) : (
        <Card padding={false}>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 text-start text-xs font-semibold uppercase tracking-wide text-slate-500">
                <tr>
                  <th className="px-5 py-3">محصول</th>
                  <th className="px-5 py-3">کلید لایسنس</th>
                  <th className="px-5 py-3">کاربران</th>
                  <th className="px-5 py-3">تاریخ انقضا</th>
                  <th className="px-5 py-3">وضعیت</th>
                  <th className="px-5 py-3 text-end">عملیات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {licenses.map((license) => {
                  const remaining = daysUntil(license.expiresAt);
                  return (
                    <tr key={license.id} className="hover:bg-slate-50/60">
                      <td className="px-5 py-3">
                        <Link
                          href={`/products/${license.productSlug}`}
                          className="font-medium text-slate-900 hover:text-indigo-700"
                        >
                          {license.productName}
                        </Link>
                        <span className="block text-xs text-slate-500">{license.planName ?? "—"}</span>
                      </td>
                      <td className="px-5 py-3">
                        <div className="flex items-center gap-2">
                          <code className="rounded bg-slate-100 px-2 py-1 text-[11px] text-slate-700">
                            {license.licenseKey}
                          </code>
                          <CopyButton value={license.licenseKey} label="" />
                        </div>
                      </td>
                      <td className="px-5 py-3 text-slate-600">
                        {faNum(license.activationsUsed)} / {faNum(license.seats)}
                      </td>
                      <td className="px-5 py-3 text-slate-600">
                        {license.expiresAt ? (
                          <span className={remaining !== null && remaining < 45 ? "font-medium text-amber-600" : ""}>
                            {formatDate(license.expiresAt)}
                            {remaining !== null && ` (${faNum(remaining)} روز)`}
                          </span>
                        ) : (
                          "Perpetual"
                        )}
                      </td>
                      <td className="px-5 py-3">
                        <Badge tone={statusTone(license.status)}>{license.status}</Badge>
                      </td>
                      <td className="px-5 py-3">
                        <div className="flex justify-end gap-1.5">
                          {license.status !== "Revoked" && license.activationsUsed < license.seats && (
                            <Button variant="outline" size="sm" loading={busy === license.id} onClick={() => setActivate(license)}>فعال‌سازی</Button>
                          )}
                          {license.expiresAt && license.status !== "Revoked" && (
                            <Button
                              variant="outline"
                              size="sm"
                              loading={busy === license.id}
                              onClick={() => void act(license, "extend", { days: 365 })}
                            >تمدید</Button>
                          )}
                          <Link href={`/products/${license.productSlug}`}>
                            <Button variant="ghost" size="sm">خرید کاربر بیشتر</Button>
                          </Link>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </Card>
      )}

      <Modal
        open={Boolean(activate)}
        onClose={() => setActivate(null)}
        title="فعال‌سازی یک کاربر"
        description="برای نصب یک نام انتخاب کنید تا بعداً آن را بشناسید."
        footer={
          <>
            <Button variant="ghost" onClick={() => setActivate(null)}>انصراف</Button>
            <Button
              onClick={() => {
                if (activate) void act(activate, "activate", { machineName: machine });
                setActivate(null);
              }}
            >
              فعال‌سازی کاربر
            </Button>
          </>
        }
      >
        <div className="space-y-4">
          <p className="text-sm text-slate-600">
            {activate?.productName} · {activate?.activationsUsed} of {activate?.seats} seats in use.
          </p>
          <Select value={machine} onChange={(e) => setMachine(e.target.value)}>
            {["WORKSTATION-01", "WORKSTATION-02", "SERVER-ERP", "LAPTOP-FIELD", "WAREHOUSE-SCANNER"].map((m) => (
              <option key={m}>{m}</option>
            ))}
          </Select>
        </div>
      </Modal>
    </div>
  );
}
