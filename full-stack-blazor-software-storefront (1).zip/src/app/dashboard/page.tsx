"use client";

import Link from "next/link";
import {
  Button,
  Card,
  EmptyState,
  SectionTitle,
  SkeletonRows,
  SkeletonStats,
  StatCard,
  statusTone,
} from "@/components/ui";
import { useApi } from "@/lib/client/api";
import { formatDate, formatMoney, faNum } from "@/lib/format";
import type { CustomerOverviewDto } from "@/shared/contracts";

export default function CustomerDashboardPage() {
  const { data, loading, error } = useApi<CustomerOverviewDto>("/api/reports/customer");

  if (loading) {
    return (
      <div className="space-y-6">
        <SkeletonStats />
        <SkeletonRows rows={5} />
      </div>
    );
  }

  if (error || !data) {
    return (
      <EmptyState
        title="داشبورد شما بارگذاری نشد"
        description={error ?? "صفحه را دوباره بارگذاری کنید و اگر تکرار شد با پشتیبانی تماس بگیرید."}
      />
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-bold tracking-tight text-slate-900">خوش آمدید</h2>
        <p className="mt-1 text-sm text-slate-600">
          وضعیت لایسنس‌ها، سفارش‌ها و درخواست‌های پشتیبانی شما.
        </p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard
          label="لایسنس فعال"
          value={faNum(data.activeLicenses)}
          icon="🔑"
          hint={`${faNum(data.expiringLicenses)} مورد در آستانه انقضا`}
          tone="indigo"
        />
        <StatCard
          label="سفارش ثبت‌شده"
          value={faNum(data.orderCount)}
          icon="🧾"
          hint={`${faNum(data.availableDownloads)} فایل قابل دانلود`}
          tone="blue"
        />
        <StatCard
          label="مجموع خرید"
          value={formatMoney(data.totalSpentCents)}
          icon="💳"
          hint="با احتساب مالیات"
          tone="green"
        />
        <StatCard
          label="تیکت باز"
          value={faNum(data.openTickets)}
          icon="🎫"
          hint={data.outstandingInvoicesCents ? `${formatMoney(data.outstandingInvoicesCents)} مانده` : "بدهی ندارید"}
          tone={data.openTickets ? "amber" : "slate"}
        />
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2" padding={false}>
          <div className="flex items-center justify-between gap-3 border-b border-slate-200 px-5 py-4">
            <SectionTitle title="سفارش‌های اخیر" description="پنج خرید آخر شما" />
            <Link href="/dashboard/orders">
              <Button variant="outline" size="sm">مشاهده همه</Button>
            </Link>
          </div>
          {data.recentOrders.length === 0 ? (
            <div className="p-5">
              <EmptyState
                icon="receipt"
                title="هنوز سفارشی ثبت نشده"
                description="پس از خرید لایسنس هر محصول، همراه با فاکتور و کلید آن در اینجا نمایش داده می‌شود."
                action={
                  <Link href="/catalog">
                    <Button>مشاهده محصولات</Button>
                  </Link>
                }
              />
            </div>
          ) : (
            <ul className="divide-y divide-slate-100">
              {data.recentOrders.map((order) => (
                <li key={order.id} className="flex flex-wrap items-center gap-3 px-5 py-4">
                  <div className="min-w-40 flex-1">
                    <p className="text-sm font-semibold text-slate-900">{order.orderNumber}</p>
                    <p className="text-xs text-slate-500">
                      {formatDate(order.placedAt)} · {faNum(order.items.length)} محصول
                    </p>
                  </div>
                  <span className="inline-flex items-center rounded-full bg-slate-50 px-2.5 py-0.5 text-xs font-semibold text-slate-700 ring-1 ring-inset ring-slate-200">
                    {order.status}
                  </span>
                  <p className="w-24 text-end text-sm font-semibold text-slate-900">
                    {formatMoney(order.totalCents)}
                  </p>
                </li>
              ))}
            </ul>
          )}
        </Card>

        <div className="space-y-6">
          <Card padding={false}>
            <div className="border-b border-slate-200 px-5 py-4">
              <SectionTitle title="لایسنس‌های در آستانه انقضا" description="۴۵ روز آینده" />
            </div>
            {data.licensesExpiringSoon.length === 0 ? (
              <p className="px-5 py-6 text-sm text-slate-500">
                در ۴۵ روز آینده لایسنسی منقضی نمی‌شود. لایسنس‌های دائمی هرگز منقضی نمی‌شوند.
              </p>
            ) : (
              <ul className="divide-y divide-slate-100">
                {data.licensesExpiringSoon.map((license) => (
                  <li key={license.id} className="px-5 py-4">
                    <p className="text-sm font-semibold text-slate-900">{license.productName}</p>
                    <p className="mt-0.5 text-xs text-slate-500">
                      {license.planName} · انقضا {formatDate(license.expiresAt)}
                    </p>
                    <Link href="/dashboard/licenses" className="mt-2 inline-block">
                      <Button variant="outline" size="sm">تمدید</Button>
                    </Link>
                  </li>
                ))}
              </ul>
            )}
          </Card>

          <Card>
            <SectionTitle title="اقدامات سریع" />
            <div className="mt-4 grid gap-2">
              <Link href="/dashboard/downloads">
                <Button variant="outline" className="w-full justify-start">
                  ⬇️ دانلود نصب‌کننده‌ها
                </Button>
              </Link>
              <Link href="/dashboard/tickets">
                <Button variant="outline" className="w-full justify-start">
                  🎫 ثبت تیکت پشتیبانی
                </Button>
              </Link>
              <Link href="/dashboard/invoices">
                <Button variant="outline" className="w-full justify-start">
                  📄 دانلود فاکتور
                </Button>
              </Link>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
