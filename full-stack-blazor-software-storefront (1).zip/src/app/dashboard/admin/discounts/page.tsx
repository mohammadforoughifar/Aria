"use client";

import { useState } from "react";
import { Badge, Button, Card, EmptyState, Field, Input, Modal, SkeletonRows, useToast } from "@/components/ui";
import { api, useApi } from "@/lib/client/api";
import { formatDate, faNum } from "@/lib/format";
import type { DiscountCodeDto } from "@/shared/contracts";

export default function AdminDiscountsPage() {
  const { push } = useToast();
  const discounts = useApi<{ items: DiscountCodeDto[] }>("/api/discount-codes");
  const [editing, setEditing] = useState<DiscountCodeDto | null>(null);
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    code: "",
    description: "",
    percentOff: 10,
    maxRedemptions: 0,
    expiresAt: "",
  });

  function start(discount: DiscountCodeDto | null) {
    setEditing(discount);
    setForm(
      discount
        ? {
            code: discount.code,
            description: discount.description ?? "",
            percentOff: discount.percentOff,
            maxRedemptions: discount.maxRedemptions,
            expiresAt: discount.expiresAt ? discount.expiresAt.slice(0, 10) : "",
          }
        : { code: "", description: "", percentOff: 10, maxRedemptions: 0, expiresAt: "" },
    );
    setOpen(true);
  }

  async function save() {
    setSaving(true);
    try {
      const payload = {
        description: form.description || null,
        percentOff: Number(form.percentOff),
        maxRedemptions: Number(form.maxRedemptions),
        expiresAt: form.expiresAt ? new Date(form.expiresAt).toISOString() : null,
      };
      if (editing) await api.patch(`/api/discount-codes/${editing.id}`, payload);
      else await api.post("/api/discount-codes", { ...payload, code: form.code.toUpperCase() });
      setOpen(false);
      await discounts.refresh();
      push({ tone: "success", title: editing ? "تخفیف به‌روزرسانی شد" : "تخفیف ایجاد شد" });
    } catch (error) {
      push({
        tone: "error",
        title: "ذخیره نشد",
        description: error instanceof Error ? error.message : undefined,
      });
    } finally {
      setSaving(false);
    }
  }

  async function toggle(discount: DiscountCodeDto) {
    discounts.setData((prev) =>
      prev ? { items: prev.items.map((d) => (d.id === discount.id ? { ...d, isActive: !d.isActive } : d)) } : prev,
    );
    try {
      await api.patch(`/api/discount-codes/${discount.id}`, { isActive: !discount.isActive });
    } catch {
      await discounts.refresh();
    }
  }

  async function remove(discount: DiscountCodeDto) {
    discounts.setData((prev) => (prev ? { items: prev.items.filter((d) => d.id !== discount.id) } : prev));
    try {
      await api.delete(`/api/discount-codes/${discount.id}`);
      push({ tone: "success", title: "تخفیف حذف شد" });
    } catch (error) {
      discounts.refresh();
      push({
        tone: "error",
        title: "حذف ناموفق بود",
        description: error instanceof Error ? error.message : undefined,
      });
    }
  }

  const items = discounts.data?.items ?? [];

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900">کدهای تخفیف</h2>
          <p className="mt-1 text-sm text-slate-600">تخفیف‌های درصدی اعمال‌شده در تسویه حساب.</p>
        </div>
        <Button onClick={() => start(null)}>کد جدید</Button>
      </div>

      {discounts.loading ? (
        <SkeletonRows rows={4} cols={5} />
      ) : items.length === 0 ? (
        <EmptyState
          icon="tag"
          title="کد تخفیفی وجود ندارد"
          description="یکی بسازید تا یک کمپین اجرا کنید."
          action={<Button onClick={() => start(null)}>کد جدید</Button>}
        />
      ) : (
        <Card padding={false}>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 text-start text-xs font-semibold uppercase tracking-wide text-slate-500">
                <tr>
                  <th className="px-5 py-3">کد</th>
                  <th className="px-5 py-3">تخفیف</th>
                  <th className="px-5 py-3 text-center">دفعات استفاده</th>
                  <th className="px-5 py-3">تاریخ انقضا</th>
                  <th className="px-5 py-3 text-center">وضعیت</th>
                  <th className="px-5 py-3 text-end">عملیات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {items.map((discount) => (
                  <tr key={discount.id} className="hover:bg-slate-50/60">
                    <td className="px-5 py-3">
                      <code className="rounded bg-slate-100 px-2 py-1 text-xs font-semibold text-slate-800">
                        {discount.code}
                      </code>
                      <p className="mt-1 text-xs text-slate-500">{discount.description}</p>
                    </td>
                    <td className="px-5 py-3 font-semibold text-slate-900">{discount.percentOff}%</td>
                    <td className="px-5 py-3 text-center text-slate-600">
                      {faNum(discount.timesRedeemed)}
                      {discount.maxRedemptions > 0 ? ` / ${faNum(discount.maxRedemptions)}` : ""}
                    </td>
                    <td className="px-5 py-3 text-slate-600">
                      {discount.expiresAt ? formatDate(discount.expiresAt) : "بدون انقضا"}
                    </td>
                    <td className="px-5 py-3 text-center">
                      <Badge tone={discount.isActive ? "green" : "slate"}>
                        {discount.isActive ? "فعال" : "غیرفعال"}
                      </Badge>
                    </td>
                    <td className="px-5 py-3">
                      <div className="flex justify-end gap-1.5">
                        <Button variant="outline" size="sm" onClick={() => start(discount)}>ویرایش</Button>
                        <Button variant="ghost" size="sm" onClick={() => void toggle(discount)}>
                          {discount.isActive ? "غیرفعال" : "فعال"}
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-rose-600 hover:bg-rose-50"
                          onClick={() => void remove(discount)}
                        >حذف</Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}

      <Modal
        open={open}
        onClose={() => setOpen(false)}
        title={editing ? `Edit ${editing.code}` : "New discount code"}
        footer={
          <>
            <Button variant="ghost" onClick={() => setOpen(false)}>انصراف</Button>
            <Button loading={saving} onClick={() => void save()} disabled={!editing && form.code.length < 3}>ذخیره</Button>
          </>
        }
      >
        <div className="grid gap-4 sm:grid-cols-2">
          {!editing && (
            <Field label="کد" required className="sm:col-span-2">
              <Input
                value={form.code}
                onChange={(e) => setForm({ ...form, code: e.target.value.toUpperCase() })}
                placeholder="SPRING20"
              />
            </Field>
          )}
          <Field label="توضیحات" className="sm:col-span-2">
            <Input value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
          </Field>
          <Field label="درصد تخفیف" required hint={`${form.percentOff}%`}>
            <Input
              type="number"
              value={form.percentOff}
              onChange={(e) => setForm({ ...form, percentOff: Number(e.target.value) })}
            />
          </Field>
          <Field label="حداکثر استفاده" hint="۰ = نامحدود">
            <Input
              type="number"
              value={form.maxRedemptions}
              onChange={(e) => setForm({ ...form, maxRedemptions: Number(e.target.value) })}
            />
          </Field>
          <Field label="تاریخ انقضا" className="sm:col-span-2">
            <Input
              type="date"
              value={form.expiresAt}
              onChange={(e) => setForm({ ...form, expiresAt: e.target.value })}
            />
          </Field>
        </div>
      </Modal>
    </div>
  );
}
