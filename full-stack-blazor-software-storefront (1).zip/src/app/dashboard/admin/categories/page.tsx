"use client";

import { useState } from "react";
import { Badge, Button, Card, EmptyState, Field, Input, Modal, SkeletonRows, Textarea, useToast } from "@/components/ui";
import { api, useApi } from "@/lib/client/api";
import { slugify } from "@/lib/format";
import type { CategoryDto } from "@/shared/contracts";

export default function AdminCategoriesPage() {
  const { push } = useToast();
  const categories = useApi<{ items: CategoryDto[] }>("/api/categories?includeInactive=true");
  const [editing, setEditing] = useState<CategoryDto | null>(null);
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    name: "",
    slug: "",
    description: "",
    icon: "package",
    sortOrder: 0,
    isActive: true,
  });

  function start(category: CategoryDto | null) {
    setEditing(category);
    setForm(
      category
        ? {
            name: category.name,
            slug: category.slug,
            description: category.description ?? "",
            icon: category.icon,
            sortOrder: category.sortOrder,
            isActive: category.isActive,
          }
        : {
            name: "",
            slug: "",
            description: "",
            icon: "package",
            sortOrder: (categories.data?.items.length ?? 0) + 1,
            isActive: true,
          },
    );
    setOpen(true);
  }

  async function save() {
    setSaving(true);
    try {
      const payload = {
        name: form.name,
        slug: form.slug || slugify(form.name),
        description: form.description || null,
        icon: form.icon,
        sortOrder: Number(form.sortOrder),
        isActive: form.isActive,
      };
      if (editing) await api.patch(`/api/categories/${editing.id}`, payload);
      else await api.post("/api/categories", payload);
      setOpen(false);
      await categories.refresh();
      push({ tone: "success", title: editing ? "دسته‌بندی به‌روزرسانی شد" : "دسته‌بندی ایجاد شد" });
    } catch (error) {
      push({
        tone: "error",
        title: "ذخیره نشد",
        description: error instanceof Error ? error.message : undefined,
      });
    } finally {
      setSaving(false);
    }
  }

  async function remove(category: CategoryDto) {
    categories.setData((prev) => (prev ? { items: prev.items.filter((c) => c.id !== category.id) } : prev));
    try {
      await api.delete(`/api/categories/${category.id}`);
      push({ tone: "success", title: "دسته‌بندی حذف شد" });
    } catch (error) {
      push({
        tone: "error",
        title: "حذف ناموفق بود",
        description: error instanceof Error ? error.message : undefined,
      });
      await categories.refresh();
    }
  }

  const items = categories.data?.items ?? [];

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900">دسته‌بندی‌ها</h2>
          <p className="mt-1 text-sm text-slate-600">نحوه گروه‌بندی فهرست محصولات در فروشگاه.</p>
        </div>
        <Button onClick={() => start(null)}>دسته‌بندی جدید</Button>
      </div>

      {categories.loading ? (
        <SkeletonRows rows={5} cols={4} />
      ) : items.length === 0 ? (
        <EmptyState
          icon="folder"
          title="دسته‌بندی‌ای وجود ندارد"
          description="یکی بسازید تا محصولات خود را گروه‌بندی کنید."
          action={<Button onClick={() => start(null)}>دسته‌بندی جدید</Button>}
        />
      ) : (
        <Card padding={false}>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 text-start text-xs font-semibold uppercase tracking-wide text-slate-500">
                <tr>
                  <th className="px-5 py-3">نام</th>
                  <th className="px-5 py-3">نامک</th>
                  <th className="px-5 py-3 text-center">محصولات</th>
                  <th className="px-5 py-3 text-center">شماره سفارش</th>
                  <th className="px-5 py-3 text-center">وضعیت</th>
                  <th className="px-5 py-3 text-end">عملیات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {items.map((category) => (
                  <tr key={category.id} className="hover:bg-slate-50/60">
                    <td className="px-5 py-3">
                      <p className="font-medium text-slate-900">{category.name}</p>
                      <p className="text-xs text-slate-500">{category.description}</p>
                    </td>
                    <td className="px-5 py-3 font-mono text-xs text-slate-600">{category.slug}</td>
                    <td className="px-5 py-3 text-center text-slate-600">{category.productCount ?? 0}</td>
                    <td className="px-5 py-3 text-center text-slate-600">{category.sortOrder}</td>
                    <td className="px-5 py-3 text-center">
                      <Badge tone={category.isActive ? "green" : "slate"}>
                        {category.isActive ? "Active" : "پنهان"}
                      </Badge>
                    </td>
                    <td className="px-5 py-3">
                      <div className="flex justify-end gap-1.5">
                        <Button variant="outline" size="sm" onClick={() => start(category)}>ویرایش</Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-rose-600 hover:bg-rose-50"
                          onClick={() => void remove(category)}
                          disabled={(category.productCount ?? 0) > 0}
                        >حذف</Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}

      <Modal
        open={open}
        onClose={() => setOpen(false)}
        title={editing ? `Edit ${editing.name}` : "دسته‌بندی جدید"}
        footer={
          <>
            <Button variant="ghost" onClick={() => setOpen(false)}>انصراف</Button>
            <Button loading={saving} onClick={() => void save()} disabled={form.name.length < 2}>ذخیره</Button>
          </>
        }
      >
        <div className="grid gap-4">
          <Field label="نام" required>
            <Input
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value, slug: form.slug || slugify(e.target.value) })}
            />
          </Field>
          <Field label="نامک" required>
            <Input value={form.slug} onChange={(e) => setForm({ ...form, slug: e.target.value })} />
          </Field>
          <Field label="توضیحات">
            <Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} rows={3} />
          </Field>
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="کلید آیکون" hint="package · layers · boxes · monitor · puzzle">
              <Input value={form.icon} onChange={(e) => setForm({ ...form, icon: e.target.value })} />
            </Field>
            <Field label="ترتیب نمایش">
              <Input
                type="number"
                value={form.sortOrder}
                onChange={(e) => setForm({ ...form, sortOrder: Number(e.target.value) })}
              />
            </Field>
          </div>
          <label className="flex items-center gap-2 text-sm text-slate-700">
            <input
              type="checkbox"
              checked={form.isActive}
              onChange={(e) => setForm({ ...form, isActive: e.target.checked })}
              className="h-4 w-4 rounded border-slate-300"
            />
            نمایش در فروشگاه
          </label>
        </div>
      </Modal>
    </div>
  );
}
