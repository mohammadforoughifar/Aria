"use client";

import Link from "next/link";
import { AreaChart, BarChart, DonutChart } from "@/components/charts";
import {
  Badge,
  Card,
  EmptyState,
  SectionTitle,
  SkeletonRows,
  SkeletonStats,
  StatCard,
  statusTone,
} from "@/components/ui";
import { useApi } from "@/lib/client/api";
import { formatDate, formatMoney, faNum } from "@/lib/format";
import type { AdminOverviewDto } from "@/shared/contracts";

export default function AdminOverviewPage() {
  const { data, loading, error } = useApi<AdminOverviewDto>("/api/reports/admin");

  if (loading) {
    return (
      <div className="space-y-6">
        <SkeletonStats />
        <SkeletonRows rows={6} cols={5} />
      </div>
    );
  }
  if (error || !data) {
    return <EmptyState title="نمای کلی بارگذاری نشد" description={error ?? undefined} />;
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-bold tracking-tight text-slate-900">نمای کلی کسب‌وکار</h2>
        <p className="mt-1 text-sm text-slate-600">درآمد، مشتریان و وضعیت لایسنس‌ها در کل پلتفرم.</p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard
          label="درآمد کل"
          value={formatMoney(data.revenueCents)}
          icon="💰"
          tone="green"
          hint={`${formatMoney(data.revenueLast30Cents)} در ۳۰ روز گذشته`}
        />
        <StatCard
          label="سفارش‌ها"
          value={faNum(data.orderCount)}
          icon="🧾"
          tone="indigo"
          hint={`${faNum(data.pendingOrderCount)} در انتظار`}
        />
        <StatCard
          label="مشتریان"
          value={String(data.customerCount)}
          icon="👥"
          tone="blue"
          hint={`+${data.newCustomers30} in 30 days`}
        />
        <StatCard label="میانگین سفارش" value={formatMoney(data.averageOrderCents)} icon="📈" tone="violet" />
      </div>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="لایسنس فعال" value={faNum(data.activeLicenses)} icon="🔑" tone="indigo" />
        <StatCard
          label="انقضا در ۴۵ روز"
          value={String(data.expiringLicenses)}
          icon="⏳"
          tone={data.expiringLicenses ? "amber" : "green"}
        />
        <StatCard label="تیکت باز" value={faNum(data.openTickets)} icon="🎫" tone={data.openTickets ? "amber" : "green"} />
        <StatCard
          label="نظرات در انتظار بررسی"
          value={String(data.pendingReviews)}
          icon="⭐"
          tone={data.pendingReviews ? "amber" : "green"}
        />
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <SectionTitle title="درآمد ماهانه" description="۶ ماه گذشته، همه سفارش‌های پرداخت‌شده" />
          <div className="mt-6">
            <BarChart
              data={data.revenueByMonth.map((r) => ({ label: r.label, value: r.valueCents }))}
              formatValue={(v) => formatMoney(v)}
            />
          </div>
        </Card>
        <Card>
          <SectionTitle title="سفارش‌ها بر اساس وضعیت" />
          <div className="mt-6">
            <DonutChart data={data.ordersByStatus.map((s) => ({ label: s.label, value: s.value }))} />
          </div>
        </Card>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <SectionTitle title="رشد مشتریان" description="حساب‌های جدید در هر ماه" />
          <div className="mt-6">
            <AreaChart data={data.customerGrowth} />
          </div>
        </Card>
        <Card>
          <SectionTitle title="محصولات برتر" description="بر اساس درآمد" />
          <ul className="mt-4 space-y-3">
            {data.topProducts.map((product) => (
              <li key={product.name} className="flex items-center justify-between gap-3 text-sm">
                <span className="min-w-0 truncate text-slate-700">{product.name}</span>
                <span className="shrink-0 text-end">
                  <span className="block font-semibold text-slate-900">{formatMoney(product.revenueCents)}</span>
                  <span className="block text-xs text-slate-500">{faNum(product.units)} عدد</span>
                </span>
              </li>
            ))}
          </ul>
        </Card>
      </div>

      <Card padding={false}>
        <div className="flex items-center justify-between gap-3 border-b border-slate-200 px-5 py-4">
          <SectionTitle title="سفارش‌های اخیر" />
          <Link href="/dashboard/admin/orders" className="text-sm font-semibold text-indigo-600 hover:text-indigo-500">
            مشاهده همه ←
          </Link>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 text-start text-xs font-semibold uppercase tracking-wide text-slate-500">
              <tr>
                <th className="px-5 py-3">شماره سفارش</th>
                <th className="px-5 py-3">مشتری</th>
                <th className="px-5 py-3">تاریخ ثبت</th>
                <th className="px-5 py-3">وضعیت</th>
                <th className="px-5 py-3 text-end">مجموع</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {data.recentOrders.map((order) => (
                <tr key={order.id} className="hover:bg-slate-50/60">
                  <td className="px-5 py-3 font-mono text-xs text-slate-700">{order.orderNumber}</td>
                  <td className="px-5 py-3">
                    <p className="font-medium text-slate-900">{order.customerName}</p>
                    <p className="text-xs text-slate-500">{order.customerEmail}</p>
                  </td>
                  <td className="px-5 py-3 text-slate-600">{formatDate(order.placedAt)}</td>
                  <td className="px-5 py-3">
                    <Badge tone={statusTone(order.status)}>{order.status}</Badge>
                  </td>
                  <td className="px-5 py-3 text-end font-semibold text-slate-900">
                    {formatMoney(order.totalCents)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
