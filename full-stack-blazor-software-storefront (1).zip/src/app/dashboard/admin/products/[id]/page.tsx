"use client";

import Link from "next/link";
import { useParams } from "next/navigation";
import { useState } from "react";
import {
  Badge,
  Button,
  Card,
  EmptyState,
  Field,
  Input,
  Modal,
  SectionTitle,
  Select,
  SkeletonRows,
  Textarea,
  useToast,
} from "@/components/ui";
import { api, useApi } from "@/lib/client/api";
import { formatDate, formatMoney, faNum, formatSize } from "@/lib/format";
import type { PlanDto, ProductDetailDto, ProductVersionDto } from "@/shared/contracts";

export default function AdminProductDetailPage() {
  const params = useParams<{ id: string }>();
  const { push } = useToast();
  const product = useApi<ProductDetailDto>(params?.id ? `/api/products/${params.id}` : null);
  const [planModal, setPlanModal] = useState<PlanDto | "new" | null>(null);
  const [versionModal, setVersionModal] = useState(false);
  const [saving, setSaving] = useState(false);
  const [planForm, setPlanForm] = useState({
    name: "",
    tier: "SingleUser" as PlanDto["tier"],
    billingType: "OneTime" as PlanDto["billingType"],
    priceCents: 0,
    seats: 1,
    description: "",
    isPopular: false,
  });
  const [versionForm, setVersionForm] = useState({
    version: "",
    releasedAt: new Date().toISOString().slice(0, 10),
    notes: "",
    sizeMb: 180,
    platform: "Windows 10/11",
  });

  const data = product.data;

  function openPlan(plan: PlanDto | "new") {
    if (plan === "new") {
      setPlanForm({
        name: "",
        tier: "SingleUser",
        billingType: "OneTime",
        priceCents: 0,
        seats: 1,
        description: "",
        isPopular: false,
      });
    } else {
      setPlanForm({
        name: plan.name,
        tier: plan.tier,
        billingType: plan.billingType,
        priceCents: plan.priceCents,
        seats: plan.seats,
        description: plan.description ?? "",
        isPopular: plan.isPopular,
      });
    }
    setPlanModal(plan);
  }

  async function savePlan() {
    if (!data) return;
    setSaving(true);
    try {
      const payload = {
        ...planForm,
        priceCents: Number(planForm.priceCents),
        seats: Number(planForm.seats),
        description: planForm.description || null,
      };
      if (planModal && planModal !== "new") {
        await api.patch(`/api/products/${data.id}/plans/${planModal.id}`, payload);
      } else {
        await api.post(`/api/products/${data.id}/plans`, { ...payload, productId: data.id });
      }
      setPlanModal(null);
      await product.refresh();
      push({ tone: "success", title: "پلن ذخیره شد" });
    } catch (error) {
      push({
        tone: "error",
        title: "ذخیره پلن ناموفق بود",
        description: error instanceof Error ? error.message : undefined,
      });
    } finally {
      setSaving(false);
    }
  }

  async function deletePlan(plan: PlanDto) {
    if (!data) return;
    product.setData({ ...data, plans: data.plans.filter((p) => p.id !== plan.id) });
    try {
      await api.delete(`/api/products/${data.id}/plans/${plan.id}`);
      push({ tone: "success", title: "پلن حذف شد" });
    } catch {
      await product.refresh();
    }
  }

  async function saveVersion() {
    if (!data) return;
    setSaving(true);
    try {
      await api.post(`/api/products/${data.id}/versions`, {
        ...versionForm,
        productId: data.id,
        sizeMb: Number(versionForm.sizeMb),
        releasedAt: new Date(versionForm.releasedAt).toISOString(),
      });
      setVersionModal(false);
      setVersionForm({
        version: "",
        releasedAt: new Date().toISOString().slice(0, 10),
        notes: "",
        sizeMb: 180,
        platform: versionForm.platform,
      });
      await product.refresh();
      push({ tone: "success", title: "نسخه منتشر شد" });
    } catch (error) {
      push({
        tone: "error",
        title: "انتشار ناموفق بود",
        description: error instanceof Error ? error.message : undefined,
      });
    } finally {
      setSaving(false);
    }
  }

  async function deleteVersion(version: ProductVersionDto) {
    if (!data) return;
    product.setData({ ...data, versions: data.versions.filter((v) => v.id !== version.id) });
    try {
      await api.delete(`/api/products/${data.id}/versions/${version.id}`);
    } catch {
      await product.refresh();
    }
  }

  if (product.loading) return <SkeletonRows rows={6} cols={4} />;
  if (product.error || !data) {
    return (
      <EmptyState
        icon="box"
        title="محصول پیدا نشد"
        description={product.error ?? undefined}
        action={
          <Link href="/dashboard/admin/products">
            <Button variant="outline">بازگشت به محصولات</Button>
          </Link>
        }
      />
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <Link href="/dashboard/admin/products" className="text-xs font-semibold text-indigo-600 hover:text-indigo-500">
            ← همه محصولات
          </Link>
          <h2 className="mt-2 text-xl font-bold tracking-tight text-slate-900">{data.name}</h2>
          <p className="mt-1 text-sm text-slate-500">
            {data.categoryName} · {data.type} · v{data.version} · from {formatMoney(data.basePriceCents)}
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Link href={`/products/${data.slug}`}>
            <Button variant="outline">مشاهده در فروشگاه</Button>
          </Link>
          <Button variant="outline" onClick={() => setVersionModal(true)}>
            انتشار نسخه
          </Button>
          <Button onClick={() => openPlan("new")}>افزودن پلن</Button>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card padding={false}>
          <div className="flex items-center justify-between border-b border-slate-200 px-5 py-4">
            <SectionTitle title="پلن‌های قیمتی" description={`${faNum(data.plans.length)} پلن`} />
            <Button size="sm" variant="outline" onClick={() => openPlan("new")}>افزودن</Button>
          </div>
          {data.plans.length === 0 ? (
            <p className="px-5 py-6 text-sm text-slate-500">هنوز پلنی نیست — یک پلن اضافه کنید تا مشتریان بتوانند خرید کنند.</p>
          ) : (
            <ul className="divide-y divide-slate-100">
              {data.plans.map((plan) => (
                <li key={plan.id} className="flex flex-wrap items-center gap-3 px-5 py-4">
                  <div className="min-w-40 flex-1">
                    <p className="flex items-center gap-2 text-sm font-semibold text-slate-900">
                      {plan.name}
                      {plan.isPopular && <Badge tone="indigo">پیشنهادی</Badge>}
                    </p>
                    <p className="text-xs text-slate-500">
                      {plan.tier} · {faNum(plan.seats)} کاربر · {plan.billingType === "OneTime" ? "یک‌باره" : "سالانه"}
                    </p>
                  </div>
                  <p className="text-sm font-bold text-slate-900">{formatMoney(plan.priceCents)}</p>
                  <div className="flex gap-1.5">
                    <Button variant="outline" size="sm" onClick={() => openPlan(plan)}>ویرایش</Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-rose-600 hover:bg-rose-50"
                      onClick={() => void deletePlan(plan)}
                    >حذف</Button>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </Card>

        <Card padding={false}>
          <div className="flex items-center justify-between border-b border-slate-200 px-5 py-4">
            <SectionTitle title="نسخه‌ها و تاریخچه تغییرات" description={`${faNum(data.versions.length)} انتشار`} />
            <Button size="sm" variant="outline" onClick={() => setVersionModal(true)}>انتشار</Button>
          </div>
          {data.versions.length === 0 ? (
            <p className="px-5 py-6 text-sm text-slate-500">هنوز نسخه‌ای منتشر نشده است.</p>
          ) : (
            <ul className="divide-y divide-slate-100">
              {data.versions.map((version) => (
                <li key={version.id} className="px-5 py-4">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <span className="rounded-md bg-slate-900 px-2 py-0.5 text-xs font-bold text-white">
                      v{version.version}
                    </span>
                    <span className="text-xs text-slate-500">
                      {formatDate(version.releasedAt)} · {version.platform} · {formatSize(version.sizeMb)}
                    </span>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-rose-600 hover:bg-rose-50"
                      onClick={() => void deleteVersion(version)}
                    >حذف</Button>
                  </div>
                  <p className="mt-2 text-sm leading-relaxed text-slate-600">{version.notes}</p>
                </li>
              ))}
            </ul>
          )}
        </Card>
      </div>

      <Card>
        <SectionTitle title="محتوا" description="متن بازاریابی نمایش‌داده‌شده در فروشگاه" />
        <div className="mt-4 grid gap-4 sm:grid-cols-2">
          <div className="sm:col-span-2">
            <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">توضیحات</p>
            <p className="mt-1 whitespace-pre-wrap text-sm leading-relaxed text-slate-700">{data.description}</p>
          </div>
          <div>
            <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">قابلیت‌ها</p>
            <ul className="mt-2 space-y-1 text-sm text-slate-700">
              {data.features.map((f) => (
                <li key={f}>· {f}</li>
              ))}
            </ul>
          </div>
          <div>
            <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">پیش‌نیازها</p>
            <ul className="mt-2 space-y-1 text-sm text-slate-700">
              {data.systemRequirements.map((r) => (
                <li key={r}>· {r}</li>
              ))}
            </ul>
          </div>
        </div>
      </Card>

      <Modal
        open={planModal !== null}
        onClose={() => setPlanModal(null)}
        title={planModal && planModal !== "new" ? `Edit ${planModal.name}` : "افزودن پلن قیمتی"}
        footer={
          <>
            <Button variant="ghost" onClick={() => setPlanModal(null)}>انصراف</Button>
            <Button loading={saving} onClick={() => void savePlan()} disabled={planForm.name.length < 2}>
              ذخیره پلن
            </Button>
          </>
        }
      >
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="نام پلن" required className="sm:col-span-2">
            <Input value={planForm.name} onChange={(e) => setPlanForm({ ...planForm, name: e.target.value })} />
          </Field>
          <Field label="سطح" required>
            <Select value={planForm.tier} onChange={(e) => setPlanForm({ ...planForm, tier: e.target.value as PlanDto["tier"] })}>
              <option value="SingleUser">تک‌کاربره</option>
              <option value="MultiUser">چندکاربره</option>
              <option value="Enterprise">سازمانی</option>
            </Select>
          </Field>
          <Field label="نوع صورتحساب" required>
            <Select
              value={planForm.billingType}
              onChange={(e) => setPlanForm({ ...planForm, billingType: e.target.value as PlanDto["billingType"] })}
            >
              <option value="OneTime">یک‌باره</option>
              <option value="Annual">اشتراک سالانه</option>
            </Select>
          </Field>
          <Field label="قیمت (سنت)" required hint={`نمایش به‌صورت ${formatMoney(Number(planForm.priceCents))}`}>
            <Input
              type="number"
              value={planForm.priceCents}
              onChange={(e) => setPlanForm({ ...planForm, priceCents: Number(e.target.value) })}
            />
          </Field>
          <Field label="تعداد کاربر" required>
            <Input
              type="number"
              value={planForm.seats}
              onChange={(e) => setPlanForm({ ...planForm, seats: Number(e.target.value) })}
            />
          </Field>
          <Field label="توضیحات" className="sm:col-span-2">
            <Textarea
              value={planForm.description}
              onChange={(e) => setPlanForm({ ...planForm, description: e.target.value })}
              rows={3}
            />
          </Field>
          <label className="flex items-center gap-2 text-sm text-slate-700">
            <input
              type="checkbox"
              checked={planForm.isPopular}
              onChange={(e) => setPlanForm({ ...planForm, isPopular: e.target.checked })}
              className="h-4 w-4 rounded border-slate-300"
            />
            نمایش به‌عنوان محبوب‌ترین
          </label>
        </div>
      </Modal>

      <Modal
        open={versionModal}
        onClose={() => setVersionModal(false)}
        title="انتشار نسخه"
        description="یک ردیف تاریخچه اضافه و نسخه نمایش‌داده‌شده را به‌روزرسانی می‌کند."
        footer={
          <>
            <Button variant="ghost" onClick={() => setVersionModal(false)}>انصراف</Button>
            <Button
              loading={saving}
              onClick={() => void saveVersion()}
              disabled={versionForm.version.length < 1 || versionForm.notes.length < 3}
            >انتشار</Button>
          </>
        }
      >
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="نسخه" required>
            <Input
              value={versionForm.version}
              onChange={(e) => setVersionForm({ ...versionForm, version: e.target.value })}
              placeholder="2025.3.0"
            />
          </Field>
          <Field label="تاریخ انتشار" required>
            <Input
              type="date"
              value={versionForm.releasedAt}
              onChange={(e) => setVersionForm({ ...versionForm, releasedAt: e.target.value })}
            />
          </Field>
          <Field label="پلتفرم">
            <Input
              value={versionForm.platform}
              onChange={(e) => setVersionForm({ ...versionForm, platform: e.target.value })}
            />
          </Field>
          <Field label="حجم نصب‌کننده (مگابایت)">
            <Input
              type="number"
              value={versionForm.sizeMb}
              onChange={(e) => setVersionForm({ ...versionForm, sizeMb: Number(e.target.value) })}
            />
          </Field>
          <Field label="یادداشت انتشار" required className="sm:col-span-2">
            <Textarea
              value={versionForm.notes}
              onChange={(e) => setVersionForm({ ...versionForm, notes: e.target.value })}
              rows={4}
            />
          </Field>
        </div>
      </Modal>
    </div>
  );
}
