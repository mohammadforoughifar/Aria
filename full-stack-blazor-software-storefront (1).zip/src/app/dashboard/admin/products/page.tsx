"use client";

import Link from "next/link";
import { useState } from "react";
import {
  Badge,
  Button,
  Card,
  EmptyState,
  Field,
  Input,
  Modal,
  Pagination,
  Select,
  SkeletonRows,
  Textarea,
  useToast,
} from "@/components/ui";
import { api, useApi } from "@/lib/client/api";
import { formatMoney, slugify, faNum } from "@/lib/format";
import type { CategoryDto, ProductDetailDto, ProductListItemDto } from "@/shared/contracts";

const emptyForm = {
  name: "",
  slug: "",
  tagline: "",
  description: "",
  categoryId: "",
  type: "Module" as ProductDetailDto["type"],
  platform: "Windows 10/11",
  version: "2025.2.1",
  basePriceCents: 0,
  accentColor: "#4f46e5",
  features: "",
  systemRequirements: "",
  trialDays: 30,
  isFeatured: false,
  isActive: true,
};

export default function AdminProductsPage() {
  const { push } = useToast();
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("all");
  const [editing, setEditing] = useState<ProductListItemDto | null>(null);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);

  const query = new URLSearchParams({ page: String(page), pageSize: "10", includeInactive: "true" });
  if (search) query.set("search", search);
  if (category !== "all") query.set("category", category);
  const products = useApi<{ items: ProductListItemDto[] }>(`/api/products?${query.toString()}`);
  const categories = useApi<{ items: CategoryDto[] }>("/api/categories?includeInactive=true");

  function startCreate() {
    setEditing(null);
    setForm({ ...emptyForm, categoryId: categories.data?.items[0]?.id ?? "" });
    setOpen(true);
  }

  function startEdit(product: ProductListItemDto) {
    setEditing(product);
    setForm({
      ...emptyForm,
      name: product.name,
      slug: product.slug,
      tagline: product.tagline,
      categoryId:
        categories.data?.items.find((c) => c.name === product.categoryName)?.id ??
        categories.data?.items[0]?.id ??
        "",
      type: product.type,
      platform: product.platform,
      version: product.version,
      basePriceCents: product.basePriceCents,
      accentColor: product.accentColor,
      isActive: product.isActive,
      isFeatured: product.isFeatured,
    });
    setOpen(true);
  }

  async function save() {
    setSaving(true);
    try {
      const payload = {
        name: form.name,
        slug: form.slug || slugify(form.name),
        tagline: form.tagline,
        description: form.description,
        categoryId: form.categoryId,
        type: form.type,
        platform: form.platform,
        version: form.version,
        basePriceCents: Number(form.basePriceCents),
        accentColor: form.accentColor,
        features: form.features.split("\n").map((f) => f.trim()).filter(Boolean),
        systemRequirements: form.systemRequirements.split("\n").map((f) => f.trim()).filter(Boolean),
        trialDays: Number(form.trialDays),
        isFeatured: form.isFeatured,
        isActive: form.isActive,
      };
      if (editing) {
        await api.patch(`/api/products/${editing.id}`, payload);
        push({ tone: "success", title: "محصول به‌روزرسانی شد" });
      } else {
        await api.post("/api/products", payload);
        push({ tone: "success", title: "محصول ایجاد شد" });
      }
      setOpen(false);
      await products.refresh();
    } catch (error) {
      push({
        tone: "error",
        title: "ذخیره نشد",
        description: error instanceof Error ? error.message : undefined,
      });
    } finally {
      setSaving(false);
    }
  }

  async function toggleActive(product: ProductListItemDto) {
    products.setData((prev) =>
      prev ? { items: prev.items.map((p) => (p.id === product.id ? { ...p, isActive: !p.isActive } : p)) } : prev,
    );
    try {
      await api.patch(`/api/products/${product.id}`, { isActive: !product.isActive });
    } catch {
      await products.refresh();
    }
  }

  async function remove(product: ProductListItemDto) {
    products.setData((prev) => (prev ? { items: prev.items.filter((p) => p.id !== product.id) } : prev));
    try {
      await api.delete(`/api/products/${product.id}`);
      push({ tone: "success", title: `${product.name} حذف شد` });
    } catch (error) {
      push({
        tone: "error",
        title: "حذف ناموفق بود",
        description: error instanceof Error ? error.message : undefined,
      });
      await products.refresh();
    }
  }

  const items = products.data?.items ?? [];

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900">محصولات</h2>
          <p className="mt-1 text-sm text-slate-600">
            ماژول‌ها، برنامه‌های دسکتاپ و افزونه‌ها — {faNum(products.meta?.totalCount ?? items.length)} محصول در فهرست.
          </p>
        </div>
        <Button onClick={startCreate}>محصول جدید</Button>
      </div>

      <div className="grid gap-3 sm:grid-cols-[1fr_240px]">
        <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="جستجوی محصولات…" />
        <Select value={category} onChange={(e) => setCategory(e.target.value)}>
          <option value="all">همه دسته‌بندی‌ها</option>
          {categories.data?.items.map((c) => (
            <option key={c.id} value={c.slug}>
              {c.name}
            </option>
          ))}
        </Select>
      </div>

      {products.loading ? (
        <SkeletonRows rows={6} cols={5} />
      ) : items.length === 0 ? (
        <EmptyState
          icon="box"
          title="محصولی وجود ندارد"
          description="اولین محصول را بسازید تا فروشگاه پر شود."
          action={<Button onClick={startCreate}>محصول جدید</Button>}
        />
      ) : (
        <Card padding={false}>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 text-start text-xs font-semibold uppercase tracking-wide text-slate-500">
                <tr>
                  <th className="px-5 py-3">محصول</th>
                  <th className="px-5 py-3">دسته‌بندی</th>
                  <th className="px-5 py-3">نوع</th>
                  <th className="px-5 py-3 text-end">از</th>
                  <th className="px-5 py-3 text-center">وضعیت</th>
                  <th className="px-5 py-3 text-end">عملیات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {items.map((product) => (
                  <tr key={product.id} className="hover:bg-slate-50/60">
                    <td className="px-5 py-3">
                      <Link
                        href={`/dashboard/admin/products/${product.id}`}
                        className="font-medium text-slate-900 hover:text-indigo-700"
                      >
                        {product.name}
                      </Link>
                      <p className="text-xs text-slate-500">
                        {product.slug} · v{product.version}
                      </p>
                    </td>
                    <td className="px-5 py-3 text-slate-600">{product.categoryName}</td>
                    <td className="px-5 py-3 text-slate-600">{product.type}</td>
                    <td className="px-5 py-3 text-end font-semibold text-slate-900">
                      {formatMoney(product.basePriceCents)}
                    </td>
                    <td className="px-5 py-3 text-center">
                      <div className="flex flex-wrap justify-center gap-1">
                        <Badge tone={product.isActive ? "green" : "slate"}>
                          {product.isActive ? "فعال" : "پنهان"}
                        </Badge>
                        {product.isFeatured && <Badge tone="amber">ویژه</Badge>}
                      </div>
                    </td>
                    <td className="px-5 py-3">
                      <div className="flex justify-end gap-1.5">
                        <Link href={`/dashboard/admin/products/${product.id}`}>
                          <Button variant="outline" size="sm">مدیریت</Button>
                        </Link>
                        <Button variant="ghost" size="sm" onClick={() => void toggleActive(product)}>
                          {product.isActive ? "پنهان" : "انتشار"}
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-rose-600 hover:bg-rose-50"
                          onClick={() => void remove(product)}
                        >حذف</Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <Pagination page={products.meta?.page ?? 1} totalPages={products.meta?.totalPages ?? 1} onChange={setPage} />
        </Card>
      )}

      <Modal
        open={open}
        onClose={() => setOpen(false)}
        title={editing ? `Edit ${editing.name}` : "محصول جدید"}
        description="پلن‌ها و نسخه‌ها پس از ذخیره از صفحه محصول مدیریت می‌شوند."
        wide
        footer={
          <>
            <Button variant="ghost" onClick={() => setOpen(false)}>انصراف</Button>
            <Button
              loading={saving}
              onClick={() => void save()}
              disabled={form.name.length < 2 || form.description.length < 20}
            >
              {editing ? "ذخیره تغییرات" : "ایجاد محصول"}
            </Button>
          </>
        }
      >
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="نام" required>
            <Input
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value, slug: form.slug || slugify(e.target.value) })}
            />
          </Field>
          <Field label="نامک" required hint="حروف کوچک با خط تیره">
            <Input value={form.slug} onChange={(e) => setForm({ ...form, slug: e.target.value })} />
          </Field>
          <Field label="دسته‌بندی" required>
            <Select value={form.categoryId} onChange={(e) => setForm({ ...form, categoryId: e.target.value })}>
              {categories.data?.items.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="نوع محصول" required>
            <Select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value as ProductDetailDto["type"] })}>
              <option value="Module">ماژول ERP</option>
              <option value="DesktopApp">برنامه دسکتاپ</option>
              <option value="AddOn">افزونه</option>
            </Select>
          </Field>
          <Field label="شعار" required className="sm:col-span-2">
            <Input value={form.tagline} onChange={(e) => setForm({ ...form, tagline: e.target.value })} />
          </Field>
          <Field label="توضیحات" required hint="حداقل ۲۰ کاراکتر" className="sm:col-span-2">
            <Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} rows={5} />
          </Field>
          <Field label="پلتفرم" required>
            <Input value={form.platform} onChange={(e) => setForm({ ...form, platform: e.target.value })} />
          </Field>
          <Field label="نسخه فعلی" required>
            <Input value={form.version} onChange={(e) => setForm({ ...form, version: e.target.value })} />
          </Field>
          <Field label="قیمت پایه (سنت)" required hint={`نمایش به‌صورت ${formatMoney(Number(form.basePriceCents))}`}>
            <Input
              type="number"
              value={form.basePriceCents}
              onChange={(e) => setForm({ ...form, basePriceCents: Number(e.target.value) })}
            />
          </Field>
          <Field label="رنگ سازمانی">
            <Input value={form.accentColor} onChange={(e) => setForm({ ...form, accentColor: e.target.value })} />
          </Field>
          <Field label="مدت آزمایش (روز)">
            <Input
              type="number"
              value={form.trialDays}
              onChange={(e) => setForm({ ...form, trialDays: Number(e.target.value) })}
            />
          </Field>
          <div className="flex items-end gap-6">
            <label className="flex items-center gap-2 text-sm text-slate-700">
              <input
                type="checkbox"
                checked={form.isFeatured}
                onChange={(e) => setForm({ ...form, isFeatured: e.target.checked })}
                className="h-4 w-4 rounded border-slate-300"
              />
              ویژه
            </label>
            <label className="flex items-center gap-2 text-sm text-slate-700">
              <input
                type="checkbox"
                checked={form.isActive}
                onChange={(e) => setForm({ ...form, isActive: e.target.checked })}
                className="h-4 w-4 rounded border-slate-300"
              />
              نمایش در فروشگاه
            </label>
          </div>
          <Field label="قابلیت‌ها" hint="هر مورد در یک خط" className="sm:col-span-2">
            <Textarea value={form.features} onChange={(e) => setForm({ ...form, features: e.target.value })} rows={4} />
          </Field>
          <Field label="پیش‌نیازهای سیستم" hint="هر مورد در یک خط" className="sm:col-span-2">
            <Textarea
              value={form.systemRequirements}
              onChange={(e) => setForm({ ...form, systemRequirements: e.target.value })}
              rows={4}
            />
          </Field>
        </div>
      </Modal>
    </div>
  );
}
