"use client";

import { useState } from "react";
import {
  Badge,
  Button,
  Card,
  EmptyState,
  Input,
  Modal,
  Pagination,
  Select,
  SkeletonRows,
  Tabs,
  statusTone,
  useToast,
} from "@/components/ui";
import { api, useApi } from "@/lib/client/api";
import { formatDate, formatMoney, faNum } from "@/lib/format";
import type { OrderDto } from "@/shared/contracts";

const STATUSES = ["Pending", "Paid", "Processing", "Completed", "Refunded", "Cancelled"];

export default function AdminOrdersPage() {
  const { push } = useToast();
  const [status, setStatus] = useState("all");
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);
  const [detail, setDetail] = useState<OrderDto | null>(null);

  const query = new URLSearchParams({ page: String(page), pageSize: "10" });
  if (status !== "all") query.set("status", status);
  if (search) query.set("search", search);
  const orders = useApi<{ items: OrderDto[] }>(`/api/orders?${query.toString()}`);

  async function changeStatus(order: OrderDto, next: string) {
    orders.setData((prev) =>
      prev
        ? { items: prev.items.map((o) => (o.id === order.id ? { ...o, status: next as OrderDto["status"] } : o)) }
        : prev,
    );
    try {
      await api.patch(`/api/orders/${order.id}`, { status: next });
      push({ tone: "success", title: `${order.orderNumber} → ${next}` });
    } catch (error) {
      await orders.refresh();
      push({
        tone: "error",
        title: "به‌روزرسانی ناموفق بود",
        description: error instanceof Error ? error.message : undefined,
      });
    }
  }

  async function openOrder(id: string) {
    const { data } = await api.get<OrderDto>(`/api/orders/${id}`);
    setDetail(data);
  }

  const items = orders.data?.items ?? [];

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-bold tracking-tight text-slate-900">سفارش‌ها</h2>
        <p className="mt-1 text-sm text-slate-600">
          {faNum(orders.meta?.totalCount ?? items.length)} سفارش در میان همه مشتریان.
        </p>
      </div>

      <div className="flex flex-wrap items-center gap-3">
        <Tabs
          tabs={[{ id: "all", label: "همه" }, ...STATUSES.map((s) => ({ id: s, label: s }))]}
          active={status}
          onChange={setStatus}
        />
        <Input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="جستجوی سفارش یا مشتری…"
          className="max-w-xs"
        />
      </div>

      {orders.loading ? (
        <SkeletonRows rows={8} cols={6} />
      ) : items.length === 0 ? (
        <EmptyState icon="receipt" title="سفارشی وجود ندارد" description="سفارشی با این فیلترها پیدا نشد." />
      ) : (
        <Card padding={false}>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 text-start text-xs font-semibold uppercase tracking-wide text-slate-500">
                <tr>
                  <th className="px-5 py-3">شماره سفارش</th>
                  <th className="px-5 py-3">مشتری</th>
                  <th className="px-5 py-3">تاریخ ثبت</th>
                  <th className="px-5 py-3 text-end">مجموع</th>
                  <th className="px-5 py-3">وضعیت</th>
                  <th className="px-5 py-3 text-end">عملیات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {items.map((order) => (
                  <tr key={order.id} className="hover:bg-slate-50/60">
                    <td className="px-5 py-3 font-mono text-xs text-slate-700">{order.orderNumber}</td>
                    <td className="px-5 py-3">
                      <p className="font-medium text-slate-900">{order.customerName}</p>
                      <p className="text-xs text-slate-500">{order.customerEmail}</p>
                    </td>
                    <td className="px-5 py-3 text-slate-600">{formatDate(order.placedAt)}</td>
                    <td className="px-5 py-3 text-end font-semibold text-slate-900">
                      {formatMoney(order.totalCents)}
                    </td>
                    <td className="px-5 py-3">
                      <Badge tone={statusTone(order.status)}>{order.status}</Badge>
                    </td>
                    <td className="px-5 py-3">
                      <div className="flex items-center justify-end gap-1.5">
                        <Select
                          value={order.status}
                          onChange={(e) => void changeStatus(order, e.target.value)}
                          className="w-36 text-xs"
                        >
                          {STATUSES.map((s) => (
                            <option key={s}>{s}</option>
                          ))}
                        </Select>
                        <Button variant="outline" size="sm" onClick={() => void openOrder(order.id)}>مشاهده</Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <Pagination page={orders.meta?.page ?? 1} totalPages={orders.meta?.totalPages ?? 1} onChange={setPage} />
        </Card>
      )}

      <Modal
        open={Boolean(detail)}
        onClose={() => setDetail(null)}
        title={detail ? `Order ${detail.orderNumber}` : "Order"}
        description={detail ? `${detail.customerName} · ${formatDate(detail.placedAt)}` : undefined}
        wide
        footer={
          <Button variant="ghost" onClick={() => setDetail(null)}>بستن</Button>
        }
      >
        {detail && (
          <div className="space-y-4">
            <div className="grid gap-3 sm:grid-cols-3">
              <div className="rounded-lg bg-slate-50 p-3 text-sm">
                <p className="text-xs font-semibold uppercase text-slate-500">وضعیت</p>
                <Badge tone={statusTone(detail.status)} className="mt-1">
                  {detail.status}
                </Badge>
              </div>
              <div className="rounded-lg bg-slate-50 p-3 text-sm">
                <p className="text-xs font-semibold uppercase text-slate-500">مجموع</p>
                <p className="mt-1 font-semibold text-slate-900">{formatMoney(detail.totalCents)}</p>
              </div>
              <div className="rounded-lg bg-slate-50 p-3 text-sm">
                <p className="text-xs font-semibold uppercase text-slate-500">تخفیف</p>
                <p className="mt-1 font-semibold text-slate-900">{detail.discountCode ?? "—"}</p>
              </div>
            </div>
            <table className="w-full text-sm">
              <thead className="bg-slate-50 text-start text-xs font-semibold uppercase text-slate-500">
                <tr>
                  <th className="px-4 py-2">محصول</th>
                  <th className="px-4 py-2">پلن</th>
                  <th className="px-4 py-2 text-center">تعداد</th>
                  <th className="px-4 py-2 text-end">مجموع</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {detail.items.map((item) => (
                  <tr key={item.id}>
                    <td className="px-4 py-2 font-medium text-slate-900">{item.productName}</td>
                    <td className="px-4 py-2 text-slate-600">{item.planName}</td>
                    <td className="px-4 py-2 text-center">{item.quantity}</td>
                    <td className="px-4 py-2 text-end font-semibold">{formatMoney(item.lineTotalCents)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            <div className="ms-auto max-w-xs space-y-1 text-sm">
              <div className="flex justify-between text-slate-600">
                <span>جمع جزء</span>
                <span>{formatMoney(detail.subtotalCents)}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>تخفیف</span>
                <span>−{formatMoney(detail.discountCents)}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>مالیات</span>
                <span>{formatMoney(detail.taxCents)}</span>
              </div>
              <div className="flex justify-between border-t border-slate-200 pt-1 font-bold text-slate-900">
                <span>مجموع</span>
                <span>{formatMoney(detail.totalCents)}</span>
              </div>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
