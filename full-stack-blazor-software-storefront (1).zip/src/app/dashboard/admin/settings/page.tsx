"use client";

import { useEffect, useState } from "react";
import { Button, Card, Field, Input, SectionTitle, SkeletonRows, Textarea, useToast } from "@/components/ui";
import { api, useApi } from "@/lib/client/api";
import type { SiteSettingsDto } from "@/shared/contracts";

export default function AdminSettingsPage() {
  const { push } = useToast();
  const { data, loading, setData } = useApi<SiteSettingsDto>("/api/settings");
  const [form, setForm] = useState<SiteSettingsDto | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (data) setForm(data);
  }, [data]);

  if (loading || !form) return <SkeletonRows rows={5} cols={2} />;

  async function save() {
    if (!form) return;
    const payload: SiteSettingsDto = { ...form };
    setSaving(true);
    try {
      const { data: updated } = await api.put<SiteSettingsDto>("/api/settings", {
        ...payload,
        taxRateBps: Number(payload.taxRateBps),
        trialDays: Number(payload.trialDays),
      });
      setData(updated);
      push({ tone: "success", title: "تنظیمات ذخیره شد", description: "فروشگاه بلافاصله به‌روزرسانی می‌شود." });
    } catch (error) {
      push({
        tone: "error",
        title: "ذخیره نشد",
        description: error instanceof Error ? error.message : undefined,
      });
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900">تنظیمات سایت</h2>
          <p className="mt-1 text-sm text-slate-600">متن فروشگاه، اطلاعات تماس و تنظیمات پیش‌فرض تجاری.</p>
        </div>
        <Button loading={saving} onClick={() => void save()}>
          ذخیره تنظیمات
        </Button>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <SectionTitle title="برند و متن‌ها" />
          <div className="mt-4 grid gap-4">
            <Field label="نام سایت" required>
              <Input value={form.siteName} onChange={(e) => setForm({ ...form, siteName: e.target.value })} />
            </Field>
            <Field label="تیتر اصلی صفحه نخست" required>
              <Input value={form.heroHeadline} onChange={(e) => setForm({ ...form, heroHeadline: e.target.value })} />
            </Field>
            <Field label="زیرعنوان صفحه نخست">
              <Textarea
                value={form.heroSubheading}
                onChange={(e) => setForm({ ...form, heroSubheading: e.target.value })}
                rows={3}
              />
            </Field>
            <Field label="نوار اطلاعیه" hint="برای پنهان شدن خالی بگذارید">
              <Input value={form.announcement} onChange={(e) => setForm({ ...form, announcement: e.target.value })} />
            </Field>
          </div>
        </Card>

        <div className="space-y-6">
          <Card>
            <SectionTitle title="اطلاعات تماس" />
            <div className="mt-4 grid gap-4">
              <Field label="ایمیل پشتیبانی" required>
                <Input value={form.supportEmail} onChange={(e) => setForm({ ...form, supportEmail: e.target.value })} />
              </Field>
              <Field label="ایمیل فروش" required>
                <Input value={form.salesEmail} onChange={(e) => setForm({ ...form, salesEmail: e.target.value })} />
              </Field>
              <Field label="تلفن پشتیبانی" required>
                <Input value={form.supportPhone} onChange={(e) => setForm({ ...form, supportPhone: e.target.value })} />
              </Field>
            </div>
          </Card>

          <Card>
            <SectionTitle title="تنظیمات پیش‌فرض تجاری" />
            <div className="mt-4 grid gap-4 sm:grid-cols-2">
              <Field
                label="نرخ مالیات (واحد پایه)"
                required
                hint={`${(Number(form.taxRateBps) / 100).toFixed(1)}% at checkout`}
              >
                <Input
                  type="number"
                  value={form.taxRateBps}
                  onChange={(e) => setForm({ ...form, taxRateBps: Number(e.target.value) })}
                />
              </Field>
              <Field label="مدت پیش‌فرض آزمایش (روز)" required>
                <Input
                  type="number"
                  value={form.trialDays}
                  onChange={(e) => setForm({ ...form, trialDays: Number(e.target.value) })}
                />
              </Field>
              <label className="flex items-center gap-2 text-sm text-slate-700 sm:col-span-2">
                <input
                  type="checkbox"
                  checked={form.maintenanceMode}
                  onChange={(e) => setForm({ ...form, maintenanceMode: e.target.checked })}
                  className="h-4 w-4 rounded border-slate-300"
                />
                حالت نگهداری (نوار اطلاع در فروشگاه نمایش می‌دهد)
              </label>
            </div>
          </Card>

          <Card>
            <SectionTitle title="داده‌ها" description="بازسازی داده‌های نمایشی" />
            <p className="mt-2 text-sm text-slate-600">
              محصولات، سفارش‌ها، لایسنس‌ها، تیکت‌ها و نظرات را بازسازی می‌کند. داده‌های فعلی جایگزین می‌شوند.
            </p>
            <Button
              variant="danger"
              className="mt-3"
              onClick={async () => {
                try {
                  await api.post("/api/system/reseed");
                  push({ tone: "success", title: "داده‌های نمایشی بازسازی شد" });
                  window.location.reload();
                } catch (error) {
                  push({
                    tone: "error",
                    title: "بازسازی ناموفق بود",
                    description: error instanceof Error ? error.message : undefined,
                  });
                }
              }}
            >
              بازسازی داده‌های نمایشی
            </Button>
          </Card>
        </div>
      </div>
    </div>
  );
}
