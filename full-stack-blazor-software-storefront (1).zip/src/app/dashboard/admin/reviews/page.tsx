"use client";

import { useState } from "react";
import { Badge, Button, Card, EmptyState, RatingStars, SkeletonRows, Tabs, statusTone, useToast } from "@/components/ui";
import { api, useApi } from "@/lib/client/api";
import { formatDate } from "@/lib/format";
import type { ReviewDto } from "@/shared/contracts";

export default function AdminReviewsPage() {
  const { push } = useToast();
  const [status, setStatus] = useState("Pending");
  const reviews = useApi<{ items: ReviewDto[] }>(`/api/reviews?status=${status}&pageSize=50`);

  async function moderate(review: ReviewDto, next: "Approved" | "Rejected") {
    reviews.setData((prev) =>
      prev ? { items: prev.items.map((r) => (r.id === review.id ? { ...r, status: next } : r)) } : prev,
    );
    try {
      await api.patch(`/api/reviews/${review.id}`, { status: next });
      push({ tone: "success", title: `Review ${next.toLowerCase()}` });
    } catch {
      await reviews.refresh();
    }
  }

  async function remove(review: ReviewDto) {
    reviews.setData((prev) => (prev ? { items: prev.items.filter((r) => r.id !== review.id) } : prev));
    try {
      await api.delete(`/api/reviews/${review.id}`);
      push({ tone: "success", title: "نظر حذف شد" });
    } catch {
      await reviews.refresh();
    }
  }

  const items = reviews.data?.items ?? [];

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-bold tracking-tight text-slate-900">بررسی نظرات</h2>
        <p className="mt-1 text-sm text-slate-600">
          تأیید یک نظر، امتیاز محصول را بلافاصله بازمحاسبه می‌کند.
        </p>
      </div>

      <Tabs
        tabs={[
          { id: "Pending", label: "در انتظار بررسی", badge: items.length },
          { id: "Approved", label: "تأییدشده" },
          { id: "Rejected", label: "ردشده" },
          { id: "all", label: "همه" },
        ]}
        active={status}
        onChange={setStatus}
      />

      {reviews.loading ? (
        <SkeletonRows rows={4} cols={4} />
      ) : items.length === 0 ? (
        <EmptyState
          icon="star"
          title={status === "Pending" ? "چیزی در انتظار بررسی نیست" : "نظری در این بخش نیست"}
          description="نظرات جدید مشتریان در صف بررسی قرار می‌گیرند."
        />
      ) : (
        <div className="space-y-4">
          {items.map((review) => (
            <Card key={review.id}>
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <div className="flex flex-wrap items-center gap-2">
                    <RatingStars value={review.rating} size={16} />
                    <p className="text-sm font-semibold text-slate-900">{review.title}</p>
                    <Badge tone={statusTone(review.status)}>{review.status}</Badge>
                  </div>
                  <p className="mt-1 text-xs text-slate-500">
                    {review.authorName}
                    {review.authorCompany ? ` · ${review.authorCompany}` : ""} · {review.productName} ·{" "}
                    {formatDate(review.createdAt)}
                  </p>
                </div>
                <div className="flex gap-1.5">
                  {review.status !== "Approved" && (
                    <Button size="sm" variant="success" onClick={() => void moderate(review, "Approved")}>تأیید</Button>
                  )}
                  {review.status !== "Rejected" && (
                    <Button size="sm" variant="outline" onClick={() => void moderate(review, "Rejected")}>رد</Button>
                  )}
                  <Button
                    size="sm"
                    variant="ghost"
                    className="text-rose-600 hover:bg-rose-50"
                    onClick={() => void remove(review)}
                  >حذف</Button>
                </div>
              </div>
              <p className="mt-3 text-sm leading-relaxed text-slate-700">{review.body}</p>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
