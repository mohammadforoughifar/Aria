"use client";

import { useState } from "react";
import {
  Badge,
  Button,
  Card,
  EmptyState,
  Field,
  Input,
  Modal,
  Pagination,
  SkeletonRows,
  useToast,
} from "@/components/ui";
import { api, useApi } from "@/lib/client/api";
import { formatDate, formatMoney, faNum } from "@/lib/format";
import type { CustomerDto } from "@/shared/contracts";

export default function AdminCustomersPage() {
  const { push } = useToast();
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState("");
  const [editing, setEditing] = useState<CustomerDto | null>(null);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    fullName: "",
    company: "",
    phone: "",
    country: "",
    role: "Customer" as CustomerDto["role"],
    isLocked: false,
  });

  const query = new URLSearchParams({ page: String(page), pageSize: "10" });
  if (search) query.set("search", search);
  const customers = useApi<{ items: CustomerDto[] }>(`/api/customers?${query.toString()}`);

  function start(customer: CustomerDto) {
    setEditing(customer);
    setForm({
      fullName: customer.fullName,
      company: customer.company ?? "",
      phone: customer.phone ?? "",
      country: customer.country ?? "",
      role: customer.role,
      isLocked: false,
    });
  }

  async function save() {
    if (!editing) return;
    setSaving(true);
    try {
      await api.patch(`/api/customers/${editing.id}`, {
        fullName: form.fullName,
        company: form.company || null,
        phone: form.phone || null,
        country: form.country || null,
        role: form.role,
        isLocked: form.isLocked,
      });
      await customers.refresh();
      setEditing(null);
      push({ tone: "success", title: "مشتری به‌روزرسانی شد" });
    } catch (error) {
      push({
        tone: "error",
        title: "ذخیره نشد",
        description: error instanceof Error ? error.message : undefined,
      });
    } finally {
      setSaving(false);
    }
  }

  async function remove(customer: CustomerDto) {
    customers.setData((prev) => (prev ? { items: prev.items.filter((c) => c.id !== customer.id) } : prev));
    try {
      await api.delete(`/api/customers/${customer.id}`);
      push({ tone: "success", title: "مشتری حذف شد" });
    } catch (error) {
      push({
        tone: "error",
        title: "حذف ناموفق بود",
        description: error instanceof Error ? error.message : undefined,
      });
      await customers.refresh();
    }
  }

  const items = customers.data?.items ?? [];

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900">مشتریان</h2>
          <p className="mt-1 text-sm text-slate-600">
            {faNum(customers.meta?.totalCount ?? items.length)} حساب همراه با میزان خرید.
          </p>
        </div>
        <Input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="جستجوی نام، ایمیل یا شرکت…"
          className="max-w-xs"
        />
      </div>

      {customers.loading ? (
        <SkeletonRows rows={8} cols={6} />
      ) : items.length === 0 ? (
        <EmptyState icon="users" title="مشتری پیدا نشد" description="جستجوی دیگری امتحان کنید." />
      ) : (
        <Card padding={false}>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 text-start text-xs font-semibold uppercase tracking-wide text-slate-500">
                <tr>
                  <th className="px-5 py-3">مشتری</th>
                  <th className="px-5 py-3">شرکت</th>
                  <th className="px-5 py-3 text-center">سفارش‌ها</th>
                  <th className="px-5 py-3 text-center">لایسنس‌ها</th>
                  <th className="px-5 py-3 text-end">ارزش کل</th>
                  <th className="px-5 py-3">تاریخ عضویت</th>
                  <th className="px-5 py-3 text-end">عملیات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {items.map((customer) => (
                  <tr key={customer.id} className="hover:bg-slate-50/60">
                    <td className="px-5 py-3">
                      <p className="font-medium text-slate-900">{customer.fullName}</p>
                      <p className="text-xs text-slate-500">{customer.email}</p>
                    </td>
                    <td className="px-5 py-3 text-slate-600">
                      {customer.company ?? "—"}
                      {customer.role === "Admin" && (
                        <Badge tone="violet" className="ms-2">مدیر</Badge>
                      )}
                    </td>
                    <td className="px-5 py-3 text-center text-slate-600">{customer.orderCount}</td>
                    <td className="px-5 py-3 text-center text-slate-600">{customer.licenseCount}</td>
                    <td className="px-5 py-3 text-end font-semibold text-slate-900">
                      {formatMoney(customer.totalSpentCents)}
                    </td>
                    <td className="px-5 py-3 text-slate-600">{formatDate(customer.createdAt)}</td>
                    <td className="px-5 py-3">
                      <div className="flex justify-end gap-1.5">
                        <Button variant="outline" size="sm" onClick={() => start(customer)}>ویرایش</Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-rose-600 hover:bg-rose-50"
                          onClick={() => void remove(customer)}
                          disabled={customer.role === "Admin"}
                        >حذف</Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <Pagination page={customers.meta?.page ?? 1} totalPages={customers.meta?.totalPages ?? 1} onChange={setPage} />
        </Card>
      )}

      <Modal
        open={Boolean(editing)}
        onClose={() => setEditing(null)}
        title={editing ? `Edit ${editing.fullName}` : "Edit customer"}
        description={editing?.email}
        footer={
          <>
            <Button variant="ghost" onClick={() => setEditing(null)}>انصراف</Button>
            <Button loading={saving} onClick={() => void save()} disabled={form.fullName.length < 2}>
              ذخیره تغییرات
            </Button>
          </>
        }
      >
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="نام و نام خانوادگی" required>
            <Input value={form.fullName} onChange={(e) => setForm({ ...form, fullName: e.target.value })} />
          </Field>
          <Field label="شرکت">
            <Input value={form.company} onChange={(e) => setForm({ ...form, company: e.target.value })} />
          </Field>
          <Field label="تلفن">
            <Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
          </Field>
          <Field label="کشور">
            <Input value={form.country} onChange={(e) => setForm({ ...form, country: e.target.value })} />
          </Field>
          <Field label="نقش">
            <select
              value={form.role}
              onChange={(e) => setForm({ ...form, role: e.target.value as CustomerDto["role"] })}
              className="h-10 w-full rounded-lg border border-slate-300 px-3 text-sm"
            >
              <option value="Customer">مشتری</option>
              <option value="Admin">مدیر</option>
            </select>
          </Field>
          <label className="mt-6 flex items-center gap-2 text-sm text-slate-700">
            <input
              type="checkbox"
              checked={form.isLocked}
              onChange={(e) => setForm({ ...form, isLocked: e.target.checked })}
              className="h-4 w-4 rounded border-slate-300"
            />
            قفل حساب (ورود مسدود می‌شود)
          </label>
        </div>
      </Modal>
    </div>
  );
}
