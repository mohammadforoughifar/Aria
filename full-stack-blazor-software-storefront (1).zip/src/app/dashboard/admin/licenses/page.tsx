"use client";

import { useState } from "react";
import {
  Badge,
  Button,
  Card,
  EmptyState,
  Field,
  Input,
  Modal,
  Pagination,
  Select,
  SkeletonRows,
  Tabs,
  statusTone,
  useToast,
} from "@/components/ui";
import { api, useApi } from "@/lib/client/api";
import { formatDate, faNum } from "@/lib/format";
import type { CustomerDto, LicenseDto, ProductListItemDto } from "@/shared/contracts";

export default function AdminLicensesPage() {
  const { push } = useToast();
  const [status, setStatus] = useState("all");
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [busy, setBusy] = useState<string | null>(null);
  const [form, setForm] = useState({ userId: "", productId: "", planId: "", seats: 1, validDays: 365 });

  const query = new URLSearchParams({ page: String(page), pageSize: "10" });
  if (status !== "all") query.set("status", status);
  if (search) query.set("search", search);
  const licenses = useApi<{ items: LicenseDto[] }>(`/api/licenses?${query.toString()}`);
  const customers = useApi<{ items: CustomerDto[] }>(open ? "/api/customers?pageSize=100" : null, [open]);
  const products = useApi<{ items: ProductListItemDto[] }>(
    open ? "/api/products?pageSize=100&includeInactive=true" : null,
    [open],
  );

  async function generate() {
    setSaving(true);
    try {
      await api.post("/api/licenses", {
        userId: form.userId,
        productId: form.productId,
        seats: Number(form.seats),
        validDays: Number(form.validDays),
      });
      setOpen(false);
      await licenses.refresh();
      push({ tone: "success", title: "لایسنس صادر شد" });
    } catch (error) {
      push({
        tone: "error",
        title: "صدور لایسنس ناموفق بود",
        description: error instanceof Error ? error.message : undefined,
      });
    } finally {
      setSaving(false);
    }
  }

  async function act(license: LicenseDto, action: "revoke" | "extend" | "reactivate") {
    setBusy(license.id);
    licenses.setData((prev) =>
      prev
        ? {
            items: prev.items.map((l) =>
              l.id === license.id
                ? {
                    ...l,
                    status: action === "extend" ? "Active" : action === "revoke" ? "Revoked" : "Active",
                    expiresAt:
                      action === "extend" && l.expiresAt
                        ? new Date(new Date(l.expiresAt).getTime() + 365 * 86_400_000).toISOString()
                        : l.expiresAt,
                  }
                : l,
            ),
          }
        : prev,
    );
    try {
      await api.patch(`/api/licenses/${license.id}`, { action, days: 365 });
      push({
        tone: "success",
        title: `License ${action === "extend" ? "extended" : action === "revoke" ? "revoked" : "reactivated"}`,
      });
    } catch (error) {
      await licenses.refresh();
      push({
        tone: "error",
        title: "عملیات ناموفق بود",
        description: error instanceof Error ? error.message : undefined,
      });
    } finally {
      setBusy(null);
    }
  }

  const items = licenses.data?.items ?? [];

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900">مدیریت لایسنس</h2>
          <p className="mt-1 text-sm text-slate-600">
            {faNum(licenses.meta?.totalCount ?? items.length)} لایسنس در کل پلتفرم.
          </p>
        </div>
        <Button onClick={() => setOpen(true)}>صدور لایسنس</Button>
      </div>

      <div className="flex flex-wrap items-center gap-3">
        <Tabs
          tabs={[
            { id: "all", label: "همه" },
            { id: "Active", label: "فعال" },
            { id: "Expired", label: "منقضی" },
            { id: "Revoked", label: "ابطال‌شده" },
          ]}
          active={status}
          onChange={setStatus}
        />
        <Input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="جستجوی کلید، مشتری یا محصول…"
          className="max-w-xs"
        />
      </div>

      {licenses.loading ? (
        <SkeletonRows rows={8} cols={6} />
      ) : items.length === 0 ? (
        <EmptyState
          icon="key"
          title="لایسنسی وجود ندارد"
          description="به‌صورت دستی صادر کنید یا منتظر سفارش‌ها بمانید."
          action={<Button onClick={() => setOpen(true)}>صدور لایسنس</Button>}
        />
      ) : (
        <Card padding={false}>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 text-start text-xs font-semibold uppercase tracking-wide text-slate-500">
                <tr>
                  <th className="px-5 py-3">کلید لایسنس</th>
                  <th className="px-5 py-3">مشتری</th>
                  <th className="px-5 py-3">محصول</th>
                  <th className="px-5 py-3 text-center">کاربران</th>
                  <th className="px-5 py-3">تاریخ انقضا</th>
                  <th className="px-5 py-3">وضعیت</th>
                  <th className="px-5 py-3 text-end">عملیات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {items.map((license) => (
                  <tr key={license.id} className="hover:bg-slate-50/60">
                    <td className="px-5 py-3">
                      <code className="rounded bg-slate-100 px-2 py-1 text-[11px] text-slate-700">
                        {license.licenseKey}
                      </code>
                    </td>
                    <td className="px-5 py-3">
                      <p className="font-medium text-slate-900">{license.customerName}</p>
                      <p className="text-xs text-slate-500">{license.customerEmail}</p>
                    </td>
                    <td className="px-5 py-3 text-slate-600">{license.productName}</td>
                    <td className="px-5 py-3 text-center text-slate-600">
                      {faNum(license.activationsUsed)}/{faNum(license.seats)}
                    </td>
                    <td className="px-5 py-3 text-slate-600">
                      {license.expiresAt ? formatDate(license.expiresAt) : "دائمی"}
                    </td>
                    <td className="px-5 py-3">
                      <Badge tone={statusTone(license.status)}>{license.status}</Badge>
                    </td>
                    <td className="px-5 py-3">
                      <div className="flex justify-end gap-1.5">
                        {license.status === "Revoked" ? (
                          <Button
                            variant="outline"
                            size="sm"
                            loading={busy === license.id}
                            onClick={() => void act(license, "reactivate")}
                          >فعال‌سازی مجدد</Button>
                        ) : (
                          <>
                            <Button
                              variant="outline"
                              size="sm"
                              loading={busy === license.id}
                              onClick={() => void act(license, "extend")}
                            >تمدید</Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="text-rose-600 hover:bg-rose-50"
                              loading={busy === license.id}
                              onClick={() => void act(license, "revoke")}
                            >ابطال</Button>
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <Pagination page={licenses.meta?.page ?? 1} totalPages={licenses.meta?.totalPages ?? 1} onChange={setPage} />
        </Card>
      )}

      <Modal
        open={open}
        onClose={() => setOpen(false)}
        title="صدور لایسنس"
        description="برای تمدیدهای خارج از پلتفرم، جبران خدمات یا استفاده داخلی کاربرد دارد."
        footer={
          <>
            <Button variant="ghost" onClick={() => setOpen(false)}>انصراف</Button>
            <Button loading={saving} onClick={() => void generate()} disabled={!form.userId || !form.productId}>صدور</Button>
          </>
        }
      >
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="مشتری" required className="sm:col-span-2">
            <Select value={form.userId} onChange={(e) => setForm({ ...form, userId: e.target.value })}>
              <option value="">یک مشتری را انتخاب کنید…</option>
              {customers.data?.items.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.fullName} — {c.email}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="محصول" required className="sm:col-span-2">
            <Select value={form.productId} onChange={(e) => setForm({ ...form, productId: e.target.value })}>
              <option value="">یک محصول را انتخاب کنید…</option>
              {products.data?.items.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="کاربران">
            <Input
              type="number"
              value={form.seats}
              onChange={(e) => setForm({ ...form, seats: Number(e.target.value) })}
            />
          </Field>
          <Field label="اعتبار (روز)" hint="۰ = دائمی">
            <Input
              type="number"
              value={form.validDays}
              onChange={(e) => setForm({ ...form, validDays: Number(e.target.value) })}
            />
          </Field>
        </div>
      </Modal>
    </div>
  );
}
