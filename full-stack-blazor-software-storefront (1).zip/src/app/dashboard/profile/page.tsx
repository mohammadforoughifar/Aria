"use client";

import { useEffect, useState } from "react";
import { Badge, Button, Card, Field, Input, SectionTitle, SkeletonRows, useToast } from "@/components/ui";
import { api, useApi, useAuth } from "@/lib/client/api";
import { formatDate } from "@/lib/format";
import type { SiteSettingsDto } from "@/shared/contracts";

export default function ProfilePage() {
  const { user, updateProfile } = useAuth();
  const { push } = useToast();
  const { data: settings } = useApi<SiteSettingsDto>("/api/settings");
  const [form, setForm] = useState({ fullName: "", company: "", phone: "", country: "" });
  const [saving, setSaving] = useState(false);
  const [pwd, setPwd] = useState({ currentPassword: "", newPassword: "", confirm: "" });
  const [pwdSaving, setPwdSaving] = useState(false);

  useEffect(() => {
    if (user) {
      setForm({
        fullName: user.fullName,
        company: user.company ?? "",
        phone: user.phone ?? "",
        country: user.country ?? "",
      });
    }
  }, [user]);

  if (!user) return <SkeletonRows rows={3} cols={2} />;

  async function save() {
    setSaving(true);
    try {
      await updateProfile({
        fullName: form.fullName,
        company: form.company || null,
        phone: form.phone || null,
        country: form.country || null,
      });
      push({ tone: "success", title: "پروفایل به‌روزرسانی شد" });
    } catch (error) {
      push({
        tone: "error",
        title: "ذخیره نشد",
        description: error instanceof Error ? error.message : undefined,
      });
    } finally {
      setSaving(false);
    }
  }

  async function changePassword() {
    if (pwd.newPassword !== pwd.confirm) {
      push({ tone: "error", title: "رمزهای عبور مطابقت ندارند" });
      return;
    }
    setPwdSaving(true);
    try {
      await api.post("/api/auth/change-password", {
        currentPassword: pwd.currentPassword,
        newPassword: pwd.newPassword,
      });
      setPwd({ currentPassword: "", newPassword: "", confirm: "" });
      push({ tone: "success", title: "رمز عبور تغییر کرد" });
    } catch (error) {
      push({
        tone: "error",
        title: "تغییر رمز عبور ناموفق بود",
        description: error instanceof Error ? error.message : undefined,
      });
    } finally {
      setPwdSaving(false);
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-bold tracking-tight text-slate-900">پروفایل و تنظیمات</h2>
        <p className="mt-1 text-sm text-slate-600">اطلاعات حساب و تنظیمات پورتال شما.</p>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <SectionTitle title="اطلاعات حساب" description="روی فاکتورها و پرونده‌های لایسنس استفاده می‌شود" />
          <div className="mt-4 grid gap-4">
            <Field label="نام و نام خانوادگی" required>
              <Input value={form.fullName} onChange={(e) => setForm({ ...form, fullName: e.target.value })} />
            </Field>
            <Field label="ایمیل" hint="برای تغییر ایمیل ورود با پشتیبانی تماس بگیرید">
              <Input value={user.email} disabled />
            </Field>
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="شرکت">
                <Input value={form.company} onChange={(e) => setForm({ ...form, company: e.target.value })} />
              </Field>
              <Field label="کشور">
                <Input value={form.country} onChange={(e) => setForm({ ...form, country: e.target.value })} />
              </Field>
            </div>
            <Field label="تلفن">
              <Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
            </Field>
            <div className="flex items-center justify-between rounded-lg bg-slate-50 px-4 py-3 text-sm">
              <span className="text-slate-600">نقش</span>
              <Badge tone={user.role === "Admin" ? "violet" : "indigo"}>{user.role}</Badge>
            </div>
            <div className="flex items-center justify-between rounded-lg bg-slate-50 px-4 py-3 text-sm">
              <span className="text-slate-600">مشتری از</span>
              <span className="font-medium text-slate-900">{formatDate(user.createdAt)}</span>
            </div>
            <div className="flex justify-end">
              <Button loading={saving} onClick={() => void save()} disabled={form.fullName.length < 2}>
                ذخیره تغییرات
              </Button>
            </div>
          </div>
        </Card>

        <div className="space-y-6">
          <Card>
            <SectionTitle title="تغییر رمز عبور" description="حداقل ۸ کاراکتر" />
            <div className="mt-4 grid gap-4">
              <Field label="رمز عبور فعلی" required>
                <Input
                  type="password"
                  value={pwd.currentPassword}
                  onChange={(e) => setPwd({ ...pwd, currentPassword: e.target.value })}
                />
              </Field>
              <Field label="رمز عبور جدید" required>
                <Input
                  type="password"
                  value={pwd.newPassword}
                  onChange={(e) => setPwd({ ...pwd, newPassword: e.target.value })}
                />
              </Field>
              <Field label="تکرار رمز عبور جدید" required>
                <Input
                  type="password"
                  value={pwd.confirm}
                  onChange={(e) => setPwd({ ...pwd, confirm: e.target.value })}
                />
              </Field>
              <div className="flex justify-end">
                <Button
                  variant="secondary"
                  loading={pwdSaving}
                  onClick={() => void changePassword()}
                  disabled={pwd.currentPassword.length < 8 || pwd.newPassword.length < 8}
                >
                  به‌روزرسانی رمز عبور
                </Button>
              </div>
            </div>
          </Card>

          <Card>
            <SectionTitle title="تنظیمات پورتال" description="مدیریت‌شده توسط مدیر سیستم" />
            <dl className="mt-4 space-y-3 text-sm">
              {[
                ["مدت نسخه آزمایشی", settings ? `${settings.trialDays} days` : "—"],
                ["نرخ مالیات", settings ? `${(settings.taxRateBps / 100).toFixed(1)}%` : "—"],
                ["ایمیل پشتیبانی", settings?.supportEmail ?? "—"],
                ["تلفن پشتیبانی", settings?.supportPhone ?? "—"],
              ].map(([label, value]) => (
                <div key={label} className="flex items-center justify-between">
                  <dt className="text-slate-600">{label}</dt>
                  <dd className="font-medium text-slate-900">{value}</dd>
                </div>
              ))}
            </dl>
            <p className="mt-4 text-xs text-slate-500">
              می‌خواهید این موارد برای سازمان شما تغییر کند؟ تیکتی ثبت کنید تا تیم ما رسیدگی کند.
            </p>
          </Card>
        </div>
      </div>
    </div>
  );
}
