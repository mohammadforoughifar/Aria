"use client";

import Link from "next/link";
import { useState } from "react";
import {
  Badge,
  Button,
  Card,
  EmptyState,
  Modal,
  Pagination,
  SkeletonRows,
  StatCard,
  statusTone,
} from "@/components/ui";
import { api, useApi } from "@/lib/client/api";
import { formatDate, formatMoney, faNum } from "@/lib/format";
import type { InvoiceDto, OrderDto } from "@/shared/contracts";

export default function InvoicesPage() {
  const [page, setPage] = useState(1);
  const [selected, setSelected] = useState<{ invoice: InvoiceDto; order: OrderDto } | null>(null);
  const [opening, setOpening] = useState(false);
  const { data, meta, loading } = useApi<{ items: InvoiceDto[] }>(`/api/invoices?page=${page}&pageSize=10`);

  const invoices = data?.items ?? [];
  const outstanding = invoices.filter((i) => i.status !== "Paid").reduce((s, i) => s + i.totalCents, 0);

  async function open(invoice: InvoiceDto) {
    setOpening(true);
    try {
      const { data: detail } = await api.get<{ invoice: InvoiceDto; order: OrderDto }>(`/api/invoices/${invoice.id}`);
      setSelected(detail);
    } finally {
      setOpening(false);
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-bold tracking-tight text-slate-900">فاکتورها</h2>
        <p className="mt-1 text-sm text-slate-600">
          هر سفارش یک فاکتور تولید می‌کند. برای چاپ یا ذخیره PDF آن را باز کنید.
        </p>
      </div>

      <div className="grid gap-4 sm:grid-cols-3">
        <StatCard label="فاکتورها" value={faNum(meta?.totalCount ?? invoices.length)} icon="📄" tone="indigo" />
        <StatCard
          label="مانده حساب"
          value={formatMoney(outstanding)}
          icon="⏳"
          tone={outstanding ? "amber" : "green"}
        />
        <StatCard
          label="پرداخت‌شده (این صفحه)"
          value={formatMoney(invoices.filter((i) => i.status === "Paid").reduce((s, i) => s + i.totalCents, 0))}
          icon="✅"
          tone="green"
        />
      </div>

      {loading ? (
        <SkeletonRows rows={5} cols={5} />
      ) : invoices.length === 0 ? (
        <EmptyState
          icon="receipt"
          title="هنوز فاکتوری نیست"
          description="فاکتورها به‌طور خودکار هنگام ثبت سفارش صادر می‌شوند."
          action={
            <Link href="/catalog">
              <Button>مشاهده محصولات</Button>
            </Link>
          }
        />
      ) : (
        <Card padding={false}>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 text-start text-xs font-semibold uppercase tracking-wide text-slate-500">
                <tr>
                  <th className="px-5 py-3">فاکتور</th>
                  <th className="px-5 py-3">شماره سفارش</th>
                  <th className="px-5 py-3">تاریخ صدور</th>
                  <th className="px-5 py-3">سررسید</th>
                  <th className="px-5 py-3">وضعیت</th>
                  <th className="px-5 py-3 text-end">مجموع</th>
                  <th className="px-5 py-3" />
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {invoices.map((invoice) => (
                  <tr key={invoice.id} className="hover:bg-slate-50/60">
                    <td className="px-5 py-3 font-mono text-xs text-slate-700">{invoice.invoiceNumber}</td>
                    <td className="px-5 py-3 text-slate-600">{invoice.orderNumber}</td>
                    <td className="px-5 py-3 text-slate-600">{formatDate(invoice.issuedAt)}</td>
                    <td className="px-5 py-3 text-slate-600">{formatDate(invoice.dueAt)}</td>
                    <td className="px-5 py-3">
                      <Badge tone={statusTone(invoice.status)}>{invoice.status}</Badge>
                    </td>
                    <td className="px-5 py-3 text-end font-semibold text-slate-900">
                      {formatMoney(invoice.totalCents)}
                    </td>
                    <td className="px-5 py-3 text-end">
                      <Button variant="outline" size="sm" loading={opening} onClick={() => void open(invoice)}>باز کردن</Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <Pagination page={meta?.page ?? 1} totalPages={meta?.totalPages ?? 1} onChange={setPage} />
        </Card>
      )}

      <Modal
        open={Boolean(selected)}
        onClose={() => setSelected(null)}
        title={selected ? `Invoice ${selected.invoice.invoiceNumber}` : "Invoice"}
        wide
        footer={
          <>
            <Button variant="ghost" onClick={() => setSelected(null)}>بستن</Button>
            <Button onClick={() => window.print()}>چاپ / ذخیره PDF</Button>
          </>
        }
      >
        {selected && (
          <div className="space-y-6 text-sm">
            <div className="flex flex-wrap items-start justify-between gap-4 rounded-xl border border-slate-200 p-5">
              <div>
                <p className="text-lg font-bold text-slate-900">شرکت نورث‌ویند</p>
                <p className="text-xs text-slate-500">هالوسترأت ۴۲، روتردام، هلند</p>
                <p className="text-xs text-slate-500">شناسه مالیاتی NL812345678B01</p>
              </div>
              <div className="text-end">
                <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">فاکتور</p>
                <p className="font-mono text-sm font-semibold text-slate-900">{selected.invoice.invoiceNumber}</p>
                <p className="mt-1 text-xs text-slate-500">تاریخ صدور {formatDate(selected.invoice.issuedAt)}</p>
                <p className="text-xs text-slate-500">تاریخ سررسید {formatDate(selected.invoice.dueAt)}</p>
              </div>
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <div className="rounded-lg bg-slate-50 p-4">
                <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">صورتحساب برای</p>
                <p className="mt-1 font-medium text-slate-900">
                  {selected.order.billingName ?? selected.order.customerName}
                </p>
                <p className="text-slate-600">{selected.order.billingEmail ?? selected.order.customerEmail}</p>
                {selected.order.billingCompany && <p className="text-slate-600">{selected.order.billingCompany}</p>}
                <p className="text-slate-600">{selected.order.billingCountry}</p>
              </div>
              <div className="rounded-lg bg-slate-50 p-4">
                <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">کد سفارش</p>
                <p className="mt-1 font-mono text-sm text-slate-900">{selected.order.orderNumber}</p>
                <p className="text-slate-600">{formatDate(selected.order.placedAt)}</p>
                <Badge tone={statusTone(selected.invoice.status)} className="mt-2">
                  {selected.invoice.status}
                </Badge>
              </div>
            </div>

            <div className="overflow-hidden rounded-lg border border-slate-200">
              <table className="w-full text-sm">
                <thead className="bg-slate-50 text-start text-xs font-semibold uppercase tracking-wide text-slate-500">
                  <tr>
                    <th className="px-4 py-2.5">توضیحات</th>
                    <th className="px-4 py-2.5 text-center">تعداد</th>
                    <th className="px-4 py-2.5 text-end">واحد</th>
                    <th className="px-4 py-2.5 text-end">مبلغ</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {selected.order.items.map((item) => (
                    <tr key={item.id}>
                      <td className="px-4 py-2.5">
                        <p className="font-medium text-slate-900">{item.productName}</p>
                        <p className="text-xs text-slate-500">
                          {item.planName} ·{" "}
                          {item.billingType === "OneTime" ? "perpetual license" : "اشتراک سالانه"}
                        </p>
                      </td>
                      <td className="px-4 py-2.5 text-center">{item.quantity}</td>
                      <td className="px-4 py-2.5 text-end">{formatMoney(item.unitPriceCents)}</td>
                      <td className="px-4 py-2.5 text-end font-medium">{formatMoney(item.lineTotalCents)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="ms-auto max-w-xs space-y-1.5">
              <div className="flex justify-between text-slate-600">
                <span>جمع جزء</span>
                <span>{formatMoney(selected.order.subtotalCents)}</span>
              </div>
              {selected.order.discountCents > 0 && (
                <div className="flex justify-between text-emerald-600">
                  <span>Discount {selected.order.discountCode ? `(${selected.order.discountCode})` : ""}</span>
                  <span>−{formatMoney(selected.order.discountCents)}</span>
                </div>
              )}
              <div className="flex justify-between text-slate-600">
                <span>مالیات</span>
                <span>{formatMoney(selected.order.taxCents)}</span>
              </div>
              <div className="flex justify-between border-t border-slate-200 pt-1.5 text-base font-bold text-slate-900">
                <span>مبلغ قابل پرداخت</span>
                <span>{formatMoney(selected.invoice.totalCents)}</span>
              </div>
            </div>

            <p className="text-xs text-slate-500">
              شرط پرداخت ۱۴ روزه است. اطلاعات انتقال بانکی در صفحه آخر سند چاپی آمده است. سؤالی دارید؟ accounts@northwindsoft.example
            </p>
          </div>
        )}
      </Modal>
    </div>
  );
}
