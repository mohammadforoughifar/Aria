"use client";

import Link from "next/link";
import { useState } from "react";
import {
  Badge,
  Button,
  Card,
  EmptyState,
  Field,
  Input,
  Modal,
  Select,
  SkeletonRows,
  Tabs,
  Textarea,
  statusTone,
  useToast,
} from "@/components/ui";
import { api, useApi, useAuth } from "@/lib/client/api";
import { timeAgo, faNum } from "@/lib/format";
import type { TicketDto } from "@/shared/contracts";

const STATUSES = ["Open", "InProgress", "WaitingCustomer", "Resolved", "Closed"];

export default function TicketsPage() {
  const { user } = useAuth();
  const { push } = useToast();
  const isAdmin = user?.role === "Admin";
  const [status, setStatus] = useState("all");
  const [search, setSearch] = useState("");
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    subject: "",
    category: "Technical",
    priority: "Normal",
    environment: "",
    message: "",
  });

  const query = new URLSearchParams({ page: "1", pageSize: "25" });
  if (status !== "all") query.set("status", status);
  if (search) query.set("search", search);
  const tickets = useApi<{ items: TicketDto[] }>(`/api/tickets?${query.toString()}`);

  async function submit() {
    setSaving(true);
    try {
      await api.post("/api/tickets", { ...form, environment: form.environment || null });
      push({ tone: "success", title: "تیکت ثبت شد" });
      setOpen(false);
      setForm({ subject: "", category: "Technical", priority: "Normal", environment: "", message: "" });
      await tickets.refresh();
    } catch (error) {
      push({
        tone: "error",
        title: "ثبت تیکت ناموفق بود",
        description: error instanceof Error ? error.message : undefined,
      });
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900">
            {isAdmin ? "تیکت‌های پشتیبانی" : "تیکت‌های پشتیبانی من"}
          </h2>
          <p className="mt-1 text-sm text-slate-600">
            {isAdmin ? "همه تیکت‌ها در میان تمام مشتریان." : "گفتگوها با تیم مهندسی ما."}
          </p>
        </div>
        <Button onClick={() => setOpen(true)}>تیکت جدید</Button>
      </div>

      <div className="flex flex-wrap items-center gap-3">
        <Tabs
          tabs={[{ id: "all", label: "همه" }, ...STATUSES.map((s) => ({ id: s, label: s }))]}
          active={status}
          onChange={setStatus}
        />
        <Input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="جستجوی موضوع یا کد پیگیری…"
          className="max-w-xs"
        />
      </div>

      {tickets.loading ? (
        <SkeletonRows rows={6} cols={5} />
      ) : !tickets.data?.items.length ? (
        <EmptyState
          icon="ticket"
          title="تیکتی وجود ندارد"
          description={isAdmin ? "در حال حاضر چیزی در صف نیست." : "چیزی نیاز به بررسی ندارد."}
          action={<Button onClick={() => setOpen(true)}>ثبت تیکت</Button>}
        />
      ) : (
        <Card padding={false}>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 text-start text-xs font-semibold uppercase tracking-wide text-slate-500">
                <tr>
                  <th className="px-5 py-3">کد پیگیری</th>
                  {isAdmin && <th className="px-5 py-3">مشتری</th>}
                  <th className="px-5 py-3">موضوع</th>
                  <th className="px-5 py-3">اولویت</th>
                  <th className="px-5 py-3">وضعیت</th>
                  <th className="px-5 py-3">به‌روزرسانی</th>
                  <th className="px-5 py-3" />
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {tickets.data.items.map((ticket) => (
                  <tr key={ticket.id} className="hover:bg-slate-50/60">
                    <td className="px-5 py-3 font-mono text-xs text-slate-500">{ticket.reference}</td>
                    {isAdmin && (
                      <td className="px-5 py-3">
                        <p className="font-medium text-slate-900">{ticket.customerName}</p>
                        <p className="text-xs text-slate-500">{ticket.customerEmail}</p>
                      </td>
                    )}
                    <td className="px-5 py-3">
                      <Link
                        href={`/dashboard/tickets/${ticket.id}`}
                        className="font-medium text-slate-900 hover:text-indigo-700"
                      >
                        {ticket.subject}
                      </Link>
                      <p className="text-xs text-slate-500">
                        {ticket.productName ?? "عمومی"} · {ticket.category} · {faNum(ticket.messageCount ?? 0)} پیام
                      </p>
                    </td>
                    <td className="px-5 py-3">
                      <Badge tone={ticket.priority === "Critical" ? "red" : ticket.priority === "High" ? "amber" : "slate"}>
                        {ticket.priority}
                      </Badge>
                    </td>
                    <td className="px-5 py-3">
                      <Badge tone={statusTone(ticket.status)}>{ticket.status}</Badge>
                    </td>
                    <td className="px-5 py-3 text-xs text-slate-500">{timeAgo(ticket.updatedAt)}</td>
                    <td className="px-5 py-3 text-end">
                      <Link href={`/dashboard/tickets/${ticket.id}`}>
                        <Button variant="outline" size="sm">باز کردن</Button>
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}

      <Modal
        open={open}
        onClose={() => setOpen(false)}
        title="تیکت پشتیبانی جدید"
        description="مهندسان ما در روزهای کاری تا ۴ ساعت پاسخ می‌دهند."
        footer={
          <>
            <Button variant="ghost" onClick={() => setOpen(false)}>انصراف</Button>
            <Button
              loading={saving}
              onClick={() => void submit()}
              disabled={form.subject.length < 5 || form.message.length < 10}
            >
              ثبت تیکت
            </Button>
          </>
        }
      >
        <div className="grid gap-4">
          <Field label="موضوع" required>
            <Input value={form.subject} onChange={(e) => setForm({ ...form, subject: e.target.value })} />
          </Field>
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="دسته">
              <Select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}>
                {["Technical", "Billing", "Licensing", "Feature Request", "General"].map((c) => (
                  <option key={c}>{c}</option>
                ))}
              </Select>
            </Field>
            <Field label="اولویت">
              <Select value={form.priority} onChange={(e) => setForm({ ...form, priority: e.target.value })}>
                {["Low", "Normal", "High", "Critical"].map((p) => (
                  <option key={p}>{p}</option>
                ))}
              </Select>
            </Field>
          </div>
          <Field label="محیط اجرا" hint="سیستم عامل، نسخه محصول، پایگاه داده">
            <Input value={form.environment} onChange={(e) => setForm({ ...form, environment: e.target.value })} />
          </Field>
          <Field label="توضیح مشکل" required>
            <Textarea value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} rows={5} />
          </Field>
        </div>
      </Modal>
    </div>
  );
}
