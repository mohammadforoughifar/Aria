"use client";

import Link from "next/link";
import { useParams } from "next/navigation";
import { useState } from "react";
import {
  Badge,
  Button,
  Card,
  EmptyState,
  Field,
  Select,
  SkeletonRows,
  Textarea,
  statusTone,
  useToast,
} from "@/components/ui";
import { api, useApi, useAuth } from "@/lib/client/api";
import { formatDateTime, timeAgo, faNum } from "@/lib/format";
import type { TicketDetailDto } from "@/shared/contracts";

export default function TicketDetailPage() {
  const params = useParams<{ id: string }>();
  const { user } = useAuth();
  const { push } = useToast();
  const [reply, setReply] = useState("");
  const [sending, setSending] = useState(false);
  const { data, loading, error, setData } = useApi<TicketDetailDto>(params?.id ? `/api/tickets/${params.id}` : null);

  const isAdmin = user?.role === "Admin";

  async function send() {
    if (!data || reply.trim().length < 2) return;
    setSending(true);
    try {
      const { data: updated } = await api.post<TicketDetailDto>(`/api/tickets/${data.id}/messages`, { body: reply });
      setData(updated);
      setReply("");
      push({ tone: "success", title: "پاسخ ارسال شد" });
    } catch (err) {
      push({
        tone: "error",
        title: "ارسال ناموفق بود",
        description: err instanceof Error ? err.message : undefined,
      });
    } finally {
      setSending(false);
    }
  }

  async function changeStatus(next: string) {
    if (!data) return;
    const previous = data;
    setData({ ...data, status: next as TicketDetailDto["status"] });
    try {
      const { data: updated } = await api.patch<TicketDetailDto>(`/api/tickets/${data.id}`, { status: next });
      setData(updated);
      push({ tone: "success", title: `Status set to ${next}` });
    } catch {
      setData(previous);
      push({ tone: "error", title: "تغییر وضعیت ناموفق بود" });
    }
  }

  if (loading) return <SkeletonRows rows={5} cols={3} />;
  if (error || !data) {
    return (
      <EmptyState
        icon="ticket"
        title="تیکت پیدا نشد"
        description={error ?? undefined}
        action={
          <Link href="/dashboard/tickets">
            <Button variant="outline">بازگشت به تیکت‌ها</Button>
          </Link>
        }
      />
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <Link href="/dashboard/tickets" className="text-xs font-semibold text-indigo-600 hover:text-indigo-500">
            همه تیکت‌ها →
          </Link>
          <h2 className="mt-2 text-xl font-bold tracking-tight text-slate-900">{data.subject}</h2>
          <p className="mt-1 text-sm text-slate-500">
            <span className="font-mono">{data.reference}</span> · opened {formatDateTime(data.createdAt)} ·{" "}
            {data.productName ?? "General"} · {data.category}
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Badge tone={statusTone(data.status)}>{data.status}</Badge>
          <Badge tone={data.priority === "Critical" ? "red" : data.priority === "High" ? "amber" : "slate"}>
            {data.priority}
          </Badge>
          {isAdmin && (
            <Select value={data.status} onChange={(e) => void changeStatus(e.target.value)} className="w-48">
              {["Open", "InProgress", "WaitingCustomer", "Resolved", "Closed"].map((s) => (
                <option key={s}>{s}</option>
              ))}
            </Select>
          )}
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-[1fr_300px]">
        <Card padding={false}>
          <ul className="divide-y divide-slate-100">
            {data.messages.map((message) => (
              <li key={message.id} className="px-5 py-4">
                <div className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-2">
                    <span
                      className={
                        message.isStaff
                          ? "flex h-8 w-8 items-center justify-center rounded-full bg-indigo-100 text-xs font-bold text-indigo-700"
                          : "flex h-8 w-8 items-center justify-center rounded-full bg-slate-200 text-xs font-bold text-slate-700"
                      }
                    >
                      {message.authorName.slice(0, 2).toUpperCase()}
                    </span>
                    <div>
                      <p className="text-sm font-semibold text-slate-900">{message.authorName}</p>
                      <p className="text-[11px] text-slate-500">{timeAgo(message.createdAt)}</p>
                    </div>
                    {message.isStaff && <Badge tone="indigo">پشتیبانی</Badge>}
                  </div>
                </div>
                <p className="mt-3 whitespace-pre-wrap text-sm leading-relaxed text-slate-700">{message.body}</p>
              </li>
            ))}
          </ul>
          <div className="border-t border-slate-200 bg-slate-50 p-5">
            <Field label={isAdmin ? "پاسخ به‌عنوان پشتیبانی" : "Reply"}>
              <Textarea value={reply} onChange={(e) => setReply(e.target.value)} rows={4} placeholder="پاسخ خود را بنویسید…" />
            </Field>
            <div className="mt-3 flex justify-end">
              <Button loading={sending} onClick={() => void send()} disabled={reply.trim().length < 2}>
                ارسال پاسخ
              </Button>
            </div>
          </div>
        </Card>

        <div className="space-y-4">
          <Card>
            <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">مشتری</p>
            <p className="mt-2 text-sm font-semibold text-slate-900">{data.customerName}</p>
            <p className="text-xs text-slate-500">{data.customerEmail}</p>
          </Card>
          <Card>
            <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">محیط اجرا</p>
            <p className="mt-2 text-sm text-slate-600">{data.environment ?? "ارائه نشده"}</p>
          </Card>
          <Card>
            <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">خط زمانی</p>
            <ul className="mt-2 space-y-2 text-xs text-slate-500">
              <li>ایجاد شده {formatDateTime(data.createdAt)}</li>
              <li>آخرین به‌روزرسانی {formatDateTime(data.updatedAt)}</li>
              <li>{faNum(data.messages.length)} پیام</li>
            </ul>
          </Card>
        </div>
      </div>
    </div>
  );
}
