"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState, type ReactNode } from "react";
import { Badge, Button, SkeletonStats, cn } from "@/components/ui";
import { useAuth, useCart } from "@/lib/client/api";
import { initials } from "@/lib/format";

const CUSTOMER_NAV = [
  { href: "/dashboard", label: "نمای کلی", icon: "🏠" },
  { href: "/dashboard/orders", label: "سفارش‌های من", icon: "🧾" },
  { href: "/dashboard/licenses", label: "لایسنس‌های من", icon: "🔑" },
  { href: "/dashboard/downloads", label: "دانلودها", icon: "⬇️" },
  { href: "/dashboard/invoices", label: "فاکتورها", icon: "📄" },
  { href: "/dashboard/tickets", label: "تیکت‌های پشتیبانی", icon: "🎫" },
  { href: "/dashboard/profile", label: "پروفایل و تنظیمات", icon: "⚙️" },
];

const ADMIN_NAV = [
  { href: "/dashboard/admin", label: "نمای کلی", icon: "📊" },
  { href: "/dashboard/admin/products", label: "محصولات", icon: "📦" },
  { href: "/dashboard/admin/categories", label: "دسته‌بندی‌ها", icon: "🗂️" },
  { href: "/dashboard/admin/orders", label: "سفارش‌ها", icon: "🧾" },
  { href: "/dashboard/admin/customers", label: "مشتریان", icon: "👥" },
  { href: "/dashboard/admin/licenses", label: "لایسنس‌ها", icon: "🔑" },
  { href: "/dashboard/admin/discounts", label: "کدهای تخفیف", icon: "🏷️" },
  { href: "/dashboard/tickets", label: "تیکت‌های پشتیبانی", icon: "🎫" },
  { href: "/dashboard/admin/reviews", label: "نظرات", icon: "⭐" },
  { href: "/dashboard/admin/settings", label: "تنظیمات سایت", icon: "⚙️" },
];

export default function DashboardLayout({ children }: { children: ReactNode }) {
  const { user, status, logout } = useAuth();
  const { cart } = useCart();
  const pathname = usePathname();
  const router = useRouter();
  const [navOpen, setNavOpen] = useState(false);

  useEffect(() => {
    if (status === "anonymous") router.replace("/login?redirect=/dashboard");
  }, [status, router]);

  useEffect(() => {
    setNavOpen(false);
  }, [pathname]);

  if (status === "loading" || !user) {
    return (
      <div className="min-h-screen bg-slate-50 p-6">
        <div className="mx-auto max-w-7xl space-y-6">
          <div className="h-14 w-64 animate-pulse rounded-xl bg-slate-200" />
          <SkeletonStats count={4} />
          <div className="h-64 animate-pulse rounded-xl bg-slate-200" />
        </div>
      </div>
    );
  }

  const nav = user.role === "Admin" ? ADMIN_NAV : CUSTOMER_NAV;
  const title =
    nav.find((item) => item.href === pathname)?.label ??
    (pathname.startsWith("/dashboard/admin")
      ? "مدیریت"
      : pathname.startsWith("/dashboard/tickets")
        ? "تیکت‌های پشتیبانی"
        : "داشبورد");

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="sticky top-0 z-30 border-b border-slate-200 bg-white">
        <div className="flex h-16 items-center gap-3 px-4 sm:px-6">
          <button
            onClick={() => setNavOpen((v) => !v)}
            className="flex h-10 w-10 items-center justify-center rounded-lg text-slate-600 transition hover:bg-slate-100 lg:hidden"
            aria-label="باز و بسته کردن منو"
          >
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className="h-5 w-5">
              <path d="M4 7h16M4 12h16M4 17h16" />
            </svg>
          </button>
          <Link href="/" className="flex items-center gap-2.5">
            <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-600 to-violet-500 text-sm font-black text-white">
              NW
            </span>
            <span className="hidden text-sm font-bold text-slate-900 sm:block">
              {user.role === "Admin" ? "کنسول مدیریت" : "پورتال مشتری"}
            </span>
          </Link>
          <h1 className="ms-4 hidden text-sm font-semibold text-slate-500 lg:block">{title}</h1>
          <div className="ms-auto flex items-center gap-2">
            <Link
              href="/cart"
              className="relative flex h-10 items-center rounded-lg px-3 text-sm font-medium text-slate-600 transition hover:bg-slate-100"
            >
              🛒
              {cart?.itemCount ? (
                <span className="absolute end-1 top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-indigo-600 px-1 text-[10px] font-bold text-white">
                  {cart.itemCount}
                </span>
              ) : null}
            </Link>
            <Link
              href="/"
              className="hidden h-10 items-center rounded-lg px-3 text-sm font-medium text-slate-600 transition hover:bg-slate-100 sm:flex"
            >فروشگاه</Link>
            <div className="flex items-center gap-2 rounded-lg border border-slate-200 py-1 ps-1 pe-2">
              <span className="flex h-8 w-8 items-center justify-center rounded-md bg-gradient-to-br from-indigo-500 to-violet-500 text-xs font-bold text-white">
                {initials(user.fullName)}
              </span>
              <div className="hidden leading-tight sm:block">
                <p className="text-xs font-semibold text-slate-900">{user.fullName}</p>
                <p className="text-[11px] text-slate-500">{user.email}</p>
              </div>
              {user.role === "Admin" && <Badge tone="violet">مدیر</Badge>}
            </div>
            <Button variant="ghost" size="sm" onClick={() => void logout()}>
              خروج
            </Button>
          </div>
        </div>
      </header>

      <div className="flex">
        <aside
          className={cn(
            "fixed inset-y-16 start-0 z-20 w-64 overflow-y-auto border-e border-slate-200 bg-white px-3 py-4 transition-transform lg:sticky lg:top-16 lg:h-[calc(100vh-4rem)] lg:translate-x-0",
            navOpen ? "translate-x-0" : "translate-x-full",
          )}
        >
          <nav className="space-y-1">
            {user.role === "Admin" && (
              <p className="px-3 pb-1 pt-2 text-[11px] font-bold uppercase tracking-wider text-slate-400">مدیریت</p>
            )}
            {nav.map((item) => {
              const active = item.href === "/dashboard" ? pathname === "/dashboard" : pathname.startsWith(item.href);
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={cn(
                    "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition",
                    active ? "bg-indigo-50 text-indigo-700" : "text-slate-600 hover:bg-slate-100 hover:text-slate-900",
                  )}
                >
                  <span className="text-base">{item.icon}</span>
                  {item.label}
                </Link>
              );
            })}
            {user.role === "Customer" && (
              <>
                <p className="px-3 pb-1 pt-4 text-[11px] font-bold uppercase tracking-wider text-slate-400">فروشگاه</p>
                <Link
                  href="/catalog"
                  className="flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium text-slate-600 transition hover:bg-slate-100 hover:text-slate-900"
                >
                  <span className="text-base">🛍️</span>مشاهده محصولات</Link>
                <Link
                  href="/support"
                  className="flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium text-slate-600 transition hover:bg-slate-100 hover:text-slate-900"
                >
                  <span className="text-base">🆘</span>دانشنامه</Link>
              </>
            )}
          </nav>
        </aside>

        {navOpen && (
          <button
            aria-label="بستن منو"
            className="fixed inset-0 z-10 bg-slate-900/30 lg:hidden"
            onClick={() => setNavOpen(false)}
          />
        )}

        <main className="min-w-0 flex-1 px-4 py-6 sm:px-6 lg:px-8">{children}</main>
      </div>
    </div>
  );
}
