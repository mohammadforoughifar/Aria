"use client";

import Link from "next/link";
import { useState } from "react";
import { Badge, Button, Card, EmptyState, SectionTitle, SkeletonRows, Tabs, useToast } from "@/components/ui";
import { api, useApi } from "@/lib/client/api";
import { formatDate, formatSize, timeAgo, faNum } from "@/lib/format";
import type { AvailableDownloadDto, DownloadDto } from "@/shared/contracts";

export default function DownloadsPage() {
  const { push } = useToast();
  const [tab, setTab] = useState("available");
  const available = useApi<{ items: AvailableDownloadDto[] }>("/api/downloads/available");
  const history = useApi<{ items: DownloadDto[] }>(tab === "history" ? "/api/downloads" : null, [tab]);

  async function download(product: AvailableDownloadDto, version: AvailableDownloadDto["versions"][number]) {
    try {
      const { data } = await api.post<{ manifest: { چک‌سام: string } }>("/api/downloads", {
        productId: product.productId,
        versionId: version.id,
        kind: product.licensed ? "installer" : "trial",
        fileName: `${product.productSlug}-${version.version}-setup.exe`,
        sizeMb: version.sizeMb,
      });
      push({
        tone: "success",
        title: `Downloading ${version.fileName}`,
        description: `Checksum ${data.manifest.چک‌سام} · ${formatSize(version.sizeMb)}`,
      });
      if (tab === "history") await history.refresh();
    } catch (error) {
      push({
        tone: "error",
        title: "دانلود ناموفق بود",
        description: error instanceof Error ? error.message : undefined,
      });
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-bold tracking-tight text-slate-900">دانلودها</h2>
        <p className="mt-1 text-sm text-slate-600">
          نصب‌کننده‌ها، نسخه‌های پیشین و راهنماها برای همه چیزهایی که به آن دسترسی دارید.
        </p>
      </div>

      <Tabs
        tabs={[
          { id: "available", label: "دانلودهای موجود" },
          { id: "history", label: "تاریخچه دانلود" },
        ]}
        active={tab}
        onChange={setTab}
      />

      {tab === "available" ? (
        available.loading ? (
          <SkeletonRows rows={6} cols={4} />
        ) : !available.data?.items.length ? (
          <EmptyState
            icon="download"
            title="هنوز چیزی برای دانلود نیست"
            description="یک محصول بخرید یا نسخه آزمایشی شروع کنید تا دانلودها اینجا نمایش داده شوند."
          />
        ) : (
          <div className="space-y-4">
            {available.data.items.map((product) => (
              <Card key={product.productId} padding={false}>
                <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 px-5 py-4">
                  <div className="flex items-center gap-3">
                    <span
                      className="flex h-10 w-10 items-center justify-center rounded-xl text-lg"
                      style={{ background: `${product.accentColor}1a`, color: product.accentColor }}
                    >
                      ⬇️
                    </span>
                    <div>
                      <Link
                        href={`/products/${product.productSlug}`}
                        className="text-sm font-semibold text-slate-900 hover:text-indigo-700"
                      >
                        {product.productName}
                      </Link>
                      <p className="text-xs text-slate-500">
                        {faNum(product.versions.length)} نسخه موجود است
                      </p>
                    </div>
                  </div>
                  <Badge tone={product.licensed ? "green" : "amber"}>
                    {product.licensed ? "دارای لایسنس" : "فقط آزمایشی"}
                  </Badge>
                </div>
                <ul className="divide-y divide-slate-100">
                  {product.versions.map((version) => (
                    <li key={version.id} className="flex flex-wrap items-center gap-3 px-5 py-3.5">
                      <div className="min-w-48 flex-1">
                        <p className="text-sm font-medium text-slate-900">
                          v{version.version}
                          <span className="ms-2 text-xs font-normal text-slate-500">{version.platform}</span>
                        </p>
                        <p className="mt-0.5 line-clamp-1 text-xs text-slate-500">{version.notes}</p>
                      </div>
                      <span className="text-xs text-slate-500">{formatDate(version.releasedAt)}</span>
                      <span className="text-xs text-slate-500">{formatSize(version.sizeMb)}</span>
                      <Button variant="outline" size="sm" onClick={() => void download(product, version)}>
                        {product.licensed ? "دانلود" : "دانلود نسخه آزمایشی"}
                      </Button>
                    </li>
                  ))}
                </ul>
              </Card>
            ))}
          </div>
        )
      ) : history.loading ? (
        <SkeletonRows rows={6} cols={4} />
      ) : !history.data?.items.length ? (
        <EmptyState icon="download" title="هنوز دانلودی انجام نشده" description="تاریخچه دانلودهای شما در اینجا نمایش داده می‌شود." />
      ) : (
        <Card padding={false}>
          <div className="border-b border-slate-100 px-5 py-4">
            <SectionTitle title="دانلودهای اخیر" description="۵۰ فایل آخر" />
          </div>
          <ul className="divide-y divide-slate-100">
            {history.data.items.map((item) => (
              <li key={item.id} className="flex flex-wrap items-center gap-3 px-5 py-3.5">
                <div className="min-w-48 flex-1">
                  <p className="text-sm font-medium text-slate-900">{item.fileName}</p>
                  <p className="text-xs text-slate-500">
                    {item.productName} · {item.kind}
                  </p>
                </div>
                <span className="text-xs text-slate-500">{formatSize(item.sizeMb)}</span>
                <span className="text-xs text-slate-500">{timeAgo(item.downloadedAt)}</span>
              </li>
            ))}
          </ul>
        </Card>
      )}
    </div>
  );
}
