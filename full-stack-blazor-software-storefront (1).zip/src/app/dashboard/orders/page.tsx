"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import {
  Badge,
  Button,
  Card,
  EmptyState,
  Input,
  Modal,
  Pagination,
  SkeletonRows,
  Tabs,
  statusTone,
} from "@/components/ui";
import { api, useApi } from "@/lib/client/api";
import { formatDate, formatMoney } from "@/lib/format";
import type { OrderDto } from "@/shared/contracts";

const STATUS_TABS = ["all", "Paid", "Processing", "Completed", "Refunded"];

export default function CustomerOrdersPage() {
  const [status, setStatus] = useState("all");
  const [search, setSearch] = useState("");
  const [debounced, setDebounced] = useState("");
  const [page, setPage] = useState(1);
  const [detail, setDetail] = useState<OrderDto | null>(null);
  const [loadingDetail, setLoadingDetail] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setDebounced(search), 350);
    return () => clearTimeout(timer);
  }, [search]);

  const query = useMemo(() => {
    const qs = new URLSearchParams({ page: String(page), pageSize: "10" });
    if (status !== "all") qs.set("status", status);
    if (debounced) qs.set("search", debounced);
    return qs.toString();
  }, [status, debounced, page]);

  const { data, meta, loading, error } = useApi<{ items: OrderDto[] }>(`/api/orders?${query}`);

  async function openOrder(id: string) {
    setLoadingDetail(true);
    try {
      const { data: order } = await api.get<OrderDto>(`/api/orders/${id}`);
      setDetail(order);
    } finally {
      setLoadingDetail(false);
    }
  }

  const orders = data?.items ?? [];

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900">سفارش‌های من</h2>
          <p className="mt-1 text-sm text-slate-600">
            هر خرید، فاکتور آن و لایسنس‌های صادرشده برای آن.
          </p>
        </div>
        <Link href="/catalog">
          <Button variant="outline">خرید لایسنس دیگر</Button>
        </Link>
      </div>

      <div className="flex flex-wrap items-center gap-3">
        <Tabs
          tabs={STATUS_TABS.map((s) => ({ id: s, label: s === "all" ? "All" : s }))}
          active={status}
          onChange={(id) => {
            setStatus(id);
            setPage(1);
          }}
        />
        <Input
          value={search}
          onChange={(e) => {
            setSearch(e.target.value);
            setPage(1);
          }}
          placeholder="جستجوی شماره سفارش…"
          className="max-w-xs"
        />
      </div>

      {loading ? (
        <SkeletonRows rows={6} cols={5} />
      ) : error ? (
        <EmptyState title="سفارش‌ها بارگذاری نشدند" description={error} />
      ) : orders.length === 0 ? (
        <EmptyState
          icon="receipt"
          title="هنوز سفارشی ثبت نشده"
          description="خریدهای شما همراه با فاکتور و کلید لایسنس در اینجا نمایش داده می‌شوند."
          action={
            <Link href="/catalog">
              <Button>مشاهده محصولات</Button>
            </Link>
          }
        />
      ) : (
        <Card padding={false}>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 text-start text-xs font-semibold uppercase tracking-wide text-slate-500">
                <tr>
                  <th className="px-5 py-3">شماره سفارش</th>
                  <th className="px-5 py-3">تاریخ</th>
                  <th className="px-5 py-3">محصولات</th>
                  <th className="px-5 py-3">وضعیت</th>
                  <th className="px-5 py-3 text-end">مجموع</th>
                  <th className="px-5 py-3" />
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {orders.map((order) => (
                  <tr key={order.id} className="hover:bg-slate-50/60">
                    <td className="px-5 py-3 font-mono text-xs text-slate-700">{order.orderNumber}</td>
                    <td className="px-5 py-3 text-slate-600">{formatDate(order.placedAt)}</td>
                    <td className="px-5 py-3 text-slate-600">{order.items.map((i) => i.productName).join(", ")}</td>
                    <td className="px-5 py-3">
                      <Badge tone={statusTone(order.status)}>{order.status}</Badge>
                    </td>
                    <td className="px-5 py-3 text-end font-semibold text-slate-900">
                      {formatMoney(order.totalCents)}
                    </td>
                    <td className="px-5 py-3 text-end">
                      <Button variant="outline" size="sm" loading={loadingDetail && !detail} onClick={() => void openOrder(order.id)}>مشاهده</Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <Pagination page={meta?.page ?? 1} totalPages={meta?.totalPages ?? 1} totalCount={meta?.totalCount} onChange={setPage} />
        </Card>
      )}

      <Modal
        open={Boolean(detail)}
        onClose={() => setDetail(null)}
        title={detail ? `Order ${detail.orderNumber}` : "Order"}
        description={detail ? `${formatDate(detail.placedAt)} · ${detail.status}` : undefined}
        wide
        footer={
          <Button variant="ghost" onClick={() => setDetail(null)}>بستن</Button>
        }
      >
        {detail && (
          <div className="space-y-6">
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="rounded-lg bg-slate-50 p-4 text-sm">
                <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">صورتحساب برای</p>
                <p className="mt-1 font-medium text-slate-900">{detail.billingName ?? detail.customerName}</p>
                <p className="text-slate-600">{detail.billingEmail ?? detail.customerEmail}</p>
                {detail.billingCompany && <p className="text-slate-600">{detail.billingCompany}</p>}
                {detail.billingCountry && <p className="text-slate-600">{detail.billingCountry}</p>}
              </div>
              <div className="rounded-lg bg-slate-50 p-4 text-sm">
                <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">پرداخت</p>
                <p className="mt-1 flex items-center gap-2 font-medium text-slate-900">
                  <Badge tone={statusTone(detail.status)}>{detail.status}</Badge>
                </p>
                {detail.discountCode && <p className="mt-1 text-slate-600">تخفیف: {detail.discountCode}</p>}
                {detail.notes && <p className="mt-1 text-slate-600">یادداشت: {detail.notes}</p>}
              </div>
            </div>

            <div className="overflow-hidden rounded-lg border border-slate-200">
              <table className="w-full text-sm">
                <thead className="bg-slate-50 text-start text-xs font-semibold uppercase tracking-wide text-slate-500">
                  <tr>
                    <th className="px-4 py-2.5">محصول</th>
                    <th className="px-4 py-2.5">پلن</th>
                    <th className="px-4 py-2.5 text-center">تعداد</th>
                    <th className="px-4 py-2.5 text-end">واحد</th>
                    <th className="px-4 py-2.5 text-end">مجموع</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {detail.items.map((item) => (
                    <tr key={item.id}>
                      <td className="px-4 py-2.5 font-medium text-slate-900">{item.productName}</td>
                      <td className="px-4 py-2.5 text-slate-600">
                        {item.planName}
                        <span className="block text-xs text-slate-400">
                          {item.billingType === "OneTime" ? "دائمی" : "سالانه"}
                        </span>
                      </td>
                      <td className="px-4 py-2.5 text-center text-slate-600">{item.quantity}</td>
                      <td className="px-4 py-2.5 text-end text-slate-600">{formatMoney(item.unitPriceCents)}</td>
                      <td className="px-4 py-2.5 text-end font-semibold text-slate-900">
                        {formatMoney(item.lineTotalCents)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="ms-auto max-w-xs space-y-1.5 text-sm">
              <div className="flex justify-between text-slate-600">
                <span>جمع جزء</span>
                <span>{formatMoney(detail.subtotalCents)}</span>
              </div>
              {detail.discountCents > 0 && (
                <div className="flex justify-between text-emerald-600">
                  <span>تخفیف</span>
                  <span>−{formatMoney(detail.discountCents)}</span>
                </div>
              )}
              <div className="flex justify-between text-slate-600">
                <span>مالیات</span>
                <span>{formatMoney(detail.taxCents)}</span>
              </div>
              <div className="flex justify-between border-t border-slate-200 pt-1.5 text-base font-bold text-slate-900">
                <span>مجموع</span>
                <span>{formatMoney(detail.totalCents)}</span>
              </div>
            </div>

            <div className="flex flex-wrap gap-2">
              <Link href="/dashboard/licenses">
                <Button size="sm">مشاهده کلیدهای لایسنس</Button>
              </Link>
              <Link href="/dashboard/invoices">
                <Button size="sm" variant="outline">
                  دریافت فاکتور
                </Button>
              </Link>
              <Link href="/dashboard/downloads">
                <Button size="sm" variant="outline">
                  دانلود نصب‌کننده‌ها
                </Button>
              </Link>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
