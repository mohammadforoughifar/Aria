"use client";

import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useState } from "react";
import { Button, Card, Field, Input, useToast } from "@/components/ui";
import { useAuth } from "@/lib/client/api";

function LoginInner() {
  const router = useRouter();
  const params = useSearchParams();
  const { login } = useAuth();
  const { push } = useToast();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const redirect = params.get("redirect") ?? "/dashboard";

  async function submit(e?: React.FormEvent) {
    e?.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const user = await login(email, password);
      push({ tone: "success", title: `خوش آمدید, ${user.fullName.split(" ")[0]}` });
      router.push(user.role === "Admin" ? "/dashboard/admin" : redirect);
    } catch (err) {
      setError(err instanceof Error ? err.message : "ورود failed");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="flex min-h-screen">
      <div className="hidden flex-1 flex-col justify-between bg-slate-900 p-12 text-slate-300 lg:flex">
        <Link href="/" className="flex items-center gap-2.5">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-500 to-violet-500 text-sm font-black text-white">
            NW
          </span>
          <span className="text-base font-bold text-white">نورث‌ویند</span>
        </Link>
        <div>
          <h2 className="text-3xl font-bold leading-tight text-white">
            لایسنس‌ها، فاکتورها و دانلودهای شما در یک‌جا.
          </h2>
          <p className="mt-4 max-w-md text-sm leading-relaxed">
            پورتال مشتری دسترسی فوری به کلیدهای لایسنس، آرشیو نصب‌کننده برای هر نسخه‌ای که به آن دسترسی دارید، فاکتورهای حسابداری و ارتباط مستقیم با مهندسان محصول می‌دهد.
          </p>
          <div className="mt-8 grid grid-cols-3 gap-4">
            {[
              { label: "نصب‌کننده‌ها", value: "همه نسخه‌ها" },
              { label: "فاکتورها", value: "آماده PDF" },
              { label: "لایسنس‌ها", value: "خودخدمت" },
            ].map((item) => (
              <div key={item.label} className="rounded-xl bg-white/5 p-4 ring-1 ring-inset ring-white/10">
                <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">{item.label}</p>
                <p className="mt-1 text-sm font-semibold text-white">{item.value}</p>
              </div>
            ))}
          </div>
        </div>
        <p className="text-xs text-slate-500">© {new Date().getFullYear()} Northwind Software Ltd.</p>
      </div>

      <div className="flex flex-1 items-center justify-center bg-slate-50 px-4 py-12 sm:px-6">
        <div className="w-full max-w-md">
          <Link href="/" className="mb-6 inline-flex items-center gap-2 text-sm text-slate-500 hover:text-slate-800 lg:hidden">
            بازگشت به فروشگاه →
          </Link>
          <Card className="p-7">
            <h1 className="text-2xl font-bold tracking-tight text-slate-900">ورود</h1>
            <p className="mt-1.5 text-sm text-slate-600">
              کاربر جدید هستید؟{" "}
              <Link
                href={`/register${redirect ? `?redirect=${redirect}` : ""}`}
                className="font-semibold text-indigo-600 hover:text-indigo-500"
              >ایجاد حساب کاربری</Link>
            </p>

            <form onSubmit={submit} className="mt-6 space-y-4">
              <Field label="ایمیل" required>
                <Input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@company.com"
                  autoComplete="email"
                />
              </Field>
              <Field label="رمز عبور" required>
                <Input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  autoComplete="current-password"
                />
              </Field>
              {error && (
                <p className="rounded-lg border border-rose-200 bg-rose-50 px-3 py-2 text-sm text-rose-700">{error}</p>
              )}
              <Button type="submit" className="w-full" size="lg" loading={loading}>
                ورود
              </Button>
            </form>

            <div className="mt-6 rounded-xl border border-dashed border-indigo-300 bg-indigo-50/60 p-4">
              <p className="text-xs font-semibold uppercase tracking-wide text-indigo-700">حساب‌های نمایشی</p>
              <div className="mt-2 space-y-1.5 text-sm text-indigo-900">
                {[
                  { label: "مدیر", email: "admin@northwindsoft.example" },
                  { label: "مشتری", email: "casey.demo@example.com" },
                ].map((account) => (
                  <button
                    key={account.email}
                    onClick={() => {
                      setEmail(account.email);
                      setPassword("Password123!");
                    }}
                    className="block w-full rounded-lg bg-white px-3 py-2 text-start ring-1 ring-inset ring-indigo-200 transition hover:bg-indigo-100"
                  >
                    <span className="font-semibold">{account.label}</span> · {account.email}
                  </button>
                ))}
                <p className="pt-1 text-xs text-indigo-700/80">
                  رمز عبور هر دو: <span className="font-mono">Password123!</span>
                </p>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}

export default function LoginPage() {
  return (
    <Suspense fallback={<div className="flex min-h-screen items-center justify-center">در حال بارگذاری…</div>}>
      <LoginInner />
    </Suspense>
  );
}
