/**
 * Shared contracts (the equivalent of Project.Shared): DTOs and the API
 * response envelope used by both the HTTP API and the browser client.
 * Domain entities are never exposed over the wire.
 */

export type Role = "Admin" | "Customer";
export type ProductType = "Module" | "DesktopApp" | "AddOn";
export type PlanTier = "SingleUser" | "MultiUser" | "Enterprise";
export type BillingType = "OneTime" | "Annual";
export type OrderStatus = "Pending" | "Paid" | "Processing" | "Completed" | "Refunded" | "Cancelled";
export type LicenseStatus = "Active" | "Expired" | "Revoked";
export type TicketStatus = "Open" | "InProgress" | "WaitingCustomer" | "Resolved" | "Closed";
export type TicketPriority = "Low" | "Normal" | "High" | "Critical";
export type ReviewStatus = "Pending" | "Approved" | "Rejected";

export interface ApiEnvelope<T> {
  success: boolean;
  data: T;
  meta?: PagedMeta;
  error?: ApiError;
}

export interface PagedMeta {
  page: number;
  pageSize: number;
  totalCount: number;
  totalPages: number;
}

export interface ApiError {
  code: string;
  message: string;
  details?: Record<string, string[]>;
}

export interface UserDto {
  id: string;
  email: string;
  fullName: string;
  role: Role;
  company: string | null;
  phone: string | null;
  country: string | null;
  createdAt: string;
  lastLoginAt: string | null;
}

export interface AuthResultDto {
  user: UserDto;
  accessToken: string;
  expiresIn: number;
}

export interface CategoryDto {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  icon: string;
  sortOrder: number;
  isActive: boolean;
  productCount?: number;
}

export interface PlanDto {
  id: string;
  productId: string;
  name: string;
  tier: PlanTier;
  billingType: BillingType;
  priceCents: number;
  seats: number;
  description: string | null;
  isPopular: boolean;
  sortOrder: number;
}

export interface ProductVersionDto {
  id: string;
  productId: string;
  version: string;
  releasedAt: string;
  notes: string;
  installerUrl: string | null;
  sizeMb: number;
  platform: string;
}

export interface ProductListItemDto {
  id: string;
  slug: string;
  name: string;
  tagline: string;
  type: ProductType;
  platform: string;
  version: string;
  basePriceCents: number;
  ratingAvg: number;
  ratingCount: number;
  popularity: number;
  heroImage: string | null;
  accentColor: string;
  isFeatured: boolean;
  isActive: boolean;
  createdAt: string;
  categoryName: string;
  categorySlug: string;
}

export interface ProductDetailDto extends ProductListItemDto {
  description: string;
  gallery: string[];
  features: string[];
  systemRequirements: string[];
  demoVideoUrl: string | null;
  trialDays: number;
  categoryId: string;
  plans: PlanDto[];
  versions: ProductVersionDto[];
}

export interface ReviewDto {
  id: string;
  productId: string;
  productName?: string;
  authorName: string;
  authorCompany: string | null;
  rating: number;
  title: string;
  body: string;
  status: ReviewStatus;
  createdAt: string;
}

export interface CartItemDto {
  id: string;
  planId: string;
  quantity: number;
  productId: string;
  productName: string;
  productSlug: string;
  planName: string;
  tier: PlanTier;
  billingType: BillingType;
  accentColor: string;
  unitPriceCents: number;
  lineTotalCents: number;
}

export interface CartDto {
  items: CartItemDto[];
  subtotalCents: number;
  itemCount: number;
  discountCents: number;
  discountCode: string | null;
  taxCents: number;
  totalCents: number;
  taxRateBps: number;
}

export interface OrderItemDto {
  id: string;
  productId: string | null;
  planId: string | null;
  productName: string;
  planName: string;
  billingType: BillingType;
  unitPriceCents: number;
  quantity: number;
  lineTotalCents: number;
}

export interface OrderDto {
  id: string;
  orderNumber: string;
  userId: string;
  customerName: string;
  customerEmail: string;
  customerCompany: string | null;
  status: OrderStatus;
  subtotalCents: number;
  discountCents: number;
  taxCents: number;
  totalCents: number;
  currency: string;
  discountCode: string | null;
  placedAt: string;
  billingName: string | null;
  billingCompany: string | null;
  billingEmail: string | null;
  billingCountry: string | null;
  notes: string | null;
  items: OrderItemDto[];
}

export interface InvoiceDto {
  id: string;
  invoiceNumber: string;
  orderId: string;
  orderNumber: string;
  customerName: string;
  customerEmail: string;
  status: "Draft" | "Issued" | "Paid" | "Void";
  issuedAt: string;
  dueAt: string | null;
  totalCents: number;
  taxCents: number;
}

export interface LicenseDto {
  id: string;
  licenseKey: string;
  userId: string;
  customerName: string;
  customerEmail: string;
  productId: string;
  productName: string;
  productSlug: string;
  planName: string | null;
  seats: number;
  activationsUsed: number;
  status: LicenseStatus;
  issuedAt: string;
  expiresAt: string | null;
}

export interface DownloadDto {
  id: string;
  productId: string;
  productName: string;
  productSlug: string;
  versionId: string | null;
  version: string;
  kind: string;
  fileName: string;
  sizeMb: number;
  downloadedAt: string;
  requiresLicense: boolean;
}

export interface AvailableDownloadDto {
  productId: string;
  productName: string;
  productSlug: string;
  accentColor: string;
  licensed: boolean;
  versions: {
    id: string;
    version: string;
    releasedAt: string;
    platform: string;
    sizeMb: number;
    fileName: string;
    installerUrl: string | null;
    notes: string;
  }[];
}

export interface TicketMessageDto {
  id: string;
  authorName: string;
  isStaff: boolean;
  body: string;
  createdAt: string;
}

export interface TicketDto {
  id: string;
  reference: string;
  userId: string;
  customerName: string;
  customerEmail: string;
  productId: string | null;
  productName: string | null;
  subject: string;
  category: string;
  priority: TicketPriority;
  status: TicketStatus;
  environment: string | null;
  createdAt: string;
  updatedAt: string;
  messageCount?: number;
}

export interface TicketDetailDto extends TicketDto {
  messages: TicketMessageDto[];
}

export interface DiscountCodeDto {
  id: string;
  code: string;
  description: string | null;
  percentOff: number;
  maxRedemptions: number;
  timesRedeemed: number;
  expiresAt: string | null;
  isActive: boolean;
  createdAt: string;
}

export interface CustomerDto extends UserDto {
  orderCount: number;
  totalSpentCents: number;
  licenseCount: number;
  openTickets: number;
}

export interface SiteSettingsDto {
  siteName: string;
  supportEmail: string;
  salesEmail: string;
  supportPhone: string;
  heroHeadline: string;
  heroSubheading: string;
  taxRateBps: number;
  trialDays: number;
  maintenanceMode: boolean;
  announcement: string;
}

export interface TestimonialDto {
  id: string;
  authorName: string;
  authorRole: string;
  company: string;
  quote: string;
  rating: number;
}

export interface FaqDto {
  id: string;
  question: string;
  answer: string;
}

export interface AdminOverviewDto {
  revenueCents: number;
  revenueLast30Cents: number;
  orderCount: number;
  pendingOrderCount: number;
  customerCount: number;
  newCustomers30: number;
  activeLicenses: number;
  expiringLicenses: number;
  openTickets: number;
  pendingReviews: number;
  averageOrderCents: number;
  revenueByMonth: { label: string; valueCents: number }[];
  ordersByStatus: { label: string; value: number }[];
  topProducts: { name: string; units: number; revenueCents: number }[];
  customerGrowth: { label: string; value: number }[];
  recentOrders: OrderDto[];
}

export interface CustomerOverviewDto {
  orderCount: number;
  activeLicenses: number;
  expiringLicenses: number;
  openTickets: number;
  totalSpentCents: number;
  availableDownloads: number;
  outstandingInvoicesCents: number;
  recentOrders: OrderDto[];
  licensesExpiringSoon: LicenseDto[];
}
