"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import type { ApiEnvelope, AuthResultDto, CartDto, PagedMeta, UserDto } from "@/shared/contracts";

/* --------- transport: token-attaching fetch with automatic refresh -------- */

const CART_SESSION_KEY = "nw_cart_session";

let accessToken: string | null = null;
let refreshPromise: Promise<boolean> | null = null;

export class ApiError extends Error {
  status: number;
  code: string;
  details?: Record<string, string[]>;
  constructor(message: string, status: number, code = "error", details?: Record<string, string[]>) {
    super(message);
    this.status = status;
    this.code = code;
    this.details = details;
  }
}

function readCartSession(): string | null {
  if (typeof window === "undefined") return null;
  return window.localStorage.getItem(CART_SESSION_KEY);
}

function writeCartSession(value: string) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(CART_SESSION_KEY, value);
}

async function tryRefresh(): Promise<boolean> {
  if (!refreshPromise) {
    refreshPromise = (async () => {
      try {
        const res = await fetch("/api/auth/refresh", { method: "POST", credentials: "include" });
        if (!res.ok) return false;
        const payload = (await res.json()) as ApiEnvelope<AuthResultDto>;
        accessToken = payload.data.accessToken;
        return true;
      } catch {
        return false;
      } finally {
        setTimeout(() => {
          refreshPromise = null;
        }, 0);
      }
    })();
  }
  return refreshPromise;
}

interface RequestOptions {
  method?: "GET" | "POST" | "PATCH" | "PUT" | "DELETE";
  body?: unknown;
}

export async function apiRequest<T>(
  path: string,
  { method = "GET", body }: RequestOptions = {},
): Promise<{ data: T; meta?: PagedMeta }> {
  const doFetch = async () => {
    const headers: Record<string, string> = { accept: "application/json" };
    if (accessToken) headers.authorization = `Bearer ${accessToken}`;
    const cartSession = readCartSession();
    if (cartSession) headers["x-cart-session"] = cartSession;
    if (body !== undefined) headers["content-type"] = "application/json";
    return fetch(path, {
      method,
      headers,
      credentials: "include",
      body: body === undefined ? undefined : JSON.stringify(body),
    });
  };

  let res = await doFetch();
  const session = res.headers.get("x-cart-session");
  if (session) writeCartSession(session);

  if (res.status === 401 && !path.startsWith("/api/auth/")) {
    const refreshed = await tryRefresh();
    if (refreshed) {
      res = await doFetch();
      const nextSession = res.headers.get("x-cart-session");
      if (nextSession) writeCartSession(nextSession);
    }
  }

  let payload: ApiEnvelope<T> | null = null;
  try {
    payload = (await res.json()) as ApiEnvelope<T>;
  } catch {
    payload = null;
  }

  if (!res.ok || !payload?.success) {
    throw new ApiError(
      payload?.error?.message ?? `Request failed with status ${res.status}`,
      res.status,
      payload?.error?.code ?? "request_failed",
      payload?.error?.details,
    );
  }
  return { data: payload.data, meta: payload.meta };
}

export const api = {
  get: <T,>(path: string) => apiRequest<T>(path),
  post: <T,>(path: string, body?: unknown) => apiRequest<T>(path, { method: "POST", body }),
  patch: <T,>(path: string, body?: unknown) => apiRequest<T>(path, { method: "PATCH", body }),
  put: <T,>(path: string, body?: unknown) => apiRequest<T>(path, { method: "PUT", body }),
  delete: <T,>(path: string) => apiRequest<T>(path, { method: "DELETE" }),
};

export function setAccessToken(token: string | null) {
  accessToken = token;
}

/* ------------------ useApi: loading / error / data hook ------------------- */

export function useApi<T>(path: string | null, deps: unknown[] = []) {
  const [data, setData] = useState<T | null>(null);
  const [meta, setMeta] = useState<PagedMeta | undefined>(undefined);
  const [loading, setLoading] = useState(Boolean(path));
  const [error, setError] = useState<string | null>(null);
  const version = useRef(0);

  const load = useCallback(
    async (silent = false) => {
      if (!path) {
        setLoading(false);
        return;
      }
      const current = ++version.current;
      if (!silent) setLoading(true);
      try {
        const result = await apiRequest<T>(path);
        if (current !== version.current) return;
        setData(result.data);
        setMeta(result.meta);
        setError(null);
      } catch (err) {
        if (current !== version.current) return;
        setError(err instanceof Error ? err.message : "Something went wrong");
      } finally {
        if (current === version.current) setLoading(false);
      }
    },
    [path],
  );

  useEffect(() => {
    void load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [path, ...deps]);

  return { data, meta, loading, error, refresh: load, setData, setMeta };
}

/* ------------------------------- auth context ------------------------------ */

interface AuthContextValue {
  user: UserDto | null;
  status: "loading" | "authenticated" | "anonymous";
  login: (email: string, password: string) => Promise<UserDto>;
  register: (input: {
    fullName: string;
    email: string;
    password: string;
    company?: string;
    country?: string;
  }) => Promise<UserDto>;
  logout: () => Promise<void>;
  updateProfile: (input: Partial<Pick<UserDto, "fullName" | "company" | "phone" | "country">>) => Promise<UserDto>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<UserDto | null>(null);
  const [status, setStatus] = useState<"loading" | "authenticated" | "anonymous">("loading");

  const applyAuth = useCallback((result: AuthResultDto) => {
    accessToken = result.accessToken;
    setUser(result.user);
    setStatus("authenticated");
  }, []);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch("/api/auth/refresh", { method: "POST", credentials: "include" });
        if (!res.ok) throw new Error("no session");
        const payload = (await res.json()) as ApiEnvelope<AuthResultDto>;
        if (cancelled) return;
        applyAuth(payload.data);
      } catch {
        if (!cancelled) {
          accessToken = null;
          setUser(null);
          setStatus("anonymous");
        }
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [applyAuth]);

  const login = useCallback(
    async (email: string, password: string) => {
      const { data } = await api.post<AuthResultDto>("/api/auth/login", { email, password });
      applyAuth(data);
      return data.user;
    },
    [applyAuth],
  );

  const register = useCallback(
    async (input: { fullName: string; email: string; password: string; company?: string; country?: string }) => {
      const { data } = await api.post<AuthResultDto>("/api/auth/register", input);
      applyAuth(data);
      return data.user;
    },
    [applyAuth],
  );

  const logout = useCallback(async () => {
    await api.post("/api/auth/logout");
    accessToken = null;
    setUser(null);
    setStatus("anonymous");
  }, []);

  const updateProfile = useCallback(
    async (input: Partial<Pick<UserDto, "fullName" | "company" | "phone" | "country">>) => {
      const { data } = await api.patch<{ user: UserDto }>("/api/auth/me", input);
      setUser(data.user);
      return data.user;
    },
    [],
  );

  const value = useMemo(
    () => ({ user, status, login, register, logout, updateProfile }),
    [user, status, login, register, logout, updateProfile],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used inside AuthProvider");
  return ctx;
}

/* ------------------------- cart context (optimistic) ----------------------- */

interface CartContextValue {
  cart: CartDto | null;
  loading: boolean;
  discountCode: string | null;
  refresh: () => Promise<void>;
  addItem: (planId: string, quantity?: number) => Promise<void>;
  setQuantity: (itemId: string, quantity: number) => Promise<void>;
  removeItem: (itemId: string) => Promise<void>;
  applyDiscount: (code: string) => Promise<void>;
  clearDiscount: () => Promise<void>;
}

const CartContext = createContext<CartContextValue | null>(null);

function recalcTotals(cart: CartDto, items: CartDto["items"]): CartDto {
  const subtotalCents = items.reduce((sum, i) => sum + i.lineTotalCents, 0);
  const taxable = Math.max(0, subtotalCents - cart.discountCents);
  return {
    ...cart,
    items,
    subtotalCents,
    itemCount: items.reduce((sum, i) => sum + i.quantity, 0),
    taxCents: Math.round((taxable * cart.taxRateBps) / 10_000),
    totalCents: taxable + Math.round((taxable * cart.taxRateBps) / 10_000),
  };
}

export function CartProvider({ children }: { children: ReactNode }) {
  const { status } = useAuth();
  const [cart, setCart] = useState<CartDto | null>(null);
  const [loading, setLoading] = useState(true);
  const [discountCode, setDiscountCode] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const query = discountCode ? `?discountCode=${encodeURIComponent(discountCode)}` : "";
      const { data } = await api.get<CartDto>(`/api/cart${query}`);
      setCart(data);
    } catch {
      setCart(null);
    } finally {
      setLoading(false);
    }
  }, [discountCode]);

  useEffect(() => {
    if (status === "loading") return;
    void load();
  }, [status, load]);

  const addItem = useCallback(
    async (planId: string, quantity = 1) => {
      // Optimistic bump, then reconcile with the server response.
      setCart((prev) =>
        prev ? recalcTotals(prev, prev.items).itemCount !== undefined ? { ...prev, itemCount: prev.itemCount + quantity } : prev : prev,
      );
      try {
        const { data } = await api.post<CartDto>("/api/cart/items", { planId, quantity });
        setCart(data);
      } catch (error) {
        await load();
        throw error;
      }
    },
    [load],
  );

  const setQuantity = useCallback(
    async (itemId: string, quantity: number) => {
      const previous = cart;
      setCart((prev) => {
        if (!prev) return prev;
        const items = prev.items
          .map((item) =>
            item.id === itemId
              ? { ...item, quantity, lineTotalCents: item.unitPriceCents * quantity }
              : item,
          )
          .filter((item) => item.quantity > 0);
        return recalcTotals(prev, items);
      });
      try {
        const { data } = await api.patch<CartDto>(`/api/cart/items/${itemId}`, { quantity });
        setCart(data);
      } catch {
        setCart(previous);
      }
    },
    [cart],
  );

  const removeItem = useCallback(
    async (itemId: string) => {
      const previous = cart;
      setCart((prev) => (prev ? recalcTotals(prev, prev.items.filter((i) => i.id !== itemId)) : prev));
      try {
        const { data } = await api.delete<CartDto>(`/api/cart/items/${itemId}`);
        setCart(data);
      } catch {
        setCart(previous);
      }
    },
    [cart],
  );

  const applyDiscount = useCallback(async (code: string) => {
    const { data } = await api.post<CartDto>("/api/cart/discount", { code });
    setCart(data);
    setDiscountCode(data.discountCode);
  }, []);

  const clearDiscount = useCallback(async () => {
    setDiscountCode(null);
  }, []);

  const value = useMemo(
    () => ({
      cart,
      loading,
      discountCode,
      refresh: load,
      addItem,
      setQuantity,
      removeItem,
      applyDiscount,
      clearDiscount,
    }),
    [cart, loading, discountCode, load, addItem, setQuantity, removeItem, applyDiscount, clearDiscount],
  );

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error("useCart must be used inside CartProvider");
  return ctx;
}
